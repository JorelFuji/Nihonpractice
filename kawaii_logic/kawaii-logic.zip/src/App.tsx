import { useState, useEffect } from 'react';
import { ViewType, Character, PlayerStats } from './types';
import { charactersList } from './dictionary';
import Navigation from './components/Navigation';
import HomeSelector from './components/HomeSelector';
import CharacterSelector from './components/CharacterSelector';
import ShiritoriGame from './components/ShiritoriGame';
import OthelloGame from './components/OthelloGame';
import Leaderboard from './components/Leaderboard';
import Rules from './components/Rules';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [selectedChar, setSelectedChar] = useState<Character>(charactersList[0]); // Starts with Satoshi!

  // Game tracking metrics
  const [playerStats, setPlayerStats] = useState<PlayerStats>({
    gamesPlayed: 8,
    wins: 5,
    winRate: 62,
    longestWord: {
      jp: "しんじゅく",
      en: "Shinjuku district"
    }
  });

  const handleShiritoriWin = (wordJp: string, wordEn: string) => {
    setPlayerStats((prev) => {
      const nextGames = prev.gamesPlayed + 1;
      const nextWins = prev.wins + 1;
      const nextRate = Math.round((nextWins / nextGames) * 100);

      const isNewRecord = wordJp.length > prev.longestWord.jp.length;
      return {
        gamesPlayed: nextGames,
        wins: nextWins,
        winRate: nextRate,
        longestWord: isNewRecord ? { jp: wordJp, en: wordEn } : prev.longestWord
      };
    });
  };

  const handleOthelloWin = () => {
    setPlayerStats((prev) => {
      const nextGames = prev.gamesPlayed + 1;
      const nextWins = prev.wins + 1;
      const nextRate = Math.round((nextWins / nextGames) * 100);
      return {
        ...prev,
        gamesPlayed: nextGames,
        wins: nextWins,
        winRate: nextRate
      };
    });
  };

  // Scroll to top on view change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView]);

  return (
    <div className="min-h-screen bg-[#050505] text-[#E5E5E1] font-sans antialiased pb-24 md:pb-8 flex flex-col selection:bg-[#D4AF37] selection:text-black">
      
      {/* Dynamic Header & Floating Mobile Menu */}
      <Navigation 
        currentView={currentView} 
        onViewChange={setCurrentView} 
        player1Name={selectedChar.en} 
        avatarSeed={selectedChar.seed}
      />

      {/* Main Core Content Container */}
      <main className="flex-grow pt-24 px-4 md:px-8 max-w-7xl mx-auto w-full">
        {currentView === 'home' && (
          <HomeSelector onViewChange={setCurrentView} playerStats={playerStats} />
        )}

        {currentView === 'character' && (
          <CharacterSelector 
            onViewChange={setCurrentView} 
            selectedChar={selectedChar} 
            onSelectChar={setSelectedChar} 
          />
        )}

        {currentView === 'shiritori' && (
          <ShiritoriGame 
            onViewChange={setCurrentView} 
            selectedChar={selectedChar} 
            onGameWon={handleShiritoriWin} 
          />
        )}

        {currentView === 'othello' && (
          <OthelloGame 
            onViewChange={setCurrentView} 
            selectedChar={selectedChar} 
            onGameWon={handleOthelloWin} 
          />
        )}

        {currentView === 'leaderboard' && (
          <Leaderboard 
            onViewChange={setCurrentView} 
            playerStats={playerStats} 
            player1Name={selectedChar.en}
            avatarSeed={selectedChar.seed}
          />
        )}

        {currentView === 'rules' && (
          <Rules onViewChange={setCurrentView} />
        )}
      </main>

      {/* Small Ambient background decorations */}
      <div className="absolute top-[30vh] left-[5vw] w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none select-none -z-10"></div>
      <div className="absolute bottom-[20vh] right-[5vw] w-[450px] h-[450px] bg-white/5 rounded-full blur-3xl pointer-events-none select-none -z-10"></div>
    </div>
  );
}

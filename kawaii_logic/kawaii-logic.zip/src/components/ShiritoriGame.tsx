import React, { useState, useEffect, useRef } from 'react';
import { Send, Menu, HelpCircle, User, Sparkles, RefreshCw, Volume2, AlertCircle } from 'lucide-react';
import { Character, ShiritoriWord, ViewType } from '../types';
import { 
  SHIRITORI_DICTIONARY, 
  convertRomajiToHiragana, 
  getWordCharacters,
  charactersList
} from '../dictionary';

interface ShiritoriGameProps {
  onViewChange: (view: ViewType) => void;
  selectedChar: Character;
  onGameWon: (longestWordJp: string, longestWordEn: string) => void;
}

export default function ShiritoriGame({ onViewChange, selectedChar, onGameWon }: ShiritoriGameProps) {
  // Game states
  const [chain, setChain] = useState<ShiritoriWord[]>([]);
  const [inputValue, setVal] = useState<string>("");
  const [playerScore, setPlayerScore] = useState<number>(0);
  const [cpuScore, setCpuScore] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(10);
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'thinking' | 'ended'>('idle');
  const [message, setMessage] = useState<{ text: string; type: 'info' | 'error' | 'success' }>({ text: "Type words to start the chain!", type: 'info' });
  const [endReason, setEndReason] = useState<string>("");

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // Initialize game on mount or reset
  const startGame = () => {
    // Starting seed word: しりとり (SHIRITORI)
    const seedWord: ShiritoriWord = {
      word: "しりとり",
      romaji: "shiritori",
      meaning: "Word Chain Battle",
      isPlayer: false
    };

    setChain([seedWord]);
    setPlayerScore(0);
    setCpuScore(0);
    setTimeLeft(10);
    setGameState('playing');
    setVal("");
    setMessage({ text: "It's your turn! Play a Japanese word starting with 「り」 (RI).", type: 'info' });
  };

  useEffect(() => {
    startGame();
    return () => stopTimer();
  }, []);

  // Sync scroll on chain append
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = scrollRef.current.scrollWidth;
    }
  }, [chain]);

  // Game timer logic
  useEffect(() => {
    if (gameState === 'playing') {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleTimeOut();
            return 10;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      stopTimer();
    }

    return () => stopTimer();
  }, [gameState, chain]);

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  const handleTimeOut = () => {
    stopTimer();
    // Player timed out! CPU plays a smart word to save or skips.
    setMessage({ text: "Time is up! CPU scores, resetting turn.", type: 'error' });
    setCpuScore((prev) => prev + 100);
    // Find next word automatically for CPU and keep playing
    triggerCpuTurn(getLastWordEndChar());
  };

  // Extract trailing character of the last word in chain
  const getLastWordEndChar = (): string => {
    if (chain.length === 0) return "";
    const lastWordObj = chain[chain.length - 1];
    const { end } = getWordCharacters(lastWordObj.word);
    return end;
  };

  // Convert input romaji to hiragana in real time
  const handleValChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value;
    const HiraganaMapped = convertRomajiToHiragana(rawVal);
    setVal(HiraganaMapped);
  };

  // Evaluate player's submission
  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (gameState !== 'playing') return;

    const trimmedInput = inputValue.trim();
    if (!trimmedInput) return;

    // 1. Check end character constraint (Cannot end with ん - instant loss!)
    const { start, end } = getWordCharacters(trimmedInput);
    
    if (end === 'ん' || end === 'ン') {
      endGame(false, `You played 「${trimmedInput}」 which ends with 「ん」! Instantly broken.`);
      return;
    }

    // 2. Validate starting character against previous word's tail
    const targetStartChar = getLastWordEndChar();
    
    // Voiced sounds flexibility (e.g. standardizing dakuon so 'go'ご matches 'ko'こ or 'go'ご)
    const matchAlternative: Record<string, string[]> = {
      'が': ['か', 'が'], 'ぎ': ['き', 'ぎ'], 'ぐ': ['く', 'ぐ'], 'げ': ['け', 'げ'], 'ご': ['こ', 'ご'],
      'ざ': ['さ', 'ざ'], 'じ': ['し', 'じ'], 'ず': ['す', 'ず'], 'ぜ': ['せ', 'ぜ'], 'zo': ['そ', 'ぞ'], 'ぞ': ['そ', 'ぞ'],
      'だ': ['た', 'だ'], 'ぢ': ['ち', 'ぢ'], 'づ': ['つ', 'づ'], 'で': ['て', 'で'], 'ど': ['と', 'ど'],
      'ば': ['は', 'ば', 'ぱ'], 'び': ['ひ', 'び', 'ぴ'], 'ぶ': ['ふ', 'ぶ', 'ぷ'], 'べ': ['へ', 'べ', 'ぺ'], 'ぼ': ['ほ', 'ぼ', 'ぽ'],
      'ぱ': ['は', 'ば', 'ぱ'], 'ぴ': ['ひ', 'び', 'ぴ'], 'ぷ': ['ふ', 'ぶ', 'ぷ'], 'ぺ': ['へ', 'べ', 'ぺ'], 'ぽ': ['ほ', 'ぼ', 'ぽ']
    };

    const isMatch = (inputStart: string, targetEnd: string) => {
      if (inputStart === targetEnd) return true;
      if (matchAlternative[targetEnd] && matchAlternative[targetEnd].includes(inputStart)) return true;
      if (matchAlternative[inputStart] && matchAlternative[inputStart].includes(targetEnd)) return true;
      return false;
    };

    if (!isMatch(start, targetStartChar)) {
      setMessage({ 
        text: `Word must start with 「${targetStartChar}」! Input starts with 「${start}」.`, 
        type: 'error' 
      });
      return;
    }

    // 3. Prevent repeats
    const isRepeated = chain.some(c => c.word === trimmedInput);
    if (isRepeated) {
      setMessage({ 
        text: `「${trimmedInput}」 has already been used in this battle! Choose another matching noun.`, 
        type: 'error' 
      });
      return;
    }

    // Lookup definition
    const dictionaryMatch = SHIRITORI_DICTIONARY.find(d => d.jp === trimmedInput);
    const meaning = dictionaryMatch ? dictionaryMatch.en : "Japanese Challenger Noun";
    const romaji = dictionaryMatch ? dictionaryMatch.romaji : trimmedInput;

    // Check if player stats wins a new longest word record
    if (trimmedInput.length > 3) {
      onGameWon(trimmedInput, meaning);
    }

    // Add to chain
    const newWord: ShiritoriWord = {
      word: trimmedInput,
      romaji,
      meaning,
      isPlayer: true
    };

    const nextChain = [...chain, newWord];
    setChain(nextChain);
    
    // Add Score
    const bonus = trimmedInput.length * 120;
    setPlayerScore((prev) => prev + bonus);
    
    // Reset Input
    setVal("");
    setMessage({ text: `Great! 「${trimmedInput}」 (+${bonus} pts). Opponent is thinking...`, type: 'success' });

    // Transition state to CPU thinking
    setGameState('thinking');
    
    // Trigger CPU turn
    setTimeout(() => {
      triggerCpuTurn(end);
    }, 1500);
  };

  // CPU plays its turn
  const triggerCpuTurn = (startingChar: string) => {
    // Find candidate words in dictionary that start with the startingChar and do not end in ん
    const candidates = SHIRITORI_DICTIONARY.filter(w => {
      const { start, end } = getWordCharacters(w.jp);
      // Voiced check
      const voicedMatch = start === startingChar || 
        (startingChar === 'り' && start === 'り'); // Fallback matches
      
      const doesMatch = start === startingChar;
      return doesMatch && end !== 'ん' && !chain.some(played => played.word === w.jp);
    });

    let playedWord: ShiritoriWord;

    if (candidates.length > 0) {
      // Pick random matched dictionary entry
      const chosen = candidates[Math.floor(Math.random() * candidates.length)];
      playedWord = {
        word: chosen.jp,
        romaji: chosen.romaji,
        meaning: chosen.en,
        isPlayer: false
      };
    } else {
      // Fallback fallback if no valid words remain in the mock dictionary.
      // Generate logical word to maintain flow based on hiragana database
      const backups: Record<string, {jp: string; romaji: string; en: string}> = {
        'あ': { jp: "あいす", romaji: "aisu", en: "Ice cream" },
        'い': { jp: "いか", romaji: "ika", en: "Squid" },
        'う': { jp: "うちわ", romaji: "uchiwa", en: "Paper fan" },
        'え': { jp: "えあこん", romaji: "eakon", en: "Air conditioner" },
        'お': { jp: "おんがく", romaji: "ongaku", en: "Music (Warning: Ends with ん! CPU loses!)" }, // Let the CPU lose optionally!
        'く': { jp: "くつした", romaji: "kutsushita", en: "Socks" },
        'こ': { jp: "こうちゃ", romaji: "koucha", en: "Black tea" },
        'す': { jp: "すーぷ", romaji: "suupu", en: "Soup" },
        'ち': { jp: "ちょっと", romaji: "chotto", en: "Moment" },
        'な': { jp: "なっとう", romaji: "nattou", en: "Natto" },
        'に': { jp: "にほんご", romaji: "nihongo", en: "Japanese language" },
        'ぬ': { jp: "ぬくもり", romaji: "nukumori", en: "Warmth" },
        'ね': { jp: "ねずみ", romaji: "nezumi", en: "Mouse / Rat" },
        'は': { jp: "はむ", romaji: "hamu", en: "Ham" },
        'ひ': { jp: "ひまわり", romaji: "himawari", en: "Sunflower" },
        'ふ': { jp: "ふーど", romaji: "fuudo", en: "Food" },
        'ほ': { jp: "ほわいと", romaji: "howaito", en: "White" },
        'ま': { jp: "まっちゃ", romaji: "maccha", en: "Matcha green tea" },
        'み': { jp: "みるく", romaji: "miruku", en: "Milk" },
        'む': { jp: "むぎわら", romaji: "mugiwara", en: "Straw" },
        'め': { jp: "めだか", romaji: "medaka", en: "Killifish" },
        'も': { jp: "ももたろう", romaji: "momotarou", en: "Peach boy" },
        'り': { jp: "りゅうきゅう", romaji: "ryuukyuu", en: "Ryukyu Islands" },
        'る': { jp: "るーる", romaji: "ruuru", en: "Rules" },
        'れ': { jp: "れんが", romaji: "renga", en: "Brick" },
        'ろ': { jp: "ろうがくぎ", romaji: "rougakugi", en: "Old school" },
        'わ': { jp: "わた", romaji: "wata", en: "Cotton" }
      };

      const backup = backups[startingChar];
      if (backup && !chain.some(played => played.word === backup.jp)) {
        playedWord = {
          word: backup.jp,
          romaji: backup.romaji,
          meaning: backup.en,
          isPlayer: false
        };
      } else {
        // If CPU cannot find any suitable noun, it fails and player wins!
        endGame(true, "Opponent AI exhausted its vocabulary. You outsmarted the sensei!");
        return;
      }
    }

    // Verify if CPU accidentally ends in "ん" (Self-defeat rule!)
    const { end: cpuEnd } = getWordCharacters(playedWord.word);
    if (cpuEnd === 'ん' || cpuEnd === 'ン') {
      setChain(prev => [...prev, playedWord]);
      setCpuScore((prev) => prev + 150);
      endGame(true, `CPU played 「${playedWord.word}」 which ends with 「ん」! You win!`);
      return;
    }

    // Add to chain & score
    setChain(prev => [...prev, playedWord]);
    setCpuScore((prev) => prev + playedWord.word.length * 90);
    setTimeLeft(10);
    setGameState('playing');
    setMessage({ 
      text: `Opponent played 「${playedWord.word}」. Your turn! Play a word starting with 「${cpuEnd}」.`, 
      type: 'info' 
    });

    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const endGame = (didPlayerWin: boolean, reason: string) => {
    stopTimer();
    setGameState('ended');
    setEndReason(reason);
    if (didPlayerWin) {
      setPlayerScore((prev) => prev + 1000); // 1000 Victory Bonus points!
      setMessage({ text: "🌸 VICTORY! Match won! 🌸", type: 'success' });
    } else {
      setMessage({ text: "❌ Match Over! ❌", type: 'error' });
    }
  };

  // Helpers
  const nextTargetChar = getLastWordEndChar();

  return (
    <div className="space-y-8 pb-36 max-w-4xl mx-auto relative">
      
      {/* Elegantly styled Battle Arena representation panel */}
      <section className="w-full h-48 sm:h-64 relative bg-[#0a0a0a] border border-white/10 rounded-none overflow-hidden shadow-2xl">
        <div className="absolute inset-0 bg-black/40 pointer-events-none"></div>

        {/* Dynamic graphics placeholder */}
        <div className="absolute inset-0 flex items-center justify-around select-none pointer-events-none p-4 opacity-80">
          {/* Player avatar display side */}
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-none border border-[#D4AF37] bg-black shadow-lg flex items-center justify-center p-0.5 animate-bounce">
              <img 
                src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedChar.seed}&backgroundColor=030303`} 
                className="w-full h-full object-contain rounded-none grayscale" 
                alt="Player"
              />
            </div>
            <span className="text-[#D4AF37] font-mono text-[8px] font-bold tracking-[0.25em] mt-1.5">CHALLENGER</span>
          </div>

          <div className="text-center space-y-1">
            <span className="text-[#D4AF37] font-mono text-[9px] uppercase tracking-[0.25em] font-medium block">ARENA BATTLE</span>
            <div className="text-[#E5E5E1]/30 font-serif text-3xl font-light tracking-wide">VS</div>
            <span className="px-2 py-0.5 border border-[#D4AF37]/30 text-[#D4AF37] font-mono text-[8px] bg-transparent tracking-[0.20em] block uppercase">
              TOKYO-01 RANKED
            </span>
          </div>

          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-none border border-white/10 bg-black shadow-lg flex items-center justify-center p-0.5">
              <img 
                src="https://api.dicebear.com/7.x/avataaars/svg?seed=Miku&backgroundColor=030303" 
                className="w-full h-full object-contain rounded-none grayscale" 
                alt="CPU Sensei"
              />
            </div>
            <span className="text-[#E5E5E1]/40 font-mono text-[8px] font-bold tracking-[0.25em] mt-1.5">AI SENSEI</span>
          </div>
        </div>

        {/* Player Nameplates (Thin monolithic frames) */}
        <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-none">
          {/* Player 1 details */}
          <div className={`bg-black/90 border border-white/15 p-3 rounded-none flex flex-col gap-1 transition-all ${gameState === 'playing' ? 'scale-105 border-[#D4AF37] shadow-[0_1px_12px_rgba(212,175,55,0.1)]' : 'opacity-85'}`}>
            <span className="font-mono text-[8px] text-[#D4AF37] tracking-[0.15em] font-bold leading-none">PLAYER 1</span>
            <span className="font-serif font-light text-[#E5E5E1] text-sm leading-none mt-1">{selectedChar.en}</span>
            <div className="w-24 h-[1px] bg-white/5 overflow-hidden mt-1.5">
              <div className="h-full bg-[#D4AF37]" style={{ width: `${Math.min(playerScore / 20, 100)}%` }}></div>
            </div>
            <span className="font-mono text-[8px] text-[#E5E5E1]/40 mt-1 leading-none">PTS: {playerScore}</span>
          </div>

          {/* Player 2 Details */}
          <div className={`bg-black/90 border border-white/15 p-3 rounded-none flex flex-col items-end gap-1 transition-all ${gameState === 'thinking' ? 'scale-105 border-white/30' : 'opacity-85'}`}>
            <span className="font-mono text-[8px] text-white/40 tracking-[0.15em] font-bold leading-none">PLAYER 2</span>
            <span className="font-serif font-light text-[#E5E5E1]/90 text-sm leading-none mt-1">AI_Sensei</span>
            <div className="w-24 h-[1px] bg-white/5 overflow-hidden mt-1.5">
              <div className="h-full bg-white/20" style={{ width: `${Math.min(cpuScore / 20, 100)}%` }}></div>
            </div>
            <span className="font-mono text-[8px] text-white/35 mt-1 leading-none">PTS: {cpuScore}</span>
          </div>
        </div>
      </section>

      {/* Game Message Alert Area */}
      <div className={`p-4 rounded-none text-center border-l bg-[#0a0a0a] font-sans font-light text-xs transition-all ${
        message.type === 'error' ? 'border-red-900 text-red-400' :
        message.type === 'success' ? 'border-green-900 text-green-400' :
        'border-[#D4AF37] text-[#E5E5E1]/80'
      }`}>
        <p className="flex items-center justify-center gap-2">
          {message.text}
        </p>
      </div>

      {/* Screen OVERLAY if Game Ended */}
      {gameState === 'ended' && (
        <div className="bg-[#0a0a0a]/95 border border-[#D4AF37] p-8 rounded-none text-center space-y-6 shadow-2xl relative z-30">
          <div className="space-y-3">
            <p className="font-mono text-[9px] text-[#D4AF37] tracking-[0.25em] font-bold uppercase">{message.text}</p>
            <h3 className="font-serif text-3xl md:text-4xl font-light text-[#E5E5E1] tracking-wide">GAME OVER</h3>
            <p className="text-sm font-sans text-[#E5E5E1]/60 max-w-lg mx-auto leading-relaxed mt-2 font-light">
              {endReason}
            </p>
          </div>

          <div className="bg-black p-6 rounded-none max-w-sm mx-auto border border-white/10">
            <p className="font-mono text-[8px] text-[#E5E5E1]/40 uppercase tracking-[0.2em] font-bold">Final Score results</p>
            <div className="flex justify-around items-center mt-4 font-serif">
              <div>
                <p className="text-[9px] text-[#D4AF37] font-mono tracking-widest leading-none">YOU</p>
                <p className="text-2xl text-[#E5E5E1] mt-1.5 font-light">{playerScore}</p>
              </div>
              <div className="w-[1px] h-8 bg-white/10"></div>
              <div>
                <p className="text-[9px] text-[#E5E5E1]/40 font-mono tracking-widest leading-none">AI SENSEI</p>
                <p className="text-2xl text-[#E5E5E1] mt-1.5 font-light">{cpuScore}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <button 
              onClick={startGame}
              className="bg-white text-black hover:bg-[#D4AF37] hover:text-black py-4 px-8 rounded-none font-mono text-xs uppercase font-bold tracking-[0.2em] transition-colors flex-1"
            >
              Play Match Again
            </button>
            <button 
              onClick={() => onViewChange('home')}
              className="border border-white/20 hover:border-white text-[#E5E5E1] bg-transparent rounded-none py-4 px-8 font-mono text-xs uppercase font-bold tracking-[0.2em] transition-all flex-1"
            >
              Back to Home
            </button>
          </div>
        </div>
      )}

      {/* Target Word Display Section */}
      {gameState !== 'ended' && (
        <section className="flex flex-col items-center text-center gap-2 py-4 relative group">
          <div className="font-mono text-[9px] text-[#D4AF37] tracking-[0.2em] font-medium uppercase">
            NEXT TARGET IN CHAIN
          </div>

          <div className="relative">
            <h2 className="font-serif text-4xl sm:text-5xl font-light text-[#E5E5E1] tracking-wide relative flex items-baseline justify-center gap-3 mt-1">
              <span className="text-[#E5E5E1]">
                {chain[chain.length - 1]?.word}
              </span>
              <span className="font-mono font-normal text-sm text-[#E5E5E1]/40 tracking-wider">
                [{chain[chain.length - 1]?.romaji.toUpperCase()}]
              </span>
            </h2>
          </div>

          {/* Parameter validation badges */}
          <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
            <div className="px-4 py-1.5 bg-white/5 border border-white/10 rounded-none font-mono text-[10px] tracking-wider text-[#E5E5E1]/70">
              STARTS WITH: <span className="text-[#D4AF37] font-semibold">【{nextTargetChar}】</span>
            </div>
            <div className="px-4 py-1.5 bg-black border border-[#D4AF37]/35 rounded-none font-mono text-[10px] tracking-wider text-[#D4AF37]">
              BONUS : <span className="text-white font-medium">+450 PTS</span>
            </div>
          </div>
        </section>
      )}

      {/* Scrollable Word sticker chain overview */}
      <section className="w-full bg-[#0a0a0a] p-6 rounded-none border border-white/10 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <span className="font-mono text-[9px] text-[#E5E5E1]/40 tracking-wider font-bold">
            CHAIN BATTLE LOG ({chain.length} Words)
          </span>
          <span className="font-mono text-[9px] text-[#D4AF37] bg-[#D4AF37]/10 px-2.5 py-1 border border-[#D4AF37]/30 rounded-none tracking-widest font-bold">
            {chain.length - 1} COMBO!
          </span>
        </div>

        {/* Scrollable list content */}
        <div 
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-2 scroll-smooth select-none snap-x snap-mandatory"
        >
          {chain.map((item, idx) => {
            const isUser = item.isPlayer;
            const isLatest = idx === chain.length - 1;
            
            return (
              <div 
                key={idx}
                className={`snap-center shrink-0 transition-transform ${
                  isLatest ? 'scale-105' : 'opacity-70'
                }`}
              >
                <div className={`px-6 py-4 rounded-none border flex flex-col items-center justify-center relative min-w-[125px] ${
                  isUser 
                    ? 'bg-white/5 border-[#D4AF37] shadow-[2px_2px_0px_0px_#D4AF37]' 
                    : 'bg-[#0a0a0a] border-white/10'
                }`}>
                  <span className={`font-serif text-sm font-light ${isUser ? 'text-[#D4AF37]' : 'text-[#E5E5E1]'}`}>
                    {item.word}
                  </span>
                  <span className="font-mono text-[9px] text-[#E5E5E1]/40 mt-1 uppercase tracking-wide">
                    {item.romaji}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Floating Bottom Input Dock Bar */}
      <footer className="fixed bottom-16 sm:bottom-0 left-0 w-full bg-[#030303]/95 backdrop-blur-md border-t border-white/10 p-6 z-40 flex flex-col items-center">
        <div className="w-full max-w-3xl flex items-center gap-4">
          
          {/* Bottom Avatar Indicator */}
          <div className="hidden sm:flex flex-col items-center gap-1 select-none shrink-0">
            <div className="relative">
              <div className="w-12 h-12 rounded-none bg-black border border-white/10 p-0.5 overflow-hidden">
                <img 
                  alt="Player avatar" 
                  className="w-full h-full object-contain grayscale"
                  src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedChar.seed}&backgroundColor=030303`}
                />
              </div>
            </div>
            <span className="font-mono text-[8px] text-[#D4AF37] font-bold tracking-wider mt-1">PLAYER</span>
          </div>

          {/* Form input frame */}
          <form 
            onSubmit={handleSubmit}
            className="flex-1 flex items-center gap-4 bg-black border border-white/15 p-2 rounded-none focus-within:border-[#D4AF37] transition-all"
          >
            {/* Round Count Down Timer Circle SVG */}
            <div className="relative w-10 h-10 flex items-center justify-center shrink-0">
              <svg className="w-full h-full -rotate-90">
                <circle 
                  className="text-white/5" 
                  cx="20" 
                  cy="20" 
                  fill="transparent" 
                  r="16" 
                  stroke="currentColor" 
                  strokeWidth="2"
                ></circle>
                <circle 
                  className={`transition-all duration-1000 ${timeLeft <= 3 ? 'text-red-700' : 'text-[#D4AF37]'}`} 
                  cx="20" 
                  cy="20" 
                  fill="transparent" 
                  r="16" 
                  stroke="currentColor" 
                  strokeWidth="2"
                  strokeDasharray="100.48"
                  strokeDashoffset={100.48 - (100.48 * timeLeft) / 10}
                ></circle>
              </svg>
              <span className={`absolute font-mono text-xs font-bold ${timeLeft <= 3 ? 'text-red-400 animate-pulse' : 'text-[#D4AF37]'}`}>
                {timeLeft}
              </span>
            </div>

            {/* Input field text core */}
            <div className="flex-1 flex flex-col min-w-0">
              <label className="font-mono text-[8px] text-[#E5E5E1]/30 tracking-widest mb-0.5 leading-none uppercase">
                Tap to Answer (Starts with: {nextTargetChar})
              </label>
              <input 
                ref={inputRef}
                type="text" 
                value={inputValue}
                onChange={handleValChange}
                disabled={gameState !== 'playing'}
                placeholder="Type noun character..." 
                className="bg-transparent border-none outline-none focus:ring-0 text-[#E5E5E1] text-sm font-serif font-light p-0 placeholder:text-white/10 min-w-0"
              />
            </div>

            {/* Submit Button */}
            <button 
              type="submit"
              disabled={gameState !== 'playing' || !inputValue.trim()}
              className="bg-[#E5E5E1] text-black hover:bg-[#D4AF37] hover:text-black px-6 py-3.5 rounded-none font-mono text-[10px] tracking-wider uppercase font-bold transition-colors disabled:opacity-20 disabled:pointer-events-none cursor-pointer flex items-center gap-1.5"
            >
              <span>SEND</span>
              <Send size={10} className="stroke-[2.5]" />
            </button>
          </form>

          {/* Right Computer Avatar Indicator */}
          <div className="hidden sm:flex flex-col items-center gap-1 select-none shrink-0">
            <div className="relative">
              <div className="w-12 h-12 rounded-none bg-black border border-white/10 p-0.5 overflow-hidden">
                <img 
                  alt="CPU avatar" 
                  className="w-full h-full object-contain grayscale"
                  src="https://api.dicebear.com/7.x/avataaars/svg?seed=Miku&backgroundColor=030303"
                />
              </div>
              {gameState === 'thinking' && (
                <div className="absolute -top-2 -left-2 px-2 py-0.5 bg-black border border-[#D4AF37] text-[#D4AF37] font-mono text-[7px] font-bold tracking-wider animate-bounce">
                  THINKING
                </div>
              )}
            </div>
            <span className="font-mono text-[8px] text-[#E5E5E1]/40 font-bold tracking-wider mt-1">SENSEI</span>
          </div>

        </div>
      </footer>
    </div>
  );
}

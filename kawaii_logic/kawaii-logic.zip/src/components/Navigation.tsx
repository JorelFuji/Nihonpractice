import { Home, Trophy, BookOpen, Settings, User } from 'lucide-react';
import { ViewType } from '../types';

interface NavigationProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  player1Name: string;
  avatarSeed: string;
}

export default function Navigation({ currentView, onViewChange, player1Name, avatarSeed }: NavigationProps) {
  return (
    <>
      {/* Desktop & Tablet Top Nav Header */}
      <header className="fixed top-0 left-0 w-full bg-[#050505]/90 backdrop-blur-md z-50 flex justify-between items-center px-4 md:px-8 py-4 border-b border-white/10">
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => onViewChange('home')}
        >
          <div className="w-10 h-10 border border-[#D4AF37] rounded-all flex items-center justify-center transition-all group-hover:bg-[#D4AF37]/10" style={{ borderRadius: '50%' }}>
            <span className="text-[#D4AF37] text-lg font-serif">V</span>
          </div>
          <div className="flex flex-col select-none">
            <span className="font-mono text-[9px] text-[#D4AF37] tracking-[0.25em] uppercase font-bold leading-none">Challenger Suite</span>
            <h1 className="font-serif font-light text-xl text-[#E5E5E1] tracking-wider leading-none mt-1">KAWAII LOGIC</h1>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex gap-8 items-center">
          <button 
            onClick={() => onViewChange('home')}
            className={`font-mono text-[11px] tracking-[0.2em] uppercase transition-colors px-2 py-1.5 relative ${
              currentView === 'home' || currentView === 'character' || currentView === 'shiritori' || currentView === 'othello'
                ? 'text-[#D4AF37] border-b border-[#D4AF37] font-medium' 
                : 'text-[#E5E5E1]/60 hover:text-[#D4AF37]'
            }`}
          >
            Play Suite
          </button>
          <button 
            onClick={() => onViewChange('leaderboard')}
            className={`font-mono text-[11px] tracking-[0.2em] uppercase transition-colors px-2 py-1.5 relative ${
              currentView === 'leaderboard' 
                ? 'text-[#D4AF37] border-b border-[#D4AF37] font-medium' 
                : 'text-[#E5E5E1]/60 hover:text-[#D4AF37]'
            }`}
          >
            Stats & Rank
          </button>
          <button 
            onClick={() => onViewChange('rules')}
            className={`font-mono text-[11px] tracking-[0.2em] uppercase transition-colors px-2 py-1.5 relative ${
              currentView === 'rules' 
                ? 'text-[#D4AF37] border-b border-[#D4AF37] font-medium' 
                : 'text-[#E5E5E1]/60 hover:text-[#D4AF37]'
            }`}
          >
            How to Play
          </button>
        </nav>

        {/* User Stats / Config Quick Indicator */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex flex-col text-right">
            <span className="text-[#E5E5E1]/40 font-mono text-[9px] uppercase tracking-widest leading-none">Challenger</span>
            <span className="text-[#E5E5E1] font-serif font-light text-sm mt-0.5">{player1Name}</span>
          </div>
          <button 
            onClick={() => onViewChange('character')}
            className="w-10 h-10 rounded-full border border-white/20 hover:border-[#D4AF37] bg-white/5 hover:scale-105 active:scale-95 transition-all overflow-hidden flex items-center justify-center p-0.5"
            title="Choose Character"
          >
            <img 
              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${avatarSeed}&backgroundColor=050505`} 
              className="w-full h-full object-contain rounded-full" 
              alt={player1Name}
              referrerPolicy="no-referrer"
            />
          </button>
        </div>
      </header>

      {/* Floating Bottom Navigation Bar (Mobile Only) */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full flex justify-around items-center px-4 py-3 bg-[#050505]/95 backdrop-blur-lg border-t border-white/10 z-50 pb-safe shadow-[0_-4px_16px_rgba(0,0,0,0.8)]">
        <button 
          onClick={() => onViewChange('home')}
          className={`flex flex-col items-center justify-center transition-all ${
            currentView === 'home' || currentView === 'character' || currentView === 'shiritori' || currentView === 'othello'
              ? 'text-[#D4AF37] bg-white/5 px-4 py-1.5 rounded-lg scale-105' 
              : 'text-[#E5E5E1]/50 hover:text-[#D4AF37] p-2'
          }`}
        >
          <Home size={18} className={currentView === 'home' || currentView === 'character' || currentView === 'shiritori' || currentView === 'othello' ? 'stroke-[2]' : ''} />
          <span className="font-mono text-[9px] tracking-wider mt-1">Play</span>
        </button>

        <button 
          onClick={() => onViewChange('leaderboard')}
          className={`flex flex-col items-center justify-center transition-all ${
            currentView === 'leaderboard' 
              ? 'text-[#D4AF37] bg-white/5 px-4 py-1.5 rounded-lg scale-105' 
              : 'text-[#E5E5E1]/50 hover:text-[#D4AF37] p-2'
          }`}
        >
          <Trophy size={18} className={currentView === 'leaderboard' ? 'stroke-[2]' : ''} />
          <span className="font-mono text-[9px] tracking-wider mt-1">Rankings</span>
        </button>

        <button 
          onClick={() => onViewChange('rules')}
          className={`flex flex-col items-center justify-center transition-all ${
            currentView === 'rules' 
              ? 'text-[#D4AF37] bg-white/5 px-4 py-1.5 rounded-lg scale-105' 
              : 'text-[#E5E5E1]/50 hover:text-[#D4AF37] p-2'
          }`}
        >
          <BookOpen size={18} className={currentView === 'rules' ? 'stroke-[2]' : ''} />
          <span className="font-mono text-[9px] tracking-wider mt-1">Rules</span>
        </button>
      </nav>
    </>
  );
}

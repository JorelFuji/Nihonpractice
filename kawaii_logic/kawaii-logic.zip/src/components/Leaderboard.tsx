import { Gamepad2, Trophy, Award, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { ViewType, PlayerStats, LeaderboardEntry } from '../types';

interface LeaderboardProps {
  onViewChange: (view: ViewType) => void;
  playerStats: PlayerStats;
  player1Name: string;
  avatarSeed: string;
}

export default function Leaderboard({ onViewChange, playerStats, player1Name, avatarSeed }: LeaderboardProps) {
  const [loadMoreCount, setLoadMoreCount] = useState<number>(0);

  // Daily champions
  const dailyChampions = [
    {
      rank: 1,
      name: "Kenji_88",
      seed: "Kenji",
      color: "e9c400",
      chain: 42,
      mvp: true
    },
    {
      rank: 2,
      name: "Aiko.Neko",
      seed: "Aiko",
      color: "baeaff",
      chain: 39,
      mvp: false
    },
    {
      rank: 3,
      name: "Hiro_San",
      seed: "Hiro",
      color: "ffb4ab",
      chain: 35,
      mvp: false
    }
  ];

  // Base list of global rank entries
  const initialGlobalEntries: LeaderboardEntry[] = [
    { rank: 12401, name: "Satoshi_Vibe", avatarSeed: "SatoshiVibe", avatarColor: "914c00", score: 2850 },
    { rank: 12402, name: "MochiMaster", avatarSeed: "MochiMaster", avatarColor: "312ec5", score: 2842 },
    { rank: 12403, name: `${player1Name} (YOU)`, avatarSeed: avatarSeed, avatarColor: "ff8a00", score: 2839, isPlayer: true },
    { rank: 12404, name: "SakuraRunner", avatarSeed: "SakuraRunner", avatarColor: "ffb7c5", score: 2810 }
  ];

  // Mock extra rankings
  const extraRankings: LeaderboardEntry[] = [
    { rank: 12405, name: "KumaSensei", avatarSeed: "KumaSensei", avatarColor: "e9c400", score: 2795 },
    { rank: 12406, name: "NeonGamer", avatarSeed: "NeonGamer", avatarColor: "c1c1ff", score: 2780 },
    { rank: 12407, name: "TokyoGrid", avatarSeed: "TokyoGrid", avatarColor: "baeaff", score: 2765 },
    { rank: 12408, name: "OseroOtaku", avatarSeed: "OseroOtaku", avatarColor: "ffb4ab", score: 2750 }
  ];

  const currentGlobalEntries: LeaderboardEntry[] = [
    ...initialGlobalEntries,
    ...extraRankings.slice(0, loadMoreCount)
  ];

  return (
    <div className="space-y-16 pb-24">
      {/* Intro Header Section */}
      <section className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-3 pb-4 border-b border-white/10">
        <div>
          <span className="font-mono text-[9px] text-[#D4AF37] font-medium border-l border-[#D4AF37] pl-3 mb-2.5 block uppercase tracking-[0.25em]">
            Player Dashboard & Leaderboards / プレイヤー統計
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-light text-[#E5E5E1] tracking-wide uppercase mt-2">
            Stats & Rankings
          </h2>
        </div>
      </section>

      {/* User Stats Summary Layout */}
      <section className="space-y-4">
        <div className="flex items-center gap-3">
          <span className="font-mono text-[9px] text-[#D4AF37] tracking-[0.25em] font-medium uppercase">
            PLAYER_DATA
          </span>
          <div className="h-[1px] flex-grow bg-white/5"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Games Played Card */}
          <div className="bg-[#0a0a0a] border border-white/10 hover:border-[#D4AF37]/50 rounded-none p-8 relative overflow-hidden group select-none transition-all duration-300">
            <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <Gamepad2 size={44} className="text-[#D4AF37]" />
            </div>
            <div className="font-mono text-[9px] text-[#E5E5E1]/40 tracking-widest uppercase font-medium">Games Played</div>
            <div className="font-serif text-5xl font-light text-[#E5E5E1] mt-3">{playerStats.gamesPlayed}</div>
            <div className="font-mono text-[8px] text-[#D4AF37] font-bold tracking-[0.2em] uppercase mt-4 leading-none">TOP 5% GLOBALLY</div>
          </div>

          {/* Wins Card */}
          <div className="bg-[#0a0a0a] border border-white/10 hover:border-[#D4AF37]/50 rounded-none p-8 relative overflow-hidden group select-none transition-all duration-300">
            <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <Trophy size={44} className="text-[#D4AF37]" />
            </div>
            <div className="font-mono text-[9px] text-[#E5E5E1]/40 tracking-widest uppercase font-medium">Wins</div>
            <div className="font-serif text-5xl font-light text-[#E5E5E1] mt-3">{playerStats.wins}</div>
            <div className="font-mono text-[8px] text-[#E5E5E1]/50 tracking-[0.2em] font-bold uppercase mt-4 leading-none">Win Rate: {playerStats.winRate}%</div>
          </div>

          {/* Longest Word Card */}
          <div className="bg-[#0a0a0a] border border-white/10 hover:border-[#D4AF37]/50 rounded-none p-8 relative overflow-hidden group select-none transition-all duration-300">
            <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <Award size={44} className="text-[#D4AF37]" />
            </div>
            <div className="font-mono text-[9px] text-[#E5E5E1]/40 tracking-widest uppercase font-medium">Longest Shiritori Word</div>
            <h3 className="font-serif text-2xl font-light text-[#D4AF37] truncate mt-3 leading-tight">
              {playerStats.longestWord.jp || "—"}
            </h3>
            <div className="font-mono text-[8px] text-[#E5E5E1]/40 font-bold tracking-[0.2em] uppercase mt-4 leading-none">
              {playerStats.longestWord.en ? playerStats.longestWord.en.toUpperCase() : "NO SESSIONS LOGGED"}
            </div>
          </div>
        </div>
      </section>

      {/* Leaderboard Multi-column Section */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-12 pt-4">
        {/* Daily Champions Block */}
        <div className="space-y-6">
          <div className="flex justify-between items-end border-b border-white/10 pb-3">
            <div className="flex flex-col">
              <span className="font-mono text-[9px] text-[#D4AF37] tracking-[0.25em] font-medium uppercase">ACTIVE_SESSION</span>
              <h3 className="font-serif text-xl font-light text-[#E5E5E1]">Daily Champions</h3>
            </div>
            <span className="font-mono text-[9px] text-[#E5E5E1]/40 uppercase font-medium tracking-widest mb-1">
              RESET IN 14:22:01
            </span>
          </div>

          <div className="space-y-4">
            {dailyChampions.map((champ) => (
              <div 
                key={champ.rank} 
                className={`bg-[#0a0a0a] border border-white/10 hover:border-[#D4AF37]/40 transition-all rounded-none p-4 flex items-center gap-4 ${
                  champ.rank === 1 ? 'border-l-2 border-l-[#D4AF37]' : champ.rank === 2 ? 'border-l-2 border-l-white/40' : 'border-l-2 border-l-white/20'
                }`}
              >
                {/* Seed Rank */}
                <span className={`font-mono text-base font-light w-8 text-center ${
                  champ.rank === 1 ? 'text-[#D4AF37]' : 'text-[#E5E5E1]/70'
                }`}>
                  0{champ.rank}
                </span>

                {/* Avatar */}
                <div className="w-11 h-11 rounded-none border border-white/10 overflow-hidden shrink-0 bg-black">
                  <img 
                    alt={champ.name} 
                    className="w-full h-full object-contain grayscale brightness-90" 
                    src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${champ.seed}&backgroundColor=${champ.color}`}
                  />
                </div>

                {/* Details */}
                <div className="flex-grow">
                  <h4 className="font-serif font-light text-[#E5E5E1] text-md leading-tight">
                    {champ.name}
                  </h4>
                  <p className="font-mono text-[9px] text-[#E5E5E1]/40 tracking-wider mt-1">
                    CHAIN: {champ.chain} WORDS
                  </p>
                </div>

                {/* Tag */}
                {champ.mvp && (
                  <div className="px-2.5 py-1 bg-white/5 border border-[#D4AF37]/30 text-[#D4AF37] font-mono text-[8px] font-bold tracking-[0.2em] rounded-none shrink-0">
                    MVP
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Global Rankings List Block */}
        <div className="space-y-6">
          <div className="flex justify-between items-end border-b border-white/10 pb-3">
            <div className="flex flex-col">
              <span className="font-mono text-[9px] text-[#E5E5E1]/40 tracking-[0.25em] font-medium uppercase">WORLD_WIDE</span>
              <h3 className="font-serif text-xl font-light text-[#E5E5E1]">Global Rankings</h3>
            </div>
            <div className="flex bg-[#0a0a0a] border border-white/10 p-0.5 rounded-none">
              <span className="px-3 py-1 bg-[#E5E5E1] text-black font-mono text-[9px] font-bold tracking-wider rounded-none">
                ALL TIME
              </span>
              <span className="px-3 py-1 text-[#E5E5E1]/40 font-mono text-[9px] font-bold tracking-wider">
                MONTHLY
              </span>
            </div>
          </div>

          <div className="space-y-2.5">
            {currentGlobalEntries.map((entry) => (
              <div 
                key={entry.rank} 
                className={`flex items-center px-4 py-3 border transition-all duration-200 ${
                  entry.isPlayer 
                    ? 'bg-[#E5E5E1]/5 border-[#D4AF37] rounded-none shadow-[inset_0_1px_12px_rgba(212,175,55,0.05)]' 
                    : 'bg-[#0a0a0a] border-white/10 rounded-none'
                }`}
              >
                <span className={`font-mono text-[9px] w-12 shrink-0 ${entry.isPlayer ? 'text-[#D4AF37] font-medium' : 'text-[#E5E5E1]/40'}`}>
                  {entry.rank.toLocaleString()}
                </span>

                <div className={`w-8 h-8 rounded-none border overflow-hidden mr-3 shrink-0 ${entry.isPlayer ? 'border-[#D4AF37]' : 'border-white/10'}`}>
                  <img 
                    alt={entry.name} 
                    className="w-full h-full object-contain bg-black grayscale" 
                    src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${entry.avatarSeed}&backgroundColor=${entry.avatarColor}`}
                  />
                </div>

                <div className={`flex-grow font-serif font-light truncate text-sm ${entry.isPlayer ? 'text-[#E5E5E1] font-normal' : 'text-[#E5E5E1]/70'}`}>
                  {entry.name}
                </div>

                <div className={`font-mono text-[10px] font-medium text-right shrink-0 ${entry.isPlayer ? 'text-[#D4AF37]' : 'text-[#E5E5E1]/60'}`}>
                  {entry.score.toLocaleString()} PTS
                </div>
              </div>
            ))}
          </div>

          <button 
            disabled={loadMoreCount >= extraRankings.length}
            onClick={() => setLoadMoreCount((prev) => Math.min(prev + 2, extraRankings.length))}
            className="w-full py-4 text-center border border-white/15 bg-transparent hover:border-white text-[#E5E5E1] active:translate-y-[1px] font-mono text-[10px] font-bold tracking-[0.25em] uppercase transition-all rounded-none disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
          >
            {loadMoreCount >= extraRankings.length ? "No More Entries" : "LOAD MORE RANKINGS"}
          </button>
        </div>
      </section>
    </div>
  );
}

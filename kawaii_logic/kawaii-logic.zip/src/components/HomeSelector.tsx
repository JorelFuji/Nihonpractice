import { Flame, Play, ShieldAlert, Cpu, CheckCircle2, Zap, HelpCircle } from 'lucide-react';
import { ViewType } from '../types';

interface HomeSelectorProps {
  onViewChange: (view: ViewType) => void;
  playerStats: {
    gamesPlayed: number;
    wins: number;
    winRate: number;
  };
}

export default function HomeSelector({ onViewChange, playerStats }: HomeSelectorProps) {
  return (
    <div className="space-y-16 pb-16">
      {/* Intro Header Section */}
      <section className="text-center md:text-left space-y-3 mt-4">
        <p className="font-mono text-[10px] text-[#D4AF37] uppercase tracking-[0.3em] leading-none font-medium">
          Choose Your Suite Challenge / あなたのゲームを選んでください
        </p>
        <h2 className="font-serif text-4xl md:text-5xl font-light text-[#E5E5E1] tracking-wide leading-tight flex items-center justify-center md:justify-start gap-4">
          <span>ゲームを選ぶ / Select Suite</span>
        </h2>
        <div className="h-[1px] w-24 bg-[#D4AF37]/40 mx-auto md:mx-0"></div>
      </section>

      {/* Game Selection Cards GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Shiritori Card (Gold Sophisticated Theme) */}
        <div className="group relative bg-[#0a0a0a] border border-white/10 hover:border-[#D4AF37]/50 rounded-lg p-8 shadow-2xl transition-all hover:-translate-y-1 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-6">
              <div className="border border-[#D4AF37] text-[#D4AF37] px-3 py-0.5 rounded-none font-mono text-[9px] font-bold tracking-[0.25em] flex items-center gap-1.5 uppercase bg-transparent">
                <Flame size={10} className="stroke-[2.5]" /> POPULAR
              </div>
              <span className="font-mono text-[10px] text-[#E5E5E1]/30 tracking-widest">SH-01</span>
            </div>

            <div className="flex items-center gap-5 mb-6">
              <div className="w-16 h-16 rounded-none border border-white/10 group-hover:border-[#D4AF37]/40 flex items-center justify-center bg-white/5 transition-all shadow-inner">
                <span className="text-2xl">🐉</span>
              </div>
              <div>
                <h3 className="font-serif text-3xl font-light text-[#E5E5E1] tracking-wide">しりとり</h3>
                <p className="font-mono text-[10px] text-[#D4AF37] font-medium uppercase tracking-[0.25em] mt-0.5">Word Chain Battle</p>
              </div>
            </div>

            <p className="text-[#E5E5E1]/70 text-sm md:text-base font-light leading-relaxed border-b border-white/5 pb-4 mb-4">
              Classical Japanese word chain discipline, where each word must start with the final mora of the opponent's previous word. <br/>
              <span className="text-[#E5E5E1]/40 text-xs block mt-1.5">前の言葉の最後の音で始まる言葉を繋げます。</span>
            </p>

            <ul className="space-y-2.5 mb-8">
              <li className="flex items-center gap-2.5 text-xs text-[#E5E5E1]/80 font-light">
                <span className="text-[#D4AF37] text-[10px]">■</span> AI opponent with adaptive heuristic difficulty
              </li>
              <li className="flex items-center gap-2.5 text-xs text-[#E5E5E1]/80 font-light">
                <span className="text-[#D4AF37] text-[10px]">■</span> Real-time conversational romaji-to-hiragana system
              </li>
              <li className="flex items-center gap-2.5 text-xs text-[#E5E5E1]/80 font-light">
                <span className="text-[#D4AF37] text-[10px]">■</span> Synchronized visual circular timer HUD
              </li>
            </ul>
          </div>

          <button 
            onClick={() => onViewChange('shiritori')}
            className="w-full bg-[#E5E5E1] hover:bg-[#D4AF37] text-black py-4 rounded-none font-mono text-[10px] font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            Enter Game <Play size={10} fill="currentColor" />
          </button>
        </div>

        {/* Othello Card (Silver/Grey Sophisticated Theme) */}
        <div className="group relative bg-[#0a0a0a] border border-white/10 hover:border-white/40 rounded-lg p-8 shadow-2xl transition-all hover:-translate-y-1 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-6">
              <div className="border border-white/20 text-[#E5E5E1]/60 px-3 py-0.5 rounded-none font-mono text-[9px] font-bold tracking-[0.25em] flex items-center gap-1.5 uppercase bg-transparent">
                <ShieldAlert size={10} className="stroke-[2.5]" /> STRATEGY
              </div>
              <span className="font-mono text-[10px] text-[#E5E5E1]/30 tracking-widest">OT-02</span>
            </div>

            <div className="flex items-center gap-5 mb-6">
              <div className="w-16 h-16 rounded-none border border-white/10 group-hover:border-white/35 flex items-center justify-center bg-white/5 transition-all shadow-inner">
                <span className="text-2xl">🧩</span>
              </div>
              <div>
                <h3 className="font-serif text-3xl font-light text-[#E5E5E1] tracking-wide">オセロ</h3>
                <p className="font-mono text-[10px] text-white/50 font-medium uppercase tracking-[0.25em] mt-0.5">Strategic Board Game</p>
              </div>
            </div>

            <p className="text-[#E5E5E1]/70 text-sm md:text-base font-light leading-relaxed border-b border-white/5 pb-4 mb-4">
              Elegantly simulated board match, capturing opponent's positions on a crisp 8x8 matrix by flanking active markers. <br/>
              <span className="text-[#E5E5E1]/40 text-xs block mt-1.5">相手の石を挟んでひっくり返す戦略ボードゲーム。</span>
            </p>

            <ul className="space-y-2.5 mb-8">
              <li className="flex items-center gap-2.5 text-xs text-[#E5E5E1]/80 font-light">
                <span className="text-[#E5E5E1]/60 text-[10px]">■</span> Interactive high-contrast viewport simulation
              </li>
              <li className="flex items-center gap-2.5 text-xs text-[#E5E5E1]/80 font-light">
                <span className="text-[#E5E5E1]/60 text-[10px]">■</span> Precise active-location ghost indicators
              </li>
              <li className="flex items-center gap-2.5 text-xs text-[#E5E5E1]/80 font-light">
                <span className="text-[#E5E5E1]/60 text-[10px]">■</span> Intelligent local engine with instant prediction loops
              </li>
            </ul>
          </div>

          <button 
            onClick={() => onViewChange('othello')}
            className="w-full bg-[#E5E5E1] hover:bg-white/90 text-black py-4 rounded-none font-mono text-[10px] font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            Enter Game <Cpu size={11} />
          </button>
        </div>
      </div>

      {/* Quick Access Action Trigger */}
      <div className="flex flex-col items-center pt-4">
        <button 
          onClick={() => {
            const nextView = Math.random() > 0.5 ? 'shiritori' : 'othello';
            onViewChange(nextView);
          }}
          className="px-10 py-4 border border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black font-mono tracking-[0.25em] uppercase text-xs flex items-center gap-3 transition-colors cursor-pointer bg-transparent"
        >
          <Zap size={12} fill="currentColor" className="stroke-[2.5]" />
          Quick Random Start
        </button>
      </div>

      {/* Elegant About Section */}
      <section className="pt-12 border-t border-white/10 flex flex-col md:flex-row gap-10 items-center">
        <div className="w-full md:w-1/3 h-56 border border-white/10 relative overflow-hidden group">
          <img 
            alt="High-tech classroom console" 
            className="w-full h-full object-cover grayscale opacity-50 transition-all duration-500 group-hover:scale-105 group-hover:grayscale-0 group-hover:opacity-100" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuADZ3_psL0dBwPj53466Jk4xs57SVRGRVhtPpNLe2vpLinGf0Tiz_e0cKKxeDehGSZ7dflaXlt-bgcnx-DqrVayu_-5zVByRqgK25psLmn_OxCRMm89yJfAKf2SVn7YUO5aHUVEEq291SJhXEZc6Z1s67j1wnBiiQ5WkQStcPNvLCgP8RodgfQPS7WGaUV86EVxr3SPiCiaa_SiJae23EXP9-7eEibyqb_DRfDG99xu_z0gpMqPCOTfbztc2aMcopj3KwJg8io2HIZ4"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-[#D4AF37]/5 mix-blend-overlay"></div>
        </div>
        
        <div className="w-full md:w-2/3 space-y-4">
          <h4 className="font-serif text-2xl font-light text-[#D4AF37] flex items-center gap-2.5">
            <HelpCircle size={18} /> About Kawaii Logic
          </h4>
          <p className="text-sm md:text-base text-[#E5E5E1]/80 leading-relaxed font-light">
            しりとり (Shiritori) is a classic Japanese word game perfect for learning vocabulary, building associations, and having fun! 
            オセロ (Osero) is the standard Japanese name for Othello/Reversi board strategy. Both games train your cognitive skills and Japanese kana recall simultaneously.
          </p>
          <div className="bg-white/5 p-4 rounded-none border-l-2 border-[#D4AF37] font-mono text-xs md:text-sm text-[#E5E5E1]/90 italic font-light">
            💡 Useful phrase: 「オセロをしましょう。」 (Osero o shimashō) - &quot;Let&apos;s play Othello.&quot;
          </div>
        </div>
      </section>

      {/* Stats Summary Panel */}
      <section className="bg-[#0a0a0a] rounded-none p-8 border border-white/15 flex flex-col sm:flex-row justify-around items-center gap-8">
        <div className="text-center">
          <p className="text-[10px] text-[#E5E5E1]/40 uppercase tracking-[0.25em] font-mono font-medium">Games Played</p>
          <p className="font-serif font-light text-4xl text-[#E5E5E1] mt-1.5">{playerStats.gamesPlayed}</p>
        </div>
        <div className="w-[1px] h-10 bg-white/10 hidden sm:block"></div>
        <div className="text-center">
          <p className="text-[10px] text-[#E5E5E1]/40 uppercase tracking-[0.25em] font-mono font-medium">Wins Logged</p>
          <p className="font-serif font-light text-4xl text-[#E5E5E1] mt-1.5">{playerStats.wins}</p>
        </div>
        <div className="w-[1px] h-10 bg-white/10 hidden sm:block"></div>
        <div className="text-center">
          <p className="text-[10px] text-[#E5E5E1]/40 uppercase tracking-[0.25em] font-mono font-medium">Overall Win Rate</p>
          <p className="font-serif font-light text-4xl text-[#D4AF37] mt-1.5">{playerStats.winRate}%</p>
        </div>
      </section>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { HelpCircle, RefreshCw, Info, Flame, AlertCircle, Trophy, Volume2, Timer } from 'lucide-react';
import { Character, ViewType } from '../types';

interface OthelloGameProps {
  onViewChange: (view: ViewType) => void;
  selectedChar: Character;
  onGameWon: () => void;
}

export type PlayerColor = 'pink' | 'blue'; // Pink is Sakura disk, Blue is Sky disk
export type CellState = PlayerColor | null;

export default function OthelloGame({ onViewChange, selectedChar, onGameWon }: OthelloGameProps) {
  // Othello board state is represented as a size x size dual array
  const SIZE = 8;
  const [board, setBoard] = useState<CellState[][]>([]);
  const [activePlayer, setActivePlayer] = useState<PlayerColor>('pink'); // Player starts as Pink
  const [scores, setScores] = useState<{ pink: number; blue: number }>({ pink: 2, blue: 2 });
  const [turnCount, setTurnCount] = useState<number>(4); // Out of 64
  const [validMoves, setValidMoves] = useState<[number, number][]>([]);
  const [isCpuMatch, setIsCpuMatch] = useState<boolean>(true); // Play vs local smart AI!
  const [gameResult, setGameResult] = useState<string | null>(null);
  const [p1Time, setP1Time] = useState<number>(342); // 05:42 in seconds
  const [p2Time, setP2Time] = useState<number>(255); // 04:15 in seconds
  const [sysLog, setSysLog] = useState<string>("Match started! Pink to move. Control corners!");

  // Initialize board on load
  const resetMatch = () => {
    const newBoard: CellState[][] = Array(SIZE).fill(null).map(() => Array(SIZE).fill(null));
    
    // Four center starting squares
    newBoard[3][3] = 'pink';
    newBoard[3][4] = 'blue';
    newBoard[4][3] = 'blue';
    newBoard[4][4] = 'pink';
    
    setBoard(newBoard);
    setActivePlayer('pink');
    setScores({ pink: 2, blue: 2 });
    setTurnCount(4);
    setGameResult(null);
    setP1Time(342);
    setP2Time(255);
    setSysLog("Game initialized. Control the corners for permanent captures!");
  };

  useEffect(() => {
    resetMatch();
  }, []);

  // Recalculate valid moves whenever board or activePlayer updates
  useEffect(() => {
    if (board.length === 0 || gameResult) return;

    const moves = getAvailableMoves(board, activePlayer);
    setValidMoves(moves);

    // Turn transition skip check
    if (moves.length === 0) {
      // Check if opponent has moves
      const opponentColor = activePlayer === 'pink' ? 'blue' : 'pink';
      const opponentMoves = getAvailableMoves(board, opponentColor);
      
      if (opponentMoves.length === 0) {
        // Both players are stuck - game terminates!
        determineWinner();
      } else {
        // Active player must skip their turn
        setSysLog(`No valid moves for ${activePlayer.toUpperCase()}! Skipping turn.`);
        setActivePlayer(opponentColor);
      }
    }
  }, [board, activePlayer, gameResult]);

  // CPU move trigger
  useEffect(() => {
    if (gameResult || !isCpuMatch || activePlayer !== 'blue' || board.length === 0) return;

    // Simulate CPU thinking state
    const timer = setTimeout(() => {
      handleCpuMove();
    }, 1200);

    return () => clearTimeout(timer);
  }, [board, activePlayer, isCpuMatch, gameResult]);

  // Game timer ticking
  useEffect(() => {
    if (gameResult) return;

    const interval = setInterval(() => {
      if (activePlayer === 'pink') {
        setP1Time((t) => t + 1);
      } else {
        setP2Time((t) => t + 1);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [activePlayer, gameResult]);

  // Format second counts to mm:ss
  const formatTime = (secs: number): string => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  // Helper Othello algorithms: Checks traps in 8 compass directions
  const directions = [
    [-1, -1], [-1,  0], [-1,  1],
    [ 0, -1],           [ 0,  1],
    [ 1, -1], [ 1,  0], [ 1,  1]
  ];

  const getAvailableMoves = (currentBoard: CellState[][], player: PlayerColor): [number, number][] => {
    const valid: [number, number][] = [];
    
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (currentBoard[r][c] !== null) continue;
        if (checkMoveValidity(currentBoard, r, c, player).length > 0) {
          valid.push([r, c]);
        }
      }
    }
    
    return valid;
  };

  // Traverses and returns all opponent discs that will be flipped by placing a token at (r, c)
  const checkMoveValidity = (currentBoard: CellState[][], r: number, c: number, player: PlayerColor): [number, number][] => {
    const cellsToFlip: [number, number][] = [];
    const opponent = player === 'pink' ? 'blue' : 'pink';

    for (const [dr, dc] of directions) {
      let row = r + dr;
      let col = c + dc;
      let tempFlips: [number, number][] = [];

      while (row >= 0 && row < SIZE && col >= 0 && col < SIZE && currentBoard[row][col] === opponent) {
        tempFlips.push([row, col]);
        row += dr;
        col += dc;
      }

      // Check if closed/capped by active player's color
      if (row >= 0 && row < SIZE && col >= 0 && col < SIZE && currentBoard[row][col] === player) {
        cellsToFlip.push(...tempFlips);
      }
    }

    return cellsToFlip;
  };

  // Place player disk
  const makeMove = (r: number, c: number) => {
    if (gameResult || activePlayer !== 'pink' && isCpuMatch) return;

    const flips = checkMoveValidity(board, r, c, activePlayer);
    if (flips.length === 0) return; // Invalid cell clicked

    executeMove(r, c, flips, activePlayer);
  };

  const executeMove = (r: number, c: number, flips: [number, number][], player: PlayerColor) => {
    const nextBoard = board.map(row => [...row]);
    
    // Place disc
    nextBoard[r][c] = player;
    
    // Flip captured ones
    flips.forEach(([fr, fc]) => {
      nextBoard[fr][fc] = player;
    });

    // Recalculate scores and turn levels
    let pinkCount = 0;
    let blueCount = 0;

    for (let row = 0; row < SIZE; row++) {
      for (let col = 0; col < SIZE; col++) {
        if (nextBoard[row][col] === 'pink') pinkCount++;
        if (nextBoard[row][col] === 'blue') blueCount++;
      }
    }

    setBoard(nextBoard);
    setScores({ pink: pinkCount, blue: blueCount });
    setTurnCount((prev) => prev + 1);

    const nextPlayer = player === 'pink' ? 'blue' : 'pink';
    setActivePlayer(nextPlayer);

    // Syslog
    setSysLog(`${player.toUpperCase()} placed token at ${String.fromCharCode(65 + r)}${c + 1}, capturing ${flips.length} opponent disk(s).`);
  };

  // AI choice algorithm
  const handleCpuMove = () => {
    const moves = getAvailableMoves(board, 'blue');
    if (moves.length === 0) return;

    // Corner heuristic weight bonus (Corners are permanent in Othello!)
    const corners = [
      [0, 0], [0, SIZE - 1],
      [SIZE - 1, 0], [SIZE - 1, SIZE - 1]
    ];

    let chosenMove: [number, number];

    // Priority 1: Pick corners if they are valid moves
    const validCorners = moves.filter(([r, c]) => 
      corners.some(([cr, cc]) => cr === r && cc === c)
    );

    if (validCorners.length > 0) {
      chosenMove = validCorners[0];
    } else {
      // Priority 2: Pick the move that captures the maximum amount of disks
      let maxFlips = -1;
      let worstCornerProximityMove: [number, number] | null = null;
      let absoluteBestMove: [number, number] = moves[0];

      // Avoid squares adjacent to corners (X-squares and C-squares) because they let the player take the corners easily!
      const dangerousCells = [
        [0, 1], [1, 0], [1, 1],
        [0, SIZE - 2], [1, SIZE - 1], [1, SIZE - 2],
        [SIZE - 2, 0], [SIZE - 1, 1], [SIZE - 2, 1],
        [SIZE - 2, SIZE - 1], [SIZE - 1, SIZE - 2], [SIZE - 2, SIZE - 2]
      ];

      const safeMoves = moves.filter(([r, c]) => 
        !dangerousCells.some(([dr, dc]) => dr === r && dc === c)
      );

      const candidateMoves = safeMoves.length > 0 ? safeMoves : moves;

      candidateMoves.forEach(([r, c]) => {
        const flips = checkMoveValidity(board, r, c, 'blue');
        if (flips.length > maxFlips) {
          maxFlips = flips.length;
          chosenMove = [r, c];
        }
      });
      
      chosenMove = chosenMove! || moves[0];
    }

    const flips = checkMoveValidity(board, chosenMove[0], chosenMove[1], 'blue');
    executeMove(chosenMove[0], chosenMove[1], flips, 'blue');
  };

  // Scoring tally of total winner
  const determineWinner = () => {
    let victorStr = "";
    if (scores.pink > scores.blue) {
      victorStr = `VICTORY! You won with ${scores.pink} discs against ${scores.blue}!`;
      onGameWon(); // Triggers global app stats win!
    } else if (scores.blue > scores.pink) {
      victorStr = `DEFEAT! CPU won with ${scores.blue} discs. Try control the corners early next match!`;
    } else {
      victorStr = `TIE MATCH! Both matched equally at ${scores.pink} discs! Outstanding defense.`;
    }

    setGameResult(victorStr);
    setSysLog(`Match terminated. ${victorStr}`);
  };

  // Forfeit Match Click
  const handleForfeit = () => {
    setGameResult(`FORFEIT! Blue wins. Keep training!`);
    setSysLog("Match forfeited. Keep practicing on the grid.");
  };

  return (
    <div className="space-y-8 pb-24 max-w-5xl mx-auto">
      {/* Othello Gameplay Header Section */}
      <section className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-3 pb-4 border-b border-white/10">
        <div>
          <span className="font-mono text-[9px] text-[#D4AF37] font-bold uppercase tracking-[0.25em] leading-none">
            STRATEGIC BOARD MATCH • MINIGAME
          </span>
          <h2 className="font-serif text-3xl font-light text-[#E5E5E1] tracking-wide mt-1 flex items-center gap-2">
            <span>オセロ Othello Arena</span>
          </h2>
        </div>
        <div className="flex gap-2 shrink-0">
          <button 
            onClick={resetMatch}
            className="flex items-center gap-2 px-5 py-2.5 border border-white/15 bg-transparent hover:border-white hover:text-white rounded-none text-[10px] font-mono font-bold tracking-[0.2em] transition-all select-none cursor-pointer"
          >
            <RefreshCw size={10} /> RESET BOARD
          </button>
        </div>
      </section>

      {/* Grid system matching layouts */}
      <div className="flex flex-col lg:flex-row gap-8 items-start justify-center">
        
        {/* Left score panel Column */}
        <aside className="w-full lg:w-64 flex flex-col gap-6 shrink-0">
          {/* Active Player (YOU) Sakura disc */}
          <div className={`p-5 border bg-[#0a0a0a] relative transition-all duration-300 rounded-none ${
            activePlayer === 'pink' ? 'border-[#D4AF37] shadow-[inset_0_1px_12px_rgba(212,175,55,0.05)]' : 'border-white/10 opacity-60'
          }`}>
            <div className="flex justify-between items-start mb-3">
              <span className="font-mono text-[8px] text-[#D4AF37] font-bold uppercase tracking-[0.15em]">SAKURA TOKEN (YOU)</span>
              {activePlayer === 'pink' && (
                <span className="font-mono text-[7px] bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 px-1.5 py-0.5 rounded-none font-bold tracking-widest">ACTIVE</span>
              )}
            </div>
            
            <div className="flex items-baseline gap-1.5 mt-2">
              <span className="font-serif text-3.5xl font-light text-[#E5E5E1]">{scores.pink}</span>
              <span className="font-mono text-[9px] text-[#E5E5E1]/40 uppercase tracking-wider">DISCS ON GRID</span>
            </div>

            <div className="mt-4 h-[1px] bg-white/5 w-full overflow-hidden">
              <div className="h-full bg-[#D4AF37]" style={{ width: `${(scores.pink / 64) * 100}%` }}></div>
            </div>

            <div className="mt-4 flex items-center gap-2 text-[#E5E5E1]/65">
              <Timer size={12} className="text-[#D4AF37]" />
              <span className="font-mono text-xs font-semibold">{formatTime(p1Time)}</span>
            </div>
          </div>

          {/* Player_Sky (Blue disk) CPU */}
          <div className={`p-5 border bg-[#0a0a0a] relative transition-all duration-300 rounded-none ${
            activePlayer === 'blue' ? 'border-[#D4AF37] shadow-[inset_0_1px_12px_rgba(212,175,55,0.05)]' : 'border-white/10 opacity-60'
          }`}>
            <div className="flex justify-between items-start mb-3">
              <span className="font-mono text-[8px] text-white/50 font-bold uppercase tracking-[0.15em]">SKY TOKEN (SENSEI)</span>
              {activePlayer === 'blue' && (
                <span className="font-mono text-[7px] bg-white/5 text-white/60 border border-white/20 px-1.5 py-0.5 rounded-none font-bold tracking-widest animate-pulse">THINKING</span>
              )}
            </div>
            
            <div className="flex items-baseline gap-1.5 mt-2">
              <span className="font-serif text-3.5xl font-light text-[#E5E5E1]">{scores.blue}</span>
              <span className="font-mono text-[9px] text-[#E5E5E1]/40 uppercase tracking-wider">DISCS ON GRID</span>
            </div>

            <div className="mt-4 h-[1px] bg-white/5 w-full overflow-hidden">
              <div className="h-full bg-[#E5E5E1]/50" style={{ width: `${(scores.blue / 64) * 100}%` }}></div>
            </div>

            <div className="mt-4 flex items-center gap-2 text-[#E5E5E1]/65">
              <Timer size={12} className="text-white/45" />
              <span className="font-mono text-xs font-semibold">{formatTime(p2Time)}</span>
            </div>
          </div>

          {/* Session Details */}
          <div className="p-5 rounded-none border border-white/10 bg-black font-light text-[#E5E5E1]/70 select-none">
            <h3 className="font-mono text-[8px] text-[#D4AF37] mb-3 tracking-[0.2em] uppercase">
              ⚙️ SESSION SPEC
            </h3>
            <div className="grid grid-cols-2 gap-4 text-xs font-light">
              <div>
                <p className="font-mono text-[8.5px] text-white/30 uppercase tracking-wider font-bold">MODE</p>
                <p className="font-serif text-[#E5E5E1]/90 mt-1 font-light">VS CPU SENSEI</p>
              </div>
              <div>
                <p className="font-mono text-[8.5px] text-white/30 uppercase tracking-wider font-bold">GRID RATIO</p>
                <p className="font-serif text-[#E5E5E1]/90 mt-1 font-light">{turnCount} / 64</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Center Game Board Column */}
        <section className="flex flex-col items-center">
          
          {/* Game Over Victor Overlay Modal */}
          {gameResult && (
            <div className="w-full bg-[#0a0a0a]/95 border border-[#D4AF37] p-8 rounded-none text-center space-y-5 shadow-2xl relative mb-6">
              <h3 className="font-serif text-2xl font-light text-[#E5E5E1] tracking-wide">MATCH COMPLETED</h3>
              <p className="text-sm font-light max-w-sm mx-auto text-[#E5E5E1]/70 leading-relaxed font-sans">
                {gameResult}
              </p>
              <div className="flex gap-4 justify-center">
                <button 
                  onClick={resetMatch}
                  className="bg-[#D4AF37] hover:bg-white text-black font-mono text-[10px] uppercase font-bold tracking-widest px-6 py-3 rounded-none transition-colors duration-150 cursor-pointer"
                >
                  Restart Battle
                </button>
                <button 
                  onClick={() => onViewChange('home')}
                  className="border border-white/20 bg-transparent text-[#E5E5E1] hover:border-white font-mono text-[10px] uppercase font-bold tracking-widest px-6 py-3 rounded-none transition-all duration-150 cursor-pointer"
                >
                  Back to Select
                </button>
              </div>
            </div>
          )}

          {/* Board Container with Letters (A to H) and Numbers (1 to 8) coordinate handles! */}
          <div className="relative bg-black border border-white/10 rounded-none p-4 md:p-6 shadow-2xl">
            {/* Numbers header */}
            <div className="absolute top-1 left-9 right-4 flex justify-between select-none pointer-events-none text-[8px] font-mono font-medium tracking-wide text-white/25 hidden md:flex">
              <span>col 1</span>
              <span>col 2</span>
              <span>col 3</span>
              <span>col 4</span>
              <span>col 5</span>
              <span>col 6</span>
              <span>col 7</span>
              <span>col 8</span>
            </div>

            {/* Corner visual code hex */}
            <span className="absolute top-1 right-3 text-[8px] font-mono font-bold text-white/10 hidden sm:block">0x00A1</span>

            <div className="grid grid-cols-8 gap-1.5 md:gap-2 bg-[#050505] p-2.5 rounded-none border border-white/5 relative">
              {board.map((row, rIdx) => 
                row.map((cell, cIdx) => {
                  const isValid = validMoves.some(([vr, vc]) => vr === rIdx && vc === cIdx);
                  const isPink = cell === 'pink';
                  
                  return (
                    <div 
                      key={`${rIdx}-${cIdx}`}
                      onClick={() => isValid && makeMove(rIdx, cIdx)}
                      className={`w-9 h-9 md:w-14 md:h-14 rounded-none flex items-center justify-center relative border border-white/5 transition-all duration-300 select-none ${
                        isValid 
                          ? 'bg-[#D4AF37]/5 border-[#D4AF37]/35 cursor-pointer hover:bg-[#D4AF37]/15' 
                          : 'bg-[#0e0e0e]'
                      }`}
                    >
                      {/* Place physical Disk inside */}
                      {cell && (
                        <div 
                          className={`w-8 h-8 md:w-11 md:h-11 rounded-none scale-100 transition-all duration-500 flex items-center justify-center ${
                            isPink 
                              ? 'bg-[#D4AF37] text-black border border-[#D4AF37]/60 shadow-[3px_3px_12px_rgba(212,175,55,0.15)]' 
                              : 'bg-[#222222] border border-white/15 text-white shadow-[3px_3px_12px_rgba(0,0,0,0.5)]'
                          }`}
                        >
                          <div className="w-1.5 h-1.5 border border-black/10 rounded-full opacity-35 bg-white/25"></div>
                        </div>
                      )}

                      {/* Display Ghost placement disk if move is valid */}
                      {isValid && !cell && (
                        <div className="w-3.5 h-3.5 md:w-5 md:h-5 rounded-none border border-[#D4AF37]/50 opacity-40 animate-pulse pointer-events-none"></div>
                      )}

                      {/* Letter marker for row on leftmost cell only */}
                      {cIdx === 0 && (
                        <span className="absolute -left-4 text-[9px] font-mono font-bold text-white/20 pointer-events-none select-none">
                          {String.fromCharCode(65 + rIdx)}
                        </span>
                      )}
                      {/* Number marker for col on top row only */}
                      {rIdx === 0 && (
                        <span className="absolute -top-4 text-[9px] font-mono font-bold text-white/20 pointer-events-none select-none">
                          {cIdx + 1}
                        </span>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* System event Log status report */}
          <div className="w-full max-w-md mt-6 text-center">
            <span className="font-mono text-[9px] text-[#D4AF37] uppercase tracking-[0.2em] font-medium block">ARENA FEEDBACK FEED</span>
            <p className="font-sans text-xs text-[#E5E5E1]/70 font-light mt-1 leading-snug">
              {sysLog}
            </p>
          </div>
        </section>

        {/* Right Rules of Play panel Column */}
        <aside className="w-full lg:w-80 flex flex-col gap-6 shrink-0">
          <div className="p-6 bg-[#0a0a0a] border border-white/10 shadow-lg rounded-none space-y-6">
            <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/10">
              <span className="text-[#D4AF37] text-lg">✦</span>
              <h4 className="font-serif font-light text-[#E5E5E1] text-lg">Rules of Play</h4>
            </div>

            <div className="space-y-4 font-light text-[#E5E5E1]/75">
              <div className="flex gap-3 items-start">
                <div className="w-6 h-6 rounded-none bg-white/5 border border-white/10 flex items-center justify-center font-mono text-[#D4AF37] text-xs font-bold shrink-0">
                  01
                </div>
                <p className="text-xs leading-relaxed font-sans mt-0.5">
                  Surround enemy tokens horizontally, vertically, or diagonally to trap and isolate.
                </p>
              </div>

              <div className="flex gap-3 items-start">
                <div className="w-6 h-6 rounded-none bg-[#D4AF37]/5 border border-[#D4AF37]/35 flex items-center justify-center font-mono text-[#D4AF37] text-xs font-bold shrink-0">
                  02
                </div>
                <p className="text-xs leading-relaxed font-sans mt-0.5">
                  Captured enemy disks flip to your active color instantly, shifting control.
                </p>
              </div>
            </div>

            <button 
              onClick={handleForfeit}
              disabled={!!gameResult}
              className="mt-4 w-full py-4 bg-transparent border border-white/15 text-[#E5E5E1] hover:bg-white hover:text-black hover:border-white font-mono text-xs uppercase font-bold tracking-wider rounded-none transition-all disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
            >
              FORFEIT MATCH 🏳️
            </button>
          </div>

          {/* Tip container */}
          <div className="p-5 rounded-none border border-[#D4AF37]/30 bg-black relative select-none">
            <p className="font-mono text-[8px] text-[#D4AF37] font-bold uppercase tracking-[0.2em] mb-1">SECRET TACTIC</p>
            <p className="font-serif text-xs text-[#E5E5E1]/80 italic leading-relaxed font-light">
              &quot;Corner tiles are permanent captures. Claim them early to dominate the board perimeter!&quot;
            </p>
          </div>
        </aside>

      </div>
    </div>
  );
}

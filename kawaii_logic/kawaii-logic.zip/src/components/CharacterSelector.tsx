import { Award, Grid, Swords, Settings2 } from 'lucide-react';
import { Character, ViewType } from '../types';
import { charactersList } from '../dictionary';

interface CharacterSelectorProps {
  onViewChange: (view: ViewType) => void;
  selectedChar: Character;
  onSelectChar: (char: Character) => void;
}

export default function CharacterSelector({ onViewChange, selectedChar, onSelectChar }: CharacterSelectorProps) {

  // For CPU, we pick "Miku" (id: 2) as default, but we can change it if Player 1 chooses Miku!
  const cpuChar = selectedChar.id === 2 ? charactersList[0] : charactersList[1];

  const handleCharacterClick = (char: Character) => {
    onSelectChar(char);
  };

  // Decide display image source for player 
  const getPlayerImage = (id: number, seed: string, color: string) => {
    if (id === 1) { // Satoshi
      return "https://lh3.googleusercontent.com/aida-public/AB6AXuCUn3gdLGlpCx1coteFU-gHETMmfN77CywTCNvppwULqmYcTyv8PDg5i-YM6vcj0hpv7PZYCftU1XzySTL7hs4kcKqa3ZstytZo5oaI3rz-0KDkdl0AMtfLz0hDccwrlHwf95SQXAOckA-21L_61hkJQJdnrQ3jXBTiE912_XDslQOHlbTo4CWqzShAH2W2M2sT_VpBqa7nwgrpr_rmMXrdxN8-kYIpyevRSFMU4YG5L1PN8hBeneGXzT2kqZK-SnQffP_ijKN6AetR";
    }
    if (id === 2) { // Miku
      return "https://lh3.googleusercontent.com/aida-public/AB6AXuC5OWLOBoeBsUFHQvIWBX3CjaIDnJMmlsg0d6mGO8-2DoFLXk7pIhCb9I0BeR-iRvDpetvJeb0-KYwZi0uvXwFUZbcpxMBIe6SNJi4kBSEuOTJbJY11Cwz-DpFNSQkMDSO3UnvyDiBEyqfn9_7Q6tPnq-gCdkNDtt5tiJuM72tAzDx9rDB-e1J9tvDXva6iVosjTKetKY8_v9J6H0t84QzTtQRWwc5GZVtACarznuIDwA2xS01p0Z0ScenBj7aeR5mI22XwQIkhkBE3";
    }
    // Return Dicebear Avatar for others
    return `https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}&backgroundColor=${color.replace('#','')}&mouth=smile`;
  };

  const getCpuImage = (id: number, seed: string, color: string) => {
    if (id === 1) {
      return "https://lh3.googleusercontent.com/aida-public/AB6AXuCUn3gdLGlpCx1coteFU-gHETMmfN77CywTCNvppwULqmYcTyv8PDg5i-YM6vcj0hpv7PZYCftU1XzySTL7hs4kcKqa3ZstytZo5oaI3rz-0KDkdl0AMtfLz0hDccwrlHwf95SQXAOckA-21L_61hkJQJdnrQ3jXBTiE912_XDslQOHlbTo4CWqzShAH2W2M2sT_VpBqa7nwgrpr_rmMXrdxN8-kYIpyevRSFMU4YG5L1PN8hBeneGXzT2kqZK-SnQffP_ijKN6AetR";
    }
    if (id === 2) {
      return "https://lh3.googleusercontent.com/aida-public/AB6AXuC5OWLOBoeBsUFHQvIWBX3CjaIDnJMmlsg0d6mGO8-2DoFLXk7pIhCb9I0BeR-iRvDpetvJeb0-KYwZi0uvXwFUZbcpxMBIe6SNJi4kBSEuOTJbJY11Cwz-DpFNSQkMDSO3UnvyDiBEyqfn9_7Q6tPnq-gCdkNDtt5tiJuM72tAzDx9rDB-e1J9tvDXva6iVosjTKetKY8_v9J6H0t84QzTtQRWwc5GZVtACarznuIDwA2xS01p0Z0ScenBj7aeR5mI22XwQIkhkBE3";
    }
    return `https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}&backgroundColor=${color.replace('#','')}`;
  };

  return (
    <div className="space-y-16 pb-32">
      {/* Dual Player Widgets Section */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Player 1 Widget */}
        <div className="relative">
          <div className="bg-[#0a0a0a] border border-white/10 p-8 rounded-none h-[380px] flex flex-col justify-between overflow-hidden relative group">
            
            <div className="flex justify-between items-start z-10">
              <div>
                <p className="font-mono text-[9px] text-[#D4AF37] tracking-[0.2em] font-medium mb-1">PLAYER_01 / ACTIVE</p>
                <h2 className="font-serif text-4xl font-light text-[#E5E5E1] tracking-wide" id="p1-name-jp">{selectedChar.jp}</h2>
                <p className="font-mono text-[10px] text-[#E5E5E1]/50 tracking-[0.2em] mt-1.5 uppercase" id="p1-name-en">{selectedChar.en}</p>
              </div>
              <span className="font-mono text-[9px] tracking-[0.2em] uppercase border border-[#D4AF37] text-[#D4AF37] bg-transparent px-3 py-1.5 rounded-none font-bold">READY</span>
            </div>

            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03] select-none -z-0">
              <span className="text-[250px] font-serif italic text-[#D4AF37]">V</span>
            </div>

            {/* Display character figure */}
            <div className="relative h-full flex items-end justify-center pointer-events-none z-10 pt-4">
              <img 
                alt={selectedChar.en} 
                className="h-72 object-contain hover:scale-105 transition-all duration-300 transform select-none" 
                id="p1-display-img" 
                src={getPlayerImage(selectedChar.id, selectedChar.seed, selectedChar.color)}
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>

        {/* CPU / Player 2 Widget */}
        <div className="relative">
          <div className="bg-[#0a0a0a] border border-white/10 p-8 rounded-none h-[380px] flex flex-col justify-between overflow-hidden relative group">
            
            <div className="flex justify-between items-start z-10">
              <div>
                <p className="font-mono text-[9px] text-white/40 tracking-[0.2em] font-medium mb-1">CPU / OPPONENT</p>
                <h2 className="font-serif text-4xl font-light text-[#E5E5E1] tracking-wide" id="p2-name-jp">{cpuChar.jp}</h2>
                <p className="font-mono text-[10px] text-[#E5E5E1]/50 tracking-[0.2em] mt-1.5 uppercase" id="p2-name-en">{cpuChar.en}</p>
              </div>
              <span className="font-mono text-[9px] tracking-[0.2em] uppercase border border-white/10 text-white/40 bg-transparent px-3 py-1.5 rounded-none font-bold">STANDBY</span>
            </div>

            {/* Display CPU figure */}
            <div className="relative h-full flex items-end justify-center pointer-events-none z-10 pt-4 opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-300">
              <img 
                alt={cpuChar.en} 
                className="h-72 object-contain transform select-none" 
                id="p2-display-img" 
                src={getCpuImage(cpuChar.id, cpuChar.seed, cpuChar.color)}
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Grid of Characters Selection */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-4 pb-2 border-b border-white/5">
          <div>
            <h3 className="font-mono text-[10px] text-[#D4AF37] font-medium tracking-[0.25em] uppercase flex items-center gap-2">
              <Grid size={12} /> FIGHTER_STORES.EXE
            </h3>
            <p className="font-serif text-2xl font-light text-[#E5E5E1] mt-1">CHOOSE YOUR STICKER HERO</p>
          </div>
          <button 
            onClick={() => {
              const randomChar = charactersList[Math.floor(Math.random() * charactersList.length)];
              handleCharacterClick(randomChar);
            }}
            className="px-6 py-2 border border-white/20 hover:border-[#D4AF37] text-[#E5E5E1] hover:text-black hover:bg-[#D4AF37] bg-transparent font-mono text-[10px] tracking-[0.15em] uppercase rounded-none transition-colors duration-300 cursor-pointer"
          >
            Random Selection
          </button>
        </div>

        {/* Sticker Grid container */}
        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-8 gap-4 px-2" id="character-grid">
          {charactersList.map((char) => {
            const isSelected = char.id === selectedChar.id;
            return (
              <button 
                key={char.id}
                onClick={() => handleCharacterClick(char)}
                className={`group bg-[#0a0a0a] border p-2 rounded-none flex flex-col items-center justify-between transition-all relative cursor-pointer ${
                  isSelected 
                    ? 'border-[#D4AF37] shadow-[0_0_12px_rgba(212,175,55,0.25)] scale-105 bg-white/5' 
                    : 'border-white/5 hover:border-white/20 hover:-translate-y-0.5'
                }`}
              >
                {/* Visual Avatar */}
                <div className="w-full aspect-square bg-black/50 rounded-none p-1 overflow-hidden shadow-inner flex items-center justify-center">
                  <img 
                    src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${char.seed}&backgroundColor=${char.color.replace('#','')}`} 
                    className="w-full h-full object-contain transition-transform group-hover:scale-110 select-none" 
                    alt={char.en}
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Sub name text */}
                <div className="w-full mt-2 text-center py-0.5 border-t border-white/5">
                  <p className="font-mono text-[9px] font-medium text-[#E5E5E1]/60 truncate">{char.jp}</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Floating Bottom CTA Action Button */}
      <div className="fixed bottom-0 left-0 w-full bg-[#050505]/95 backdrop-blur-xl border-t border-white/10 p-6 flex justify-center items-center z-40">
        <button 
          onClick={() => onViewChange('home')}
          className="group relative px-16 py-4 bg-[#E5E5E1] hover:bg-[#D4AF37] text-black font-mono font-bold text-xs rounded-none transition-colors duration-300 cursor-pointer flex items-center gap-3 uppercase tracking-[0.25em]"
        >
          <Swords size={12} className="stroke-[2.5]" />
          Assign & Play Game
          <span className="absolute -right-4 -top-4 bg-[#D4AF37] text-black font-mono text-[9px] tracking-wider px-3 py-1 rounded-none uppercase font-bold animate-bounce shadow-md">
            CHALLENGE!
          </span>
        </button>
      </div>
    </div>
  );
}

import { BookOpen, BookOpenCheck, Settings, Award, AlertTriangle, Play, HelpCircle } from 'lucide-react';
import { useState } from 'react';
import { ViewType } from '../types';

interface RulesProps {
  onViewChange: (view: ViewType) => void;
}

type LangMode = 'bilingual' | 'english' | 'japanese';

export default function Rules({ onViewChange }: RulesProps) {
  const [langMode, setLangMode] = useState<LangMode>('bilingual');

  const t = {
    bilingual: {
      title: "HOW TO PLAY",
      subtitle: "しりとり & オセロ ガイド",
      desc: "Master the art of the word chain and board capture. Learn the flow, avoid the 'n', and build your vocabulary.",
      tabBilingual: "BILINGUAL",
      tabEnglish: "ENGLISH",
      tabJapanese: "日本語",
      whatTitle: "WHAT IS SHIRITORI?",
      whatJp: "しりとりとは？",
      whatDesc: "Shiritori (しりとり) is a traditional Japanese word game. The name literally means \"taking the end\" or \"taking the tail,\" referring to the core mechanic of starting a new word with the final syllable of the previous one.",
      flowTitle: "EXAMPLE GAME FLOW",
      loseTitle: "THE END CONDITION",
      loseJp: "敗北条件 (How You Lose)",
      loseDesc: "The most critical rule: If you play a word ending in the Japanese character \"N\" (ん), you lose immediately.",
      loseAlert: "WHY? No Japanese word starts with \"N\". The chain is broken forever!",
      rulesTitle: "BASIC RULES",
      rulesJp: "基本ルール",
      rule1Title: "NOUNS ONLY",
      rule1Desc: "Only nouns (Meishi) are permitted in standard play.",
      rule2Title: "NO REPEATS",
      rule2Desc: "You cannot use a word that has already been spoken in the active game.",
      rule3Title: "DAKUON RULES",
      rule3Desc: "Words ending in voiced marks (e.g. \"ga\" が) can be followed by \"ka\" or \"ga\".",
      wordBankTitle: "STARTER WORD BANK / 初心者用単語帳",
      readyTitle: "Ready to test your vocab skills?",
      btnStart: "START GAME",
      btnPractice: "TRAINING MODE"
    },
    english: {
      title: "HOW TO PLAY",
      subtitle: "Word Chain Rules",
      desc: "Master the art of the word chain and board capture. Learn the flow, avoid the 'n', and build your vocabulary.",
      tabBilingual: "BILINGUAL",
      tabEnglish: "ENGLISH",
      tabJapanese: "日本語",
      whatTitle: "WHAT IS SHIRITORI?",
      whatJp: "",
      whatDesc: "Shiritori is a traditional Japanese word game where players must say a noun that starts with the last syllable of the previous player's word. It is highly popular among both children and language learners.",
      flowTitle: "WORD FLOW EXAMPLE",
      loseTitle: "THE END CONDITION",
      loseJp: "Instant Loss Condition",
      loseDesc: "If you play a word block ending in the character 'N' (ん), the game finishes instantly as a loss.",
      loseAlert: "Why? Since zero Japanese nouns start with the character 'N' (ん), the word chain becomes impossible to continue.",
      rulesTitle: "STANDARD RULES",
      rulesJp: "",
      rule1Title: "NOUNS ONLY",
      rule1Desc: "Only standard nouns are allowed. Verbs and adjectives are banned.",
      rule2Title: "NO REPEATS",
      rule2Desc: "You cannot say a word that was already played earlier in the chain.",
      rule3Title: "DAKUON FLEXIBILITY",
      rule3Desc: "Voiced end characters (such as が - ga) can be matched by standard forms (か - ka) or same form.",
      wordBankTitle: "STARTER VOCABULARY BOOK",
      readyTitle: "Ready to test your skills?",
      btnStart: "START GAME",
      btnPractice: "PRACTICE GAME"
    },
    japanese: {
      title: "あそびかた",
      subtitle: "しりとりのルール",
      desc: "ことばを繋げるゲームです。語尾を次の言葉の語頭にし、語彙を増やして勝利を目指しましょう！",
      tabBilingual: "BILINGUAL",
      tabEnglish: "ENGLISH",
      tabJapanese: "日本語",
      whatTitle: "「しりとり」とは？",
      whatJp: "しりとりとは？",
      whatDesc: "しりとりは、前の人が言った言葉の最後の音をとって、新しい言葉を繋げる日本の伝統的な言葉遊びです。名詞のみを使うのが一般的です。",
      flowTitle: "しりとりの流れ例",
      loseTitle: "敗北のルール",
      loseJp: "敗北条件（ん・ン）",
      loseDesc: "最も重要なしりとりのルールです。言葉の最後の文字が「ん」で終わる言葉を言ったプレイヤーは、その時点で即負けとなります。",
      loseAlert: "なぜ？「ん」から始まる日本語の単語は存在しないため、しりとりが絶対に続けられなくなるからです。",
      rulesTitle: "基本ルール",
      rulesJp: "基本ルール",
      rule1Title: "名詞のみ",
      rule1Desc: "しりとりで使えるのは、一般的に「名詞」のみです。動詞や形容詞は使えません。",
      rule2Title: "重複の禁止",
      rule2Desc: "そのゲーム中に、既に誰かが発言した言葉を再び言うことはできません。",
      rule3Title: "濁音・半濁音のルール",
      rule3Desc: "「が」など濁音で終わった場合、「か」から始めても「が」から始めても遊べます。",
      wordBankTitle: "初心者用単語帳",
      readyTitle: "しりとりを始めてみましょう！",
      btnStart: "ゲームを始める",
      btnPractice: "練習モード"
    }
  }[langMode];

  return (
    <div className="space-y-16 pb-24">
      {/* Top Header Block */}
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-white/10 pb-8">
        <div>
          <span className="font-mono text-[9px] text-[#D4AF37] font-medium border-l border-[#D4AF37] pl-3 mb-2.5 block uppercase tracking-[0.25em]">
            Game Manual / 遊び方指南
          </span>
          <h1 className="font-serif text-3xl md:text-4xl font-light text-[#E5E5E1] tracking-wide uppercase">
            {t.title}
          </h1>
          <p className="text-[#E5E5E1]/60 font-sans font-light text-sm md:text-base mt-2 max-w-2xl leading-relaxed">
            {t.desc}
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-[#0a0a0a] border border-white/10 p-1 rounded-none shrink-0 self-start md:self-auto">
          <button
            onClick={() => setLangMode('bilingual')}
            className={`px-4 py-2 font-mono font-bold text-[10px] tracking-wider rounded-none transition-all ${
              langMode === 'bilingual' ? 'bg-[#E5E5E1] text-black shadow-md' : 'text-[#E5E5E1]/40 hover:text-[#D4AF37]'
            }`}
          >
            {t.tabBilingual}
          </button>
          <button
            onClick={() => setLangMode('english')}
            className={`px-4 py-2 font-mono font-bold text-[10px] tracking-wider rounded-none transition-all ${
              langMode === 'english' ? 'bg-[#E5E5E1] text-black shadow-md' : 'text-[#E5E5E1]/40 hover:text-[#D4AF37]'
            }`}
          >
            {t.tabEnglish}
          </button>
          <button
            onClick={() => setLangMode('japanese')}
            className={`px-4 py-2 font-mono font-bold text-[10px] tracking-wider rounded-none transition-all ${
              langMode === 'japanese' ? 'bg-[#E5E5E1] text-black shadow-md' : 'text-[#E5E5E1]/40 hover:text-[#D4AF37]'
            }`}
          >
            {t.tabJapanese}
          </button>
        </div>
      </section>

      {/* Bento Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* bento box 1: What is Shiritori */}
        <div className="md:col-span-8 bg-[#0a0a0a] border border-white/10 hover:border-[#D4AF37]/50 rounded-none p-8 shadow-2xl transition-all duration-300 group relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 p-3 font-mono text-[9px] text-[#D4AF37]/30 tracking-widest">MODULE_01</div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <span className="font-mono text-[9px] text-[#D4AF37] tracking-[0.25em] font-medium uppercase">{t.whatTitle}</span>
              <div className="h-[1px] flex-grow bg-white/5"></div>
            </div>
            {t.whatJp && <h2 className="font-serif text-2xl font-light text-[#E5E5E1]">{t.whatJp}</h2>}
            <p className="text-sm md:text-base text-[#E5E5E1]/80 font-light leading-relaxed">
              {t.whatDesc}
            </p>
          </div>

          <div className="mt-8 bg-black/40 border border-dashed border-white/10 p-6 rounded-none">
            <span className="font-mono text-[9px] text-[#D4AF37] mb-2.5 block uppercase font-bold tracking-widest">{t.flowTitle}</span>
            <div className="flex flex-wrap items-center gap-3 font-mono text-xs text-[#E5E5E1]">
              <span className="bg-white/5 p-2 px-3 border border-white/15 rounded-none">
                Rin<span className="text-[#D4AF37]">go</span> (りんご)
              </span>
              <span className="text-[#D4AF37] font-bold">➔</span>
              <span className="bg-white/5 p-2 px-3 border border-white/15 rounded-none">
                <span className="text-[#D4AF37]">Go</span>ri<span className="text-white/70">ra</span> (ごりら)
              </span>
              <span className="text-[#D4AF37] font-bold">➔</span>
              <span className="bg-white/5 p-2 px-3 border border-[#D4AF37] rounded-none">
                <span className="text-white/70">Ra</span>ppa (らっぱ)
              </span>
            </div>
          </div>
        </div>

        {/* bento box 2: Pro Tip strategies */}
        <div className="md:col-span-4 bg-[#0a0a0a] border border-[#D4AF37]/50 rounded-none p-8 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 p-3 bg-white/5 text-[#D4AF37] font-mono text-[8px] uppercase tracking-widest font-bold">PRO TIPS</div>
          
          <div className="space-y-4">
            <span className="font-mono text-[9px] text-[#D4AF37] tracking-[0.25em] font-medium uppercase">STRATEGY</span>
            
            <ul className="space-y-5">
              <li className="flex gap-3">
                <span className="text-lg leading-none text-[#D4AF37]">■</span>
                <p className="font-sans text-xs md:text-sm font-light text-[#E5E5E1]/80">
                  End words with uncommon syllables like <strong className="text-white">&quot;Mu&quot; (む)</strong> or <strong className="text-white">&quot;Ne&quot; (ね)</strong> to trap opponents.
                </p>
              </li>
              <li className="flex gap-3">
                <span className="text-lg leading-none text-[#D4AF37]">■</span>
                <p className="font-sans text-xs md:text-sm font-light text-[#E5E5E1]/80">
                  Match voiced sounds intelligently. Re-voice them to return difficult chains to safety.
                </p>
              </li>
              <li className="flex gap-3">
                <span className="text-lg leading-none text-[#D4AF37]">■</span>
                <p className="font-sans text-xs md:text-sm font-light text-[#E5E5E1]/80">
                  Keep a mental list of <strong className="text-white">&quot;Re&quot; (れ)</strong> words, as they are surprisingly common paths in conversational Japanese.
                </p>
              </li>
            </ul>
          </div>
        </div>

        {/* bento box 3: Basic Rules */}
        <div className="md:col-span-5 bg-[#0a0a0a] border border-white/10 hover:border-white/30 rounded-none p-8 transition-all flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <span className="font-mono text-[9px] text-[#E5E5E1]/40 tracking-[0.25em] font-medium uppercase">{t.rulesTitle}</span>
              <div className="h-[1px] flex-grow bg-white/5"></div>
            </div>
            {t.rulesJp && <h2 className="font-serif text-2xl font-light text-[#E5E5E1]">{t.rulesJp}</h2>}
            
            <ul className="space-y-4 mt-2">
              <li className="flex items-start gap-3">
                <div className="border border-[#D4AF37]/50 text-[#D4AF37] text-[10px] bg-transparent font-mono rounded-none px-2 py-0.5 shrink-0">01</div>
                <div>
                  <p className="font-serif text-xs font-light tracking-wide text-[#E5E5E1] uppercase">{t.rule1Title}</p>
                  <p className="text-xs text-[#E5E5E1]/60 font-light mt-0.5">{t.rule1Desc}</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="border border-[#D4AF37]/50 text-[#D4AF37] text-[10px] bg-transparent font-mono rounded-none px-2 py-0.5 shrink-0">02</div>
                <div>
                  <p className="font-serif text-xs font-light tracking-wide text-[#E5E5E1] uppercase">{t.rule2Title}</p>
                  <p className="text-xs text-[#E5E5E1]/60 font-light mt-0.5">{t.rule2Desc}</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="border border-[#D4AF37]/50 text-[#D4AF37] text-[10px] bg-transparent font-mono rounded-none px-2 py-0.5 shrink-0">03</div>
                <div>
                  <p className="font-serif text-xs font-light tracking-wide text-[#E5E5E1] uppercase">{t.rule3Title}</p>
                  <p className="text-xs text-[#E5E5E1]/60 font-light mt-0.5">{t.rule3Desc}</p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* bento box 4: Lose Condition */}
        <div className="md:col-span-7 bg-[#0a0a0a] border border-red-900/40 rounded-none p-8 flex flex-col justify-between relative">
          <div className="absolute top-0 right-0 p-3 font-mono text-[9px] text-red-500/40 font-bold uppercase tracking-widest">DANGER_ZONE</div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <span className="font-mono text-[9px] text-red-500/60 tracking-[0.25em] font-medium uppercase">{t.loseTitle}</span>
              <div className="h-[1px] flex-grow bg-red-900/10"></div>
            </div>
            
            <div className="flex flex-col md:flex-row gap-6 items-center">
              <div className="flex-1 space-y-4">
                <h2 className="font-serif text-2xl font-light text-red-300">{t.loseJp}</h2>
                <p className="text-sm text-[#E5E5E1]/70 font-light">
                  {t.loseDesc}
                </p>
                <div className="bg-red-950/20 border border-red-900/30 p-4 rounded-none">
                  <p className="text-red-400/90 text-xs font-mono font-medium leading-relaxed">
                    ⚠️ {t.loseAlert}
                  </p>
                </div>
              </div>

              {/* Pulsing Game Over Indicator */}
              <div className="w-24 h-24 flex flex-col items-center justify-center border border-red-500/30 bg-red-950/20 rounded-none shrink-0 select-none animate-pulse">
                <span className="text-4xl font-serif font-light text-red-400">ん</span>
                <span className="font-mono text-[8px] font-bold text-red-400 mt-1 uppercase tracking-widest">GameOver</span>
              </div>
            </div>
          </div>
        </div>

        {/* word bank table */}
        <div className="md:col-span-12 bg-[#0a0a0a] border border-white/10 rounded-none overflow-hidden mt-2">
          <div className="bg-white/5 px-6 py-4 flex justify-between items-center border-b border-white/10">
            <span className="font-mono text-[9px] text-[#D4AF37] tracking-[0.25em] font-bold uppercase">{t.wordBankTitle}</span>
            <span className="text-[#D4AF37]">📖</span>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left font-sans text-xs md:text-sm border-collapse">
              <thead>
                <tr className="bg-black border-b border-white/10 text-white/50">
                  <th className="px-6 py-4 font-bold uppercase tracking-wider font-mono text-[9px]">Japanese (Kana)</th>
                  <th className="px-6 py-4 font-bold uppercase tracking-wider font-mono text-[9px]">Romaji</th>
                  <th className="px-6 py-4 font-bold uppercase tracking-wider font-mono text-[9px]">English Meaning</th>
                  <th className="px-6 py-4 font-bold uppercase tracking-wider font-mono text-[9px]">Starts / Ends</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 font-serif text-[#E5E5E1] text-base font-light">さくら</td>
                  <td className="px-6 py-4 font-mono text-[#E5E5E1]/60 text-xs">Sakura</td>
                  <td className="px-6 py-4 font-sans font-light text-[#E5E5E1]/80">Cherry Blossom</td>
                  <td className="px-6 py-4">
                    <span className="bg-black border border-white/5 text-[#D4AF37] px-2 py-1 rounded-none font-mono text-[10px]">Sa (さ) ➔ Ra (ら)</span>
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors bg-white/[0.01]">
                  <td className="px-6 py-4 font-serif text-red-300 text-base font-light">らいおん</td>
                  <td className="px-6 py-4 font-mono text-[#E5E5E1]/60 text-xs">Raion</td>
                  <td className="px-6 py-4 font-sans font-light text-red-400">Lion (FORBIDDEN WORD)</td>
                  <td className="px-6 py-4">
                    <span className="bg-red-950/20 border border-red-900/20 text-red-400 px-2 py-1 rounded-none font-mono text-[10px]">Ra (ら) ➔ N (ん) ❌</span>
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 font-serif text-[#E5E5E1] text-base font-light">ねこ</td>
                  <td className="px-6 py-4 font-mono text-[#E5E5E1]/60 text-xs">Neko</td>
                  <td className="px-6 py-4 font-sans font-light text-[#E5E5E1]/80">Cat</td>
                  <td className="px-6 py-4">
                    <span className="bg-black border border-white/5 text-[#D4AF37] px-2 py-1 rounded-none font-mono text-[10px]">Ne (ね) ➔ Ko (こ)</span>
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors bg-white/[0.01]">
                  <td className="px-6 py-4 font-serif text-[#E5E5E1] text-base font-light">こいぬ</td>
                  <td className="px-6 py-4 font-mono text-[#E5E5E1]/60 text-xs">Koinu</td>
                  <td className="px-6 py-4 font-sans font-light text-[#E5E5E1]/80">Puppy</td>
                  <td className="px-6 py-4">
                    <span className="bg-black border border-white/5 text-[#D4AF37] px-2 py-1 rounded-none font-mono text-[10px]">Ko (こ) ➔ Nu (ぬ)</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Footer Call to action */}
      <section className="flex flex-col items-center text-center gap-6 py-12 border-t border-white/10">
        <h3 className="font-serif text-2xl font-light text-[#E5E5E1]">{t.readyTitle}</h3>
        <div className="flex flex-col sm:flex-row gap-4 w-full justify-center max-w-lg px-4">
          <button
            onClick={() => onViewChange('shiritori')}
            className="bg-white text-black hover:bg-[#D4AF37] hover:text-black py-4 px-8 rounded-none font-mono text-xs uppercase font-bold tracking-[0.2em] transition-colors flex-1 flex items-center justify-center gap-2"
          >
            <Play size={10} fill="currentColor" /> {t.btnStart}
          </button>
          <button
            onClick={() => onViewChange('home')}
            className="border border-white/20 hover:border-white text-[#E5E5E1] bg-transparent rounded-none py-4 px-8 font-mono text-xs uppercase font-bold tracking-[0.2em] transition-all flex-1"
          >
            {t.btnPractice}
          </button>
        </div>
      </section>
    </div>
  );
}

export interface DictionaryWord {
  jp: string;
  romaji: string;
  en: string;
}

export const SHIRITORI_DICTIONARY: DictionaryWord[] = [
  // A
  { jp: "あめ", romaji: "ame", en: "Rain / Candy" },
  { jp: "あい", romaji: "ai", en: "Love" },
  { jp: "あさ", romaji: "asa", en: "Morning" },
  { jp: "あき", romaji: "aki", en: "Autumn" },
  // I
  { jp: "いぬ", romaji: "inu", en: "Dog" },
  { jp: "いちご", romaji: "ichigo", en: "Strawberry" },
  { jp: "いえ", romaji: "ie", en: "House" },
  { jp: "いけ", romaji: "ike", en: "Pond" },
  // U
  { jp: "うみ", romaji: "umi", en: "Sea" },
  { jp: "うし", romaji: "ushi", en: "Cow" },
  { jp: "うた", romaji: "uta", en: "Song" },
  { jp: "うち", romaji: "uchi", en: "Home" },
  // E
  { jp: "えき", romaji: "eki", en: "Station" },
  { jp: "えんぴつ", romaji: "enpitsu", en: "Pencil" },
  { jp: "えほん", romaji: "ehon", en: "Picture book" },
  { jp: "えがお", romaji: "egao", en: "Smile" },
  // O
  { jp: "お茶", romaji: "ocha", en: "Green tea" },
  { jp: "おおかみ", romaji: "ookami", en: "Wolf" },
  { jp: "おにぎり", romaji: "onigiri", en: "Rice ball" },
  { jp: "おもちゃ", romaji: "omocha", en: "Toy" },
  // KA
  { jp: "かも", romaji: "kamo", en: "Duck" },
  { jp: "かわ", romaji: "kawa", en: "River" },
  { jp: "かつお", romaji: "katsuo", en: "Bonito fish" },
  { jp: "かぜ", romaji: "kaze", en: "Wind / Cold" },
  { jp: "かさ", romaji: "kasa", en: "Umbrella" },
  // KI
  { jp: "きつね", romaji: "kitsune", en: "Fox" },
  { jp: "きっぷ", romaji: "kippu", en: "Ticket" },
  { jp: "きのこ", romaji: "kinoko", en: "Mushroom" },
  { jp: "きりん", romaji: "kirin", en: "Giraffe" },
  // KU
  { jp: "くま", romaji: "kuma", en: "Bear" },
  { jp: "くるま", romaji: "kuruma", en: "Car" },
  { jp: "くも", romaji: "kumo", en: "Cloud" },
  { jp: "くつ", romaji: "kutsu", en: "Shoes" },
  // KE
  { jp: "けしごむ", romaji: "keshigomu", en: "Eraser" },
  { jp: "けむり", romaji: "kemuri", en: "Smoke" },
  { jp: "けーき", romaji: "keeki", en: "Cake" },
  // KO
  { jp: "こいぬ", romaji: "koinu", en: "Puppy" },
  { jp: "こめ", romaji: "kome", en: "Rice" },
  { jp: "こころ", romaji: "kokoro", en: "Heart / Mind" },
  { jp: "ことば", romaji: "kotoba", en: "Word" },
  // SA
  { jp: "さくら", romaji: "sakura", en: "Cherry Blossom" },
  { jp: "さかな", romaji: "sakana", en: "Fish" },
  { jp: "さる", romaji: "saru", en: "Monkey" },
  { jp: "さとう", romaji: "satou", en: "Sugar" },
  // SHI
  { jp: "しりとり", romaji: "shiritori", en: "Word Chain" },
  { jp: "しお", romaji: "shio", en: "Salt" },
  { jp: "しか", romaji: "shika", en: "Deer" },
  { jp: "しんせん", romaji: "shinsen", en: "Freshness" },
  // SU
  { jp: "すいか", romaji: "suika", en: "Watermelon" },
  { jp: "すずめ", romaji: "suzume", en: "Sparrow" },
  { jp: "すし", romaji: "sushi", en: "Sushi" },
  { jp: "すな", romaji: "suna", en: "Sand" },
  // SE
  { jp: "せっけん", romaji: "sekken", en: "Soap" },
  { jp: "せなか", romaji: "senaka", en: "Back of body" },
  { jp: "せんせい", romaji: "sensei", en: "Teacher" },
  // SO
  { jp: "そら", romaji: "sora", en: "Sky" },
  { jp: "そうじ", romaji: "souji", en: "Cleaning" },
  { jp: "そふと", romaji: "sofuto", en: "Software" },
  // TA
  { jp: "たこ", romaji: "tako", en: "Octopus / Kite" },
  { jp: "たまご", romaji: "tamago", en: "Egg" },
  { jp: "たいよう", romaji: "taiyou", en: "Sun" },
  { jp: "たび", romaji: "tabi", en: "Journey" },
  // CHI
  { jp: "ちず", romaji: "chizu", en: "Map" },
  { jp: "ちきゅう", romaji: "chikyuu", en: "Earth" },
  { jp: "ちから", romaji: "chikara", en: "Strength" },
  // TSU
  { jp: "つくえ", romaji: "tsukue", en: "Desk" },
  { jp: "つき", romaji: "tsuki", en: "Moon" },
  { jp: "つばさ", romaji: "tsubasa", en: "Wings" },
  // TE
  { jp: "てがみ", romaji: "tegami", en: "Letter" },
  { jp: "てんき", romaji: "tenki", en: "Weather" },
  { jp: "てれび", romaji: "terebi", en: "Television" },
  // TO
  { jp: "とうふ", romaji: "toufu", en: "Tofu" },
  { jp: "とら", romaji: "tora", en: "Tiger" },
  { jp: "とり", romaji: "tori", en: "Bird" },
  { jp: "ともだち", romaji: "tomodachi", en: "Friend" },
  // NA
  { jp: "なつ", romaji: "natsu", en: "Summer" },
  { jp: "なみ", romaji: "nami", en: "Wave" },
  { jp: "なす", romaji: "nasu", en: "Eggplant" },
  // NI
  { jp: "にんじん", romaji: "ninjin", en: "Carrot" },
  { jp: "にく", romaji: "niku", en: "Meat" },
  { jp: "にじ", romaji: "niji", en: "Rainbow" },
  // NU
  { jp: "ぬの", romaji: "nuno", en: "Cloth" },
  { jp: "ぬいぐるみ", romaji: "nuigurumi", en: "Stuffed toy" },
  // NE
  { jp: "ねこ", romaji: "neko", en: "Cat" },
  { jp: "ねつ", romaji: "netsu", en: "Heat / Fever" },
  { jp: "ねんど", romaji: "nendo", en: "Clay" },
  // NO
  { jp: "のり", romaji: "nori", en: "Seaweed / Glue" },
  { jp: "のど", romaji: "nodo", en: "Throat" },
  { jp: "ノート", romaji: "no-to", en: "Notebook" },
  // HA
  { jp: "はな", romaji: "hana", en: "Flower / Nose" },
  { jp: "はし", romaji: "hashi", en: "Bridge / Chopsticks" },
  { jp: "はいしゃ", romaji: "haisha", en: "Dentist" },
  // HI
  { jp: "ひつじ", romaji: "hitsuji", en: "Sheep" },
  { jp: "ひかり", romaji: "hikari", en: "Light" },
  { jp: "ひこうき", romaji: "hikouki", en: "Airplane" },
  // FU
  { jp: "ふね", romaji: "fune", en: "Ship / Boat" },
  { jp: "ふく", romaji: "fuku", en: "Clothes" },
  { jp: "ふうせん", romaji: "fuusen", en: "Balloon" },
  // HE
  { jp: "へや", romaji: "heya", en: "Room" },
  { jp: "へび", romaji: "hebi", en: "Snake" },
  { jp: "へるめっと", romaji: "herumetto", en: "Helmet" },
  // HO
  { jp: "ほし", romaji: "hoshi", en: "Star" },
  { jp: "ほん", romaji: "hon", en: "Book" },
  { jp: "ほたる", romaji: "hotaru", en: "Firefly" },
  // MA
  { jp: "まつお", romaji: "matsuo", en: "Pine tree tails" },
  { jp: "まくら", romaji: "makura", en: "Pillow" },
  { jp: "まど", romaji: "mado", en: "Window" },
  // MI
  { jp: "みかん", romaji: "mikan", en: "Mandarin orange" },
  { jp: "みず", romaji: "mizu", en: "Water" },
  { jp: "みち", romaji: "michi", en: "Road / Path" },
  // MU
  { jp: "むし", romaji: "mushi", en: "Insect" },
  { jp: "むすめ", romaji: "musume", en: "Daughter" },
  { jp: "むら", romaji: "mura", en: "Village" },
  // ME
  { jp: "めがね", romaji: "megane", en: "Glasses" },
  { jp: "めろん", romaji: "meron", en: "Melon" },
  // MO
  { jp: "もち", romaji: "mochi", en: "Rice cake" },
  { jp: "もり", romaji: "mori", en: "Forest" },
  { jp: "もも", romaji: "momo", en: "Peach" },
  // YA
  { jp: "やま", romaji: "yama", en: "Mountain" },
  { jp: "やさい", romaji: "yasai", en: "Vegetables" },
  { jp: "やね", romaji: "yane", en: "Roof" },
  // YU
  { jp: "ゆき", romaji: "yuki", en: "Snow" },
  { jp: "ゆめ", romaji: "yume", en: "Dream" },
  { jp: "ゆうがた", romaji: "yuugata", en: "Evening" },
  // YO
  { jp: "よる", romaji: "yoru", en: "Night" },
  { jp: "ようせい", romaji: "yousei", en: "Fairy" },
  // RA
  { jp: "らいおん", romaji: "raion", en: "Lion (Careful: ends with ん!)" },
  { jp: "らっぱ", romaji: "rappa", en: "Trumpet" },
  { jp: "らくだ", romaji: "rakuda", en: "Camel" },
  // RI
  { jp: "りす", romaji: "risu", en: "Squirrel" },
  { jp: "りんご", romaji: "ringo", en: "Apple" },
  { jp: "りぼん", romaji: "ribon", en: "Ribbon (Careful: ends with ん!)" },
  // RU
  { jp: "るり", romaji: "ruri", en: "Lapis Lazuli" },
  { jp: "るすばんばん", romaji: "rusubanban", en: "House staying" },
  // RE
  { jp: "れもん", romaji: "remon", en: "Lemon (ends with ん!)" },
  { jp: "れきし", romaji: "rekishi", en: "History" },
  { jp: "れんぞく", romaji: "renzoku", en: "Continuous" },
  // RO
  { jp: "ろうそく", romaji: "rousoku", en: "Candle" },
  { jp: "ろけっと", romaji: "roketto", en: "Rocket" },
  { jp: "ろば", romaji: "roba", en: "Donkey" },
  // WA
  { jp: "わに", romaji: "wani", en: "Alligator" },
  { jp: "わたあめ", romaji: "wataame", en: "Cotton candy" },
  { jp: "わらび", romaji: "warabi", en: "Bracken fern" }
];

export const charactersList = [
  { id: 1, en: "Satoshi", jp: "サトシ", seed: "Satoshi", color: "#ff8a00" },
  { id: 2, en: "Miku", jp: "ミク", seed: "Miku", color: "#312ec5" },
  { id: 3, en: "Kuma", jp: "クマ", seed: "Kuma", color: "#e9c400" },
  { id: 4, en: "Yuki", jp: "ユキ", seed: "Yuki", color: "#c1c1ff" },
  { id: 5, en: "Taro", jp: "タロウ", seed: "Taro", color: "#ffb4ab" },
  { id: 6, en: "Rei", jp: "レイ", seed: "Rei", color: "#914c00" },
  { id: 7, en: "Hoshi", jp: "ホシ", seed: "Hoshi", color: "#ff8a00" },
  { id: 8, en: "Ren", jp: "レン", seed: "Ren", color: "#312ec5" },
  { id: 9, en: "Momo", jp: "モモ", seed: "Momo", color: "#e9c400" },
  { id: 10, en: "Ken", jp: "ケン", seed: "Ken", color: "#c1c1ff" },
  { id: 11, en: "Luna", jp: "ルナ", seed: "Luna", color: "#ffb4ab" },
  { id: 12, en: "Zen", jp: "ゼン", seed: "Zen", color: "#914c00" },
  { id: 13, en: "Pochi", jp: "ポチ", seed: "Pochi", color: "#ff8a00" },
  { id: 14, en: "Ryu", jp: "リュウ", seed: "Ryu", color: "#312ec5" },
  { id: 15, en: "Sakura", jp: "サクラ", seed: "Sakura", color: "#e9c400" },
  { id: 16, en: "Goro", jp: "ゴロウ", seed: "Goro", color: "#c1c1ff" }
];

// Helper to convert Romaji to Hiragana
export function convertRomajiToHiragana(text: string): string {
  const romajiMap: Record<string, string> = {
    'a': 'あ', 'i': 'い', 'u': 'う', 'e': 'え', 'o': 'お',
    'ka': 'か', 'ki': 'き', 'ku': 'く', 'ke': 'け', 'ko': 'こ',
    'ga': 'が', 'gi': 'ぎ', 'gu': 'ぐ', 'ge': 'げ', 'go': 'ご',
    'sa': 'さ', 'shi': 'し', 'si': 'し', 'su': 'す', 'se': 'せ', 'so': 'そ',
    'za': 'ざ', 'ji': 'じ', 'zi': 'じ', 'zu': 'ず', 'ze': 'ぜ', 'zo': 'ぞ',
    'ta': 'た', 'chi': 'ち', 'ti': 'ち', 'tsu': 'つ', 'tu': 'つ', 'te': 'て', 'to': 'と',
    'da': 'だ', 'di': 'ぢ', 'du': 'づ', 'de': 'で', 'do': 'ど',
    'na': 'な', 'ni': 'に', 'nu': 'ぬ', 'ne': 'ね', 'no': 'の',
    'ha': 'は', 'hi': 'ひ', 'fu': 'ふ', 'hu': 'ふ', 'he': 'へ', 'ho': 'ほ',
    'ba': 'ば', 'bi': 'び', 'bu': 'ぶ', 'be': 'べ', 'bo': 'ぼ',
    'pa': 'ぱ', 'pi': 'ぴ', 'pu': 'ぷ', 'pe': 'ぺ', 'po': 'ぽ',
    'ma': 'ま', 'mi': 'み', 'mu': 'む', 'me': 'め', 'mo': 'も',
    'ya': 'や', 'yu': 'ゆ', 'yo': 'よ',
    'ra': 'ら', 'ri': 'り', 'ru': 'る', 're': 'れ', 'ro': 'ろ',
    'wa': 'わ', 'wo': 'を', 'n': 'ん', 'nn': 'ん',
    'pa-': 'ぱー', 'pe-': 'ぺー', 'pi-': 'ぴー', 'po-': 'ぽー', 'pu-': 'ぷー',
    'ke-': 'けー', 'ko-': 'こー', 'ku-': 'くー', 'ki-': 'きー', 'ka-': 'かー'
  };

  let val = text.toLowerCase();
  let converted = "";
  let i = 0;
  
  while (i < val.length) {
    let char3 = val.substring(i, i + 3);
    let char2 = val.substring(i, i + 2);
    let char1 = val.substring(i, i + 1);
    
    if (romajiMap[char3]) {
      converted += romajiMap[char3];
      i += 3;
    } else if (romajiMap[char2]) {
      converted += romajiMap[char2];
      i += 2;
    } else if (romajiMap[char1]) {
      converted += romajiMap[char1];
      i += 1;
    } else {
      converted += val[i];
      i++;
    }
  }
  
  return converted;
}

// Get the starting and ending hiragana characters for a word
export function getWordCharacters(word: string): { start: string; end: string } {
  if (!word) return { start: "", end: "" };
  
  const start = word.charAt(0);
  
  // Handlers for long vowels, small kana, or standard end characters
  let end = word.charAt(word.length - 1);
  
  if (end === "ー" && word.length > 1) {
    end = word.charAt(word.length - 2);
  }
  
  // Convert standard small characters to big ones for starting ease
  const smallToBig: Record<string, string> = {
    'ゃ': 'や', 'ゅ': 'ゆ', 'ょ': 'よ',
    'ぁ': 'あ', 'ぃ': 'い', 'ぅ': 'う', 'ぇ': 'え', 'ぉ': 'お',
    'っ': 'つ'
  };
  
  if (smallToBig[end]) {
    end = smallToBig[end];
  }
  
  return { start, end };
}

export interface Character {
  id: number;
  en: string;
  jp: string;
  seed: string;
  color: string;
}

export interface ShiritoriWord {
  word: string;
  romaji: string;
  meaning: string;
  isPlayer: boolean;
}

export type ViewType = 'home' | 'character' | 'shiritori' | 'othello' | 'leaderboard' | 'rules';

export interface PlayerStats {
  gamesPlayed: number;
  wins: number;
  winRate: number;
  longestWord: {
    jp: string;
    en: string;
  };
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  avatarSeed: string;
  avatarColor: string;
  score: number;
  chain?: number;
  isPlayer?: boolean;
}

# Konnichiwa! Japanese for Everyone — Course Deck

Audience: enrolled students. Purpose: lesson-content / course walkthrough. 24 slides.

## Palette
- bg navy #1a1a3e (deeper #16162f for dividers)
- cherry blossom pink #FFB7C5
- gold #FFD700
- vermilion accent #b13a2e (sparing)
- text #EDE8E0 / #F5F0EA

## Type
- Japanese + big kana: Shippori Mincho B1
- English display: Cormorant Garamond
- Body / labels: Zen Kaku Gothic New

## Patterns: subtle seigaiha band (title/dividers/close), faint giant kanji watermark on dividers.

## Title sequence (topic noun-phrases + Stage dividers)
1. (Title) こんにちは! Japanese for Everyone
2. Welcome to the Course
3. Three Ways to Write
4. The Learning Journey
5. The Course at a Glance
6. How You'll Learn
7. Stage One — The Foundations (基礎)
8. The Hiragana Chart
9. The Katakana Chart
10. Reading Your First Words
11. Stage Two — Building Blocks (基本)
12. Basic Sentence Structure
13. Numbers, Dates & Time
14. Everyday Vocabulary
15. Your First Kanji (N5)
16. Stage Three — Real Japanese (実践)
17. Intermediate Grammar
18. A Real Conversation
19. Stage Four — Toward Mastery (上級)
20. Keigo & Polite Speech
21. Advanced Kanji & Reading
22. What N4 Unlocks
23. Course Wrap-Up
24. Closing — がんばって！

---
name: Imperial Heritage
colors:
  surface: '#131412'
  surface-dim: '#131412'
  surface-bright: '#393937'
  surface-container-lowest: '#0e0e0d'
  surface-container-low: '#1b1c1a'
  surface-container: '#1f201e'
  surface-container-high: '#2a2a28'
  surface-container-highest: '#343533'
  on-surface: '#e4e2de'
  on-surface-variant: '#c8c5cf'
  inverse-surface: '#e4e2de'
  inverse-on-surface: '#30312e'
  outline: '#918f99'
  outline-variant: '#47464e'
  surface-tint: '#c4c2f0'
  primary: '#c4c2f0'
  on-primary: '#2c2d51'
  primary-container: '#1a1a3e'
  on-primary-container: '#8382ac'
  inverse-primary: '#5b5b82'
  secondary: '#fbb3c1'
  on-secondary: '#50212d'
  secondary-container: '#6b3743'
  on-secondary-container: '#e8a2b0'
  tertiary: '#e9c400'
  on-tertiary: '#3a3000'
  tertiary-container: '#c9a900'
  on-tertiary-container: '#4c3f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c4c2f0'
  on-primary-fixed: '#17173b'
  on-primary-fixed-variant: '#434369'
  secondary-fixed: '#ffd9df'
  secondary-fixed-dim: '#fbb3c1'
  on-secondary-fixed: '#360c19'
  on-secondary-fixed-variant: '#6b3743'
  tertiary-fixed: '#ffe16d'
  tertiary-fixed-dim: '#e9c400'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#544600'
  background: '#131412'
  on-background: '#e4e2de'
  surface-variant: '#343533'
typography:
  display-lg:
    fontFamily: Noto Serif
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 32px
  margin-desktop: 64px
  margin-mobile: 24px
---

## Brand & Style

This design system draws inspiration from Japanese aesthetic principles of *Ma* (negative space) and *Kogei* (fine craftsmanship). It targets a high-end educational and professional audience, focusing on the delivery of sophisticated content such as historical lectures, luxury brand training, or cultural archives.

The design style is **Minimalist-Traditional**. It pairs clean, structured layouts with ornate, high-contrast accents. The emotional response is one of quiet authority, timelessness, and deep respect for the subject matter. Every element is placed with purpose, avoiding clutter to allow the premium typography and subtle textures to breathe.

## Colors

The palette is rooted in a deep, midnight navy that serves as the canvas for the entire system. This provides a high-contrast foundation for the more delicate accent colors.

- **Primary (Midnight Navy):** Used for all major backgrounds and structural containers. It evokes stability and depth.
- **Secondary (Sakura Pink):** Reserved for interactive elements, call-outs, and soft decorative accents. It provides a warm, human contrast to the dark base.
- **Tertiary (Imperial Gold):** Used sparingly for highlights, borders, and significant icons. It signifies prestige and value.
- **Neutral (Washi White):** An off-white, paper-like tone used for primary body text and light-themed content cards to ensure readability without the harshness of pure white.

## Typography

The typography system prioritizes legibility and a "literary" feel. While the system uses **Noto Serif** for headlines (replicating the elegance of Shippori Mincho) and **Source Serif 4** for body text, the layout should respect traditional typesetting.

- **Headlines:** Should be used with generous leading. For display titles, consider vertical text alignment for short Japanese phrases to enhance the traditional feel.
- **Body:** Serif-based for a long-form reading experience that feels academic and premium.
- **Labels:** A clean, modern sans-serif (Plus Jakarta Sans) is used for UI metadata and small labels to ensure clarity at small sizes and provide a contemporary counterpoint to the serif dominant style.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for desktop to maintain the "slide" or "page" aesthetic, switching to a fluid model for mobile.

- **The Grid:** A 12-column grid with wide 32px gutters. This width allows for the "Ma" (whitespace) necessary for a premium feel.
- **Rhythm:** Spacing should follow an 8px base unit. Use larger-than-standard padding (e.g., 64px or 80px) between major sections to denote clear transitions in educational content.
- **Decorative Margins:** Utilize the outer margins for subtle decorative elements like vertical page numbering or "Seigaiha" (wave) watermarks.

## Elevation & Depth

This design system avoids heavy drop shadows in favor of **Tonal Layers** and **Graphic Linework**. 

- **Surface Tiers:** Use subtle shifts in the Navy background (e.g., 5% lighter or darker) to define different content areas. 
- **Gold Dividers:** Instead of shadows, use 1px Imperial Gold lines or "Asanoha" pattern borders to separate content blocks. 
- **Backdrop Blurs:** When overlays or modals are used, apply a high-density background blur (30px+) over the Midnight Navy to maintain a glass-like, premium depth without breaking the minimalist aesthetic.

## Shapes

The shape language is strictly **Sharp (0)**. 

Sharp corners convey a sense of precision, architectural structure, and traditional wood-block printing aesthetics. All cards, buttons, and input fields should utilize 90-degree angles. To prevent the UI from feeling "harsh," the rigidity of the shapes is softened by the organic nature of the serif typography and the delicate "Sakura" accent colors.

## Components

### Buttons
Primary buttons use a solid Gold background with Navy text, featuring a thin double-border (1px Gold, 2px Gap, 1px Gold) on hover. Secondary buttons are Ghost-style with Sakura Pink text and outlines.

### Cards
Cards are defined by 1px Gold or Navy-light borders. They should never have shadows. Headers within cards should be separated by a decorative "Asanoha" (hemp leaf) divider line.

### Lists
Lists should utilize custom "mon" (emblem) style bullets. Use simple geometric circles or stylized petal shapes in Sakura Pink for bullet points.

### Dividers
Dividers are a core component of this system. They should not just be plain lines; use them to incorporate the traditional patterns (Seigaiha) at a very low opacity (10-15%) to separate sections of a lecture.

### Input Fields
Inputs are bottom-border only, mimicking a calligraphy scroll. The focus state changes the bottom border from Washi White to Imperial Gold.

### Lecture Slides
For educational content, use a "side-car" layout: a narrow column for key terms (using Label-sm) and a wide column for main prose or imagery. High-quality photography should be framed with a thin 1px Gold inset border.
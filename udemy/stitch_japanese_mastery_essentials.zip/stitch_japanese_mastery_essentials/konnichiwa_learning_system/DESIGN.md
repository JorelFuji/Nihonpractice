---
name: Konnichiwa! Learning System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434656'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#747688'
  outline-variant: '#c4c5d9'
  surface-tint: '#104af0'
  primary: '#0040df'
  on-primary: '#ffffff'
  primary-container: '#2d5bff'
  on-primary-container: '#efefff'
  inverse-primary: '#b8c3ff'
  secondary: '#006e2f'
  on-secondary: '#ffffff'
  secondary-container: '#6bff8f'
  on-secondary-container: '#007432'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c3ff'
  on-primary-fixed: '#001355'
  on-primary-fixed-variant: '#0035bd'
  secondary-fixed: '#6bff8f'
  secondary-fixed-dim: '#4ae176'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005321'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

The design system is built for a professional e-learning environment that balances academic rigor with an encouraging, accessible atmosphere. The brand personality is "The Expert Mentor": authoritative yet approachable, organized but not rigid. 

The aesthetic follows a **Corporate / Modern** style, characterized by high-clarity layouts, systematic spacing, and a focused interface that reduces cognitive load for instructors. It utilizes generous white space to ensure content remains the primary focus, while subtle accents of vibrant color drive motivation and signify progress. The emotional response should be one of confidence, efficiency, and clarity.

## Colors

The color palette is functionally driven to assist with dashboard scanning and status identification:

- **Primary (Education Blue):** Used for primary actions, navigation states, and branding elements. It represents trust and formal education.
- **Success (Green):** Used for "Published" statuses, completed modules, and positive progress indicators.
- **Warning/Draft (Amber):** Used for "Draft" or "Pending" states to grab attention without signaling an error.
- **Neutrals:** A sophisticated range of slate grays is used for text hierarchy, borders, and subtle background layering to maintain a clean, high-end feel.

The interface is primarily light-mode to ensure maximum legibility for long-form reading and content management.

## Typography

This design system utilizes **Inter** exclusively to leverage its exceptional legibility and systematic weight distribution. 

- **Headlines:** Use Semi-Bold and Bold weights with slight negative letter-spacing to create a compact, professional look for dashboard headers.
- **Body:** Regular weight is used for instructional text and descriptions, ensuring comfort during extended periods of content creation.
- **Labels:** Uppercase labels with increased letter-spacing are used for metadata and status badges to differentiate them from interactive text.
- **Accessibility:** Line heights are set to at least 1.4x the font size to ensure a high level of readability for non-native speakers.

## Layout & Spacing

The layout is based on a **Fluid Grid** system that prioritizes logical grouping of information.

- **Desktop:** A 12-column grid with 24px gutters. A persistent sidebar (280px) houses primary navigation.
- **Tablet:** 8-column grid with 16px gutters. The sidebar collapses into a hamburger menu to prioritize content area.
- **Mobile:** 4-column grid with 16px margins. Touch targets for all interactive elements (buttons, list items) are a minimum of 44x44px.

A 4px baseline shift is used to maintain a consistent vertical rhythm. Content should be grouped in "containers" that use `lg` (24px) padding for internal breathing room.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and subtle **Ambient Shadows**.

- **Level 0 (Background):** A very light gray (#F8FAFC) creates a neutral canvas.
- **Level 1 (Cards/Surface):** Pure white surfaces with a soft, diffused shadow (0px 1px 3px rgba(0,0,0,0.1)) are used for course modules and lecture cards.
- **Level 2 (Active/Hover):** Interactive cards lift slightly on hover with a more pronounced shadow (0px 10px 15px -3px rgba(0,0,0,0.08)).
- **Outlines:** Subtle 1px borders (#E2E8F0) are used instead of shadows for non-essential groupings to keep the interface from feeling "heavy."

## Shapes

The shape language uses **Rounded** (Level 2) geometry to soften the professional aesthetic and make the platform feel more welcoming to educators.

- **Standard Elements:** 0.5rem (8px) corner radius for buttons, input fields, and small containers.
- **Large Elements:** 1rem (16px) corner radius for main course cards and dashboard widgets.
- **Status Badges:** 9999px (pill-shaped) to clearly distinguish them from buttons and other square-ish interactive elements.

## Components

- **Buttons:** Primary buttons use a solid Education Blue fill with white text. Secondary buttons use a ghost style (blue border, blue text).
- **Status Badges:** 
    - *Unpublished:* Neutral gray background with dark gray text.
    - *Draft:* Light amber background with dark amber text.
    - *Published:* Light green background with dark green text.
- **Course Sections:** Use a "header" style with a Level 1 white surface and a thick vertical left border in Education Blue to signify the group.
- **Lecture Lists:** Interactive rows with hover states. Each row includes a drag-handle icon for reordering, a title, and a duration label.
- **Progress Indicators:** Horizontal bars using a light gray track and a Success Green fill. Percentage text should be placed to the right in `label-md`.
- **Input Fields:** Outlined style with 1px border. Focused state uses a 2px Education Blue border and a soft blue outer glow.
- **Cards:** White surfaces with 16px rounded corners, used to encapsulate high-level metrics like "Total Students" or "Course Rating."
import React, { useState } from 'react';
import { Pet } from '../types';

interface TeamScreenProps {
  pets: Pet[];
  activePetId: string;
  stars: number;
  onSelectPet: (petId: string) => void;
  onUpgradePet: (petId: string, cost: number) => void;
  onAddStars: (amount: number) => void;
  triggerAudioFeed: () => void;
  triggerAudioLevelUp: () => void;
  triggerAudioTrain: () => void;
}

export default function TeamScreen({
  pets,
  activePetId,
  stars,
  onSelectPet,
  onUpgradePet,
  onAddStars,
  triggerAudioFeed,
  triggerAudioLevelUp,
  triggerAudioTrain,
}: TeamScreenProps) {
  const activePet = pets.find((p) => p.id === activePetId) || pets[0];
  const [activeItemSlot, setActiveItemSlot] = useState<number | null>(null);
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const availableItems = [
    { name: 'Charged Talisman', bonus: '+25 Speed', icon: 'electric_bolt' },
    { name: 'Granite Shield', bonus: '+35 Defense', icon: 'shield_with_heart' },
    { name: 'Fire Dragon Ruby', bonus: '+40 Attack', icon: 'local_fire_department' },
    { name: 'Star Pearl', bonus: '+50 Stamina', icon: 'wb_sunny' },
  ];

  const handleUpgrade = () => {
    const cost = activePet.level * 35; // level-dependent cost
    if (stars < cost) {
      setMessage(`❌ Insufficient gold fragments! Need ${cost} stars to upgrade ${activePet.name}.`);
      triggerAudioTrain();
      return;
    }

    onUpgradePet(activePet.id, cost);
    triggerAudioLevelUp();
    setMessage(`✨ Success! Upgraded ${activePet.name} to LVL ${activePet.level + 1}! Attributes gained +5.`);
  };

  const handleEquipItem = (itemName: string) => {
    if (activeItemSlot === null) return;
    triggerAudioFeed();

    const updatedHeld = [...activePet.heldItems];
    updatedHeld[activeItemSlot] = itemName;

    // Apply item trigger
    activePet.heldItems = updatedHeld;
    setActiveItemSlot(null);
    setMessage(`🛡️ Equipped "${itemName}" in Slot ${activeItemSlot + 1}!`);
  };

  const currentEvoPath = activePet.evolutionPath;
  const isEvoUnlocked = activePet.level >= currentEvoPath.levelRequired;

  return (
    <div className="relative w-full h-full text-brand-on-surface" id="team-screen-root">
      <div className="pt-2 px-4 pb-28 max-w-lg mx-auto overflow-y-auto h-full no-scrollbar">
        
        {/* Companion Selector List */}
        <div className="flex gap-2.5 mb-3 overflow-x-auto py-1.5 no-scrollbar border-b border-white/5 scroll-smooth">
          {pets.map((p) => (
            <button
              key={p.id}
              onClick={() => { triggerAudioFeed(); onSelectPet(p.id); setMessage(null); }}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border transition-all cursor-pointer shrink-0 ${
                p.id === activePetId
                  ? 'bg-brand-primary-container/20 border-brand-primary text-brand-primary shadow-[0_0_12px_rgba(0,224,255,0.25)]'
                  : 'bg-brand-surface-high border-white/10 text-brand-on-surface-variant hover:border-white/20'
              }`}
            >
              <img className="w-6 h-6 rounded-md object-contain" src={p.thumbnail} alt={p.name} referrerPolicy="no-referrer" />
              <div className="text-left">
                <p className="text-[11px] font-bold tracking-tight">{p.name}</p>
                <p className="text-[9px] font-mono opacity-80">LV. {p.level}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Hero Section: Pet Avatar & Equipment */}
        <div className="relative flex flex-col items-center">
          
          {/* Ambient Background Glow matching the species */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-brand-primary/10 rounded-full blur-[80px] animate-pulse-glow"></div>
          
          <div className="relative z-10 w-full aspect-square max-w-[240px] glass-panel rounded-3xl flex items-center justify-center p-4 mb-4 transition-all duration-500 hover:scale-[1.03]">
            
            <img 
              className="w-full h-full object-contain filter drop-shadow-[0_15px_30px_rgba(0,224,255,0.4)] pointer-events-auto" 
              src={activePet.image} 
              alt={activePet.name}
              referrerPolicy="no-referrer"
            />

            {/* Held Items Equipment Slots */}
            <div className="absolute -right-3 top-1/4 flex flex-col gap-2.5">
              {[0, 1].map((idx) => {
                const item = activePet.heldItems[idx];
                return (
                  <div 
                    key={idx}
                    onClick={() => { triggerAudioFeed(); setActiveItemSlot(idx); }}
                    className={`w-11 h-11 glass-panel rounded-xl flex items-center justify-center shadow-lg cursor-pointer group active:scale-90 transition-all ${
                      item ? 'border-brand-secondary bg-brand-secondary/10' : 'border-brand-primary/40 hover:border-brand-primary'
                    }`}
                  >
                    {item ? (
                      <span className="material-symbols-outlined text-brand-secondary text-sm font-bold animate-pulse">check_circle</span>
                    ) : (
                      <span className="material-symbols-outlined text-brand-primary/45 group-hover:text-brand-primary text-base">add_box</span>
                    )}

                    <div className="absolute right-full mr-1 px-1.5 py-0.5 bg-brand-surface-high text-[8px] rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap text-white">
                      {item ? `${item}` : 'Empty Slot'}
                    </div>
                  </div>
                );
              })}
            </div>

          </div>

          <div className="text-center mb-4">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <h2 className="font-display text-2xl font-black text-white">{activePet.name}</h2>
              <span className="px-2 py-0.5 rounded-full bg-brand-primary-container/20 border border-brand-primary/50 text-brand-primary-container font-mono text-[10px] font-bold">
                LVL {activePet.level}
              </span>
            </div>
            <p className="text-xs text-brand-on-surface-variant">{activePet.description}</p>
          </div>
        </div>

        {/* Action message feedback card */}
        {message && (
          <div className="glass-panel text-center py-2 px-3 rounded-xl max-w-sm mx-auto mb-3 border-brand-primary/20 bg-slate-900/90 shadow-md">
            <p className="text-xs font-semibold text-brand-primary">{message}</p>
          </div>
        )}

        {/* Equipment Selector Popover overlay */}
        {activeItemSlot !== null && (
          <div className="glass-panel p-3 rounded-2xl border-brand-primary bg-slate-950/95 shadow-2xl mb-4 text-center">
            <div className="flex justify-between items-center mb-2 border-b border-white/5 pb-1">
              <span className="text-xs font-bold text-white uppercase tracking-wider">Select Item for Slot {activeItemSlot + 1}</span>
              <button onClick={() => setActiveItemSlot(null)} className="text-[10px] text-brand-error font-medium">Cancel</button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {availableItems.map((item, index) => (
                <button
                  key={index}
                  onClick={() => handleEquipItem(item.name)}
                  className="p-2 bg-brand-surface-high rounded-xl border border-white/10 hover:border-brand-primary text-left hover:bg-slate-900 cursor-pointer text-xs transition-colors"
                >
                  <div className="flex items-center gap-1 text-brand-primary font-bold">
                    <span className="material-symbols-outlined text-xs">{item.icon}</span>
                    <span className="truncate">{item.name}</span>
                  </div>
                  <span className="text-[9px] text-brand-on-surface-variant font-mono">{item.bonus}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Bento Grid: Stats & Evolution */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          
          {/* Base Attributes card */}
          <div className="glass-panel rounded-2xl p-4 flex flex-col gap-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-bold text-brand-primary uppercase tracking-widest">Base Attributes</h3>
              <span className="material-symbols-outlined text-brand-primary block text-sm">analytics</span>
            </div>

            <div className="space-y-3">
              {/* Attack */}
              <div className="space-y-1">
                <div className="flex justify-between items-end text-xs">
                  <span className="text-brand-on-surface-variant font-medium">Attack Strength</span>
                  <span className="font-mono font-bold text-brand-primary">{activePet.attributes.attack} / {activePet.maxAttributeVal}</span>
                </div>
                <div className="h-2.5 bg-brand-surface-highest rounded-full overflow-hidden border border-white/5">
                  <div 
                    className="h-full bg-gradient-to-r from-brand-primary to-blue-500 stat-bar-glow rounded-full transition-all duration-500" 
                    style={{ width: `${(activePet.attributes.attack / activePet.maxAttributeVal) * 100}%` }}
                  ></div>
                </div>
              </div>

              {/* Defense */}
              <div className="space-y-1">
                <div className="flex justify-between items-end text-xs">
                  <span className="text-brand-on-surface-variant font-medium">Defense Armor</span>
                  <span className="font-mono font-bold text-brand-primary">{activePet.attributes.defense} / {activePet.maxAttributeVal}</span>
                </div>
                <div className="h-2.5 bg-brand-surface-highest rounded-full overflow-hidden border border-white/5">
                  <div 
                    className="h-full bg-gradient-to-r from-brand-primary to-blue-500 stat-bar-glow rounded-full transition-all duration-500" 
                    style={{ width: `${(activePet.attributes.defense / activePet.maxAttributeVal) * 100}%` }}
                  ></div>
                </div>
              </div>

              {/* Speed */}
              <div className="space-y-1">
                <div className="flex justify-between items-end text-xs">
                  <span className="text-brand-on-surface-variant font-medium">Lithe Speed</span>
                  <span className="font-mono font-bold text-brand-primary">{activePet.attributes.speed} / {activePet.maxAttributeVal}</span>
                </div>
                <div className="h-2.5 bg-brand-surface-highest rounded-full overflow-hidden border border-white/5">
                  <div 
                    className="h-full bg-gradient-to-r from-brand-primary to-blue-500 stat-bar-glow rounded-full transition-all duration-500" 
                    style={{ width: `${(activePet.attributes.speed / activePet.maxAttributeVal) * 100}%` }}
                  ></div>
                </div>
              </div>

              {/* Stamina */}
              <div className="space-y-1">
                <div className="flex justify-between items-end text-xs">
                  <span className="text-brand-on-surface-variant font-medium">Stamina Power</span>
                  <span className="font-mono font-bold text-brand-primary">{activePet.attributes.stamina} / {activePet.maxAttributeVal}</span>
                </div>
                <div className="h-2.5 bg-brand-surface-highest rounded-full overflow-hidden border border-white/5">
                  <div 
                    className="h-full bg-gradient-to-r from-brand-primary to-blue-500 stat-bar-glow rounded-full transition-all duration-500" 
                    style={{ width: `${(activePet.attributes.stamina / activePet.maxAttributeVal) * 100}%` }}
                  ></div>
                </div>
              </div>

            </div>
          </div>

          {/* Evolution Tree Card */}
          <div className="glass-panel rounded-2xl p-4 flex flex-col">
            <h3 className="text-xs font-bold text-brand-primary uppercase tracking-widest mb-3">Evolution Path</h3>
            
            <div className="flex-grow flex flex-col items-center justify-around py-2.5">
              {/* Current Stage */}
              <div className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 rounded-xl bg-brand-primary/10 border border-brand-primary flex items-center justify-center">
                  <img className="w-8 h-8 object-contain" src={activePet.thumbnail} alt={activePet.name} registrar-alt="" referrerPolicy="no-referrer" />
                </div>
                <span className="font-mono text-[9px] font-bold text-white uppercase">{activePet.name}</span>
              </div>

              {/* Evolution Requirement Connector */}
              <div className="flex flex-col items-center py-1.5 text-center">
                <div className="w-0.5 h-6 bg-gradient-to-b from-brand-primary to-brand-surface-highest"></div>
                
                <div className={`my-1.5 px-2.5 py-0.5 rounded-full border flex items-center gap-1 select-none ${
                  isEvoUnlocked 
                    ? 'bg-brand-secondary/20 border-brand-secondary text-brand-secondary' 
                    : 'bg-brand-surface-high border-brand-error/20 text-brand-error'
                }`}>
                  <span className="material-symbols-outlined text-[12px]">
                    {isEvoUnlocked ? 'check_circle' : 'lock'}
                  </span>
                  <span className="font-mono text-[8px] font-bold">
                    {isEvoUnlocked ? 'EVOLVABLE NOW' : `LVL ${currentEvoPath.levelRequired} REQUIRED`}
                  </span>
                </div>

                <div className="w-0.5 h-6 bg-brand-surface-highest"></div>
              </div>

              {/* Locked Stage */}
              <div className={`flex flex-col items-center gap-1 ${isEvoUnlocked ? 'opacity-100 animate-pulse' : 'opacity-40'}`}>
                <div className={`w-12 h-12 rounded-xl border flex items-center justify-center ${
                  isEvoUnlocked ? 'bg-brand-secondary/10 border-brand-secondary border-solid' : 'bg-brand-surface-highest border-dashed border-white/20'
                }`}>
                  <span className="material-symbols-outlined text-sm text-brand-on-surface-variant font-bold">question_mark</span>
                </div>
                <span className="font-mono text-[9px] text-brand-on-surface-variant uppercase">{currentEvoPath.nextName}</span>
              </div>

            </div>
          </div>

        </div>

        {/* Dynamic Skill Lab panel */}
        {selectedSkill && (
          <div className="glass-panel p-3 rounded-2xl bg-slate-900 border-white/10 mb-4 text-center">
            <span className="text-xs font-bold text-brand-primary block uppercase mb-1">Active Skill Modifier</span>
            <p className="text-xs text-brand-on-surface leading-normal font-medium">{selectedSkill}</p>
          </div>
        )}

        {/* Action Button Section */}
        <div className="flex gap-2 p-1">
          <button 
            id="team-btn-upgrade"
            onClick={handleUpgrade}
            className="flex-1 squishy-button bg-brand-primary-container text-brand-on-primary-container font-display text-[14px] font-black py-3.5 rounded-2xl border-b-[4px] border-brand-on-primary-container shadow-[0_4px_20px_rgba(0,224,255,0.25)] shrink-0 cursor-pointer"
          >
            Upgrade Pet Spirit (cost: {activePet.level * 35})
          </button>
          
          <button 
            id="team-btn-skills"
            onClick={() => {
              triggerAudioFeed();
              const skills = [
                'Hydro Vortex: boosts Special critical modifier by +1.5x.',
                'Frenzy Core: health bars deplete at 5% slowed rate.',
                'Volt Reflex: +12% speed evasion on lava storms.',
                'Regen Matrix: Restores 3 energy ticks per minute.'
              ];
              const randomSkill = skills[Math.floor(Math.random() * skills.length)];
              setSelectedSkill(randomSkill);
              setMessage('✨ Loaded a temporary Skills Lab passive modifier!');
            }}
            className="flex-1 squishy-button glass-panel text-brand-primary font-display text-[14px] font-black py-3.5 rounded-2xl border-b-[4px] border-brand-primary/20 shrink-0 cursor-pointer"
          >
            Skills Lab
          </button>
        </div>

      </div>
    </div>
  );
}

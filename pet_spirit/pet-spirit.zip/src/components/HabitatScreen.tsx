import React, { useState } from 'react';
import { Pet } from '../types';
import { Sparkles, Flower, Star, Zap, Utensils, Gamepad2, Dumbbell, Snowflake } from 'lucide-react';

interface HabitatScreenProps {
  pet: Pet;
  stars: number;
  energyPills: string;
  onUpdatePet: (updatedPet: Pet) => void;
  onAddStars: (amount: number) => void;
  triggerAudioFeed: () => void;
  triggerAudioLevelUp: () => void;
  triggerAudioTrain: () => void;
}

export default function HabitatScreen({
  pet,
  stars,
  energyPills,
  onUpdatePet,
  onAddStars,
  triggerAudioFeed,
  triggerAudioLevelUp,
  triggerAudioTrain,
}: HabitatScreenProps) {
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [animationClass, setAnimationClass] = useState<string>('animate-float');
  const [particles, setParticles] = useState<{ id: number; x: number; y: number; color: string }[]>([]);

  const triggerParticles = (color: string) => {
    const list = Array.from({ length: 15 }).map((_, i) => ({
      id: Date.now() + i,
      x: 30 + Math.random() * 40, // percentage x
      y: 40 + Math.random() * 40, // percentage y
      color,
    }));
    setParticles(list);
    setTimeout(() => {
      setParticles([]);
    }, 1200);
  };

  const handleFeed = () => {
    triggerAudioFeed();
    const curHp = pet.health;
    const curEnergy = pet.energy;
    const newHp = Math.min(pet.maxHealth, curHp + 25);
    const newEnergy = Math.min(pet.maxEnergy, curEnergy + 20);

    onUpdatePet({
      ...pet,
      health: newHp,
      energy: newEnergy,
    });
    setActionMessage(`${pet.name} matches your care! Refed and gained +25 HP and +20 Energy.`);
    triggerParticles('#2ff801');

    setAnimationClass('animate-bounce');
    setTimeout(() => {
      setAnimationClass('animate-float');
    }, 1000);
  };

  const handlePlay = () => {
    if (pet.energy < 15) {
      setActionMessage(`Not enough Energy to play! Feed ${pet.name} first.`);
      triggerParticles('#ffb4ab');
      return;
    }
    triggerAudioFeed();
    const newEnergy = Math.max(0, pet.energy - 15);
    // XP gain inside level
    const randXp = 15;
    const attributes = { ...pet.attributes };
    attributes.speed = Math.min(pet.maxAttributeVal, attributes.speed + 1);

    onUpdatePet({
      ...pet,
      energy: newEnergy,
      attributes,
    });
    setActionMessage(`${pet.name} is super happy playing with you! Speed increased! Energy -15.`);
    triggerParticles('#00e0ff');

    setAnimationClass('scale-125 rotate-6 duration-300');
    setTimeout(() => {
      setAnimationClass('animate-float');
    }, 500);
  };

  const handleTrain = () => {
    if (pet.energy < 25) {
      setActionMessage(`Not enough Energy to train! ${pet.name} needs a break.`);
      triggerParticles('#ffb4ab');
      return;
    }
    triggerAudioTrain();
    const newEnergy = Math.max(0, pet.energy - 25);
    const attributes = { ...pet.attributes };
    attributes.attack = Math.min(pet.maxAttributeVal, attributes.attack + 2);
    attributes.stamina = Math.min(pet.maxAttributeVal, attributes.stamina + 2);

    // Chance to level up
    let newLevel = pet.level;
    let leveledUp = false;
    if (Math.random() > 0.4) {
      newLevel += 1;
      leveledUp = true;
      triggerAudioLevelUp();
      onAddStars(120);
    }

    onUpdatePet({
      ...pet,
      level: newLevel,
      energy: newEnergy,
      attributes,
    });

    if (leveledUp) {
      setActionMessage(`✨ LEVEL UP! ${pet.name} reached LVL ${newLevel}! Attributes increased, got +120 Stars!`);
      triggerParticles('#ffdffd');
      setAnimationClass('animate-pulse scale-110 border-primary-container border-2 duration-1000');
    } else {
      setActionMessage(`Intense practice! ${pet.name} gained +2 Attack and +2 Stamina. Energy -25.`);
      triggerParticles('#ffd6fe');
      setAnimationClass('animate-bounce');
    }

    setTimeout(() => {
      setAnimationClass('animate-float');
    }, 1200);
  };

  const handleClean = () => {
    triggerAudioFeed();
    const newHp = pet.maxHealth;
    onUpdatePet({
      ...pet,
      health: newHp,
    });
    setActionMessage(`${pet.name} was pampered with sparkling celestial elements. Full Health restored!`);
    triggerParticles('#baf2ff');

    setAnimationClass('scale-95 duration-2 * rotate-12');
    setTimeout(() => {
      setAnimationClass('animate-float');
    }, 500);
  };

  const hpPercentage = `${(pet.health / pet.maxHealth) * 100}%`;
  const energyPercentage = `${(pet.energy / pet.maxEnergy) * 100}%`;

  return (
    <div className="relative w-full h-full flex flex-col justify-between" id="habitat-screen-root">
      
      {/* HUD Bar (HP/Energy & Stars) */}
      <div className="relative z-10 px-4 mt-3 flex justify-between items-start gap-4">
        
        {/* Monster Profile Card */}
        <div className="glass-panel rounded-xl p-4 flex flex-col gap-3 w-2/3 max-w-[245px] transition-all hover:scale-105 duration-300">
          <div className="flex justify-between items-center">
            <span className="font-display text-xl font-bold tracking-tight text-white">{pet.name}</span>
            <div className="bg-brand-primary-container/20 px-2 py-0.5 rounded-lg border border-brand-primary/30">
              <span className="font-mono text-xs font-bold text-brand-primary-container tracking-wider">LVL {pet.level}</span>
            </div>
          </div>
          
          <div className="space-y-2.5">
            {/* HP Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-bold uppercase tracking-wider text-brand-secondary">
                <span>Health</span>
                <span className="font-mono">{pet.health}/{pet.maxHealth}</span>
              </div>
              <div className="h-2 w-full bg-brand-surface-highest/80 rounded-full overflow-hidden">
                <div 
                  className="stat-bar-fill h-full bg-linear-to-r from-brand-secondary-container to-teal-400 rounded-full" 
                  style={{ width: hpPercentage }}
                ></div>
              </div>
            </div>
            
            {/* Energy Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-bold uppercase tracking-wider text-brand-primary-container">
                <span>Energy</span>
                <span className="font-mono">{pet.energy}/{pet.maxEnergy}</span>
              </div>
              <div className="h-2 w-full bg-brand-surface-highest/80 rounded-full overflow-hidden">
                <div 
                  className="stat-bar-fill h-full bg-linear-to-r from-brand-primary-container to-blue-500 rounded-full" 
                  style={{ width: energyPercentage }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Secondary Stats Floating */}
        <div className="flex flex-col gap-2.5 items-end">
          <div className="glass-panel px-4 py-2 rounded-full flex items-center gap-2 shadow-[0_4px_12px_rgba(0,0,0,0.5)] bg-slate-900/60 border-brand-tertiary-fixed/20">
            <span className="material-symbols-outlined text-brand-tertiary-fixed text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>star</span>
            <span className="font-mono text-sm font-bold text-white tracking-wide">{stars.toLocaleString()}</span>
          </div>
          <div className="glass-panel px-4 py-2 rounded-full flex items-center gap-2 shadow-[0_4px_12px_rgba(0,0,0,0.5)] bg-slate-900/60 border-brand-primary/20">
            <span className="material-symbols-outlined text-brand-primary text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>bolt</span>
            <span className="font-mono text-sm font-bold text-white tracking-wide">{energyPills}</span>
          </div>
        </div>

      </div>

      {/* Narrative Event Log Notification */}
      <div className="absolute top-36 inset-x-4 z-30 transition-all duration-300 pointer-events-none">
        {actionMessage ? (
          <div className="glass-panel rounded-xl py-2 px-4 shadow-lg text-center max-w-sm mx-auto border-brand-primary-container/30 bg-slate-900/90 pointer-events-auto">
            <p className="text-xs text-brand-primary leading-snug font-medium">
              {actionMessage}
            </p>
            <button 
              onClick={() => setActionMessage(null)} 
              className="text-[10px] text-brand-on-surface-variant hover:text-white underline mt-1 cursor-pointer block mx-auto py-0.5 px-2"
            >
              Dismiss
            </button>
          </div>
        ) : (
          <div className="text-center opacity-40 text-[10px] tracking-wider uppercase text-brand-on-surface-variant font-medium select-none">
            Tap pet utilities below to train & nurture Sparky
          </div>
        )}
      </div>

      {/* Central Animated Monster Section with Ground Glow & Floating Particles */}
      <div className="relative flex-1 flex flex-col justify-center items-center py-2 z-10 pointer-events-none">
        
        {/* Dynamic click-generated particles */}
        {particles.map((p) => (
          <div
            key={p.id}
            className="absolute w-2 h-2 rounded-full animate-ping pointer-events-none z-20"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              backgroundColor: p.color,
              filter: `drop-shadow(0 0 6px ${p.color})`,
            }}
          />
        ))}

        <div className={`relative w-64 h-64 md:w-72 md:h-72 flex flex-col items-center justify-center pointer-events-auto cursor-pointer select-none transition-all duration-500 ${animationClass}`}>
          <img 
            className="w-full h-full object-contain drop-shadow-[0_25px_45px_rgba(0,224,255,0.45)] transition-all" 
            src={pet.image} 
            alt={pet.name}
            referrerPolicy="no-referrer"
            onClick={() => {
              triggerAudioFeed();
              triggerParticles('#00daf8');
              setActionMessage(`*Giggle* ${pet.name} sparkles with electrical joy!`);
            }}
          />
          {/* Ground shadow */}
          <div className="w-40 h-5 bg-black/50 blur-lg rounded-full -mt-4 transform scale-x-125 opacity-80 pointer-events-none"></div>
        </div>
      </div>

      {/* Action Grid Panel - Bottom Section */}
      <div className="relative w-full px-4 pb-2 z-20">
        <div className="grid grid-cols-4 gap-2.5 max-w-md mx-auto">
          
          <button 
            id="action-btn-feed"
            onClick={handleFeed}
            className="squishy-btn flex flex-col items-center justify-center gap-1.5 bg-brand-surface-high border-brand-surface-highest text-white p-3 rounded-2xl shadow-xl hover:bg-slate-800 transition-colors focus:outline-none"
          >
            <span className="material-symbols-outlined text-brand-secondary text-[24px]">restaurant</span>
            <span className="font-sans text-[12px] font-bold tracking-tight">Feed</span>
          </button>
          
          <button 
            id="action-btn-play"
            onClick={handlePlay}
            className="squishy-btn flex flex-col items-center justify-center gap-1.5 bg-brand-surface-high border-brand-surface-highest text-white p-3 rounded-2xl shadow-xl hover:bg-slate-800 transition-colors focus:outline-none"
          >
            <span className="material-symbols-outlined text-brand-primary text-[24px]">sports_esports</span>
            <span className="font-sans text-[12px] font-bold tracking-tight">Play</span>
          </button>
          
          <button 
            id="action-btn-train"
            onClick={handleTrain}
            className="squishy-btn flex flex-col items-center justify-center gap-1.5 bg-brand-surface-high border-brand-surface-highest text-white p-3 rounded-2xl shadow-xl hover:bg-slate-800 transition-colors focus:outline-none"
          >
            <span className="material-symbols-outlined text-[#e2bae1] text-[24px]">fitness_center</span>
            <span className="font-sans text-[12px] font-bold tracking-tight">Train</span>
          </button>
          
          <button 
            id="action-btn-clean"
            onClick={handleClean}
            className="squishy-btn flex flex-col items-center justify-center gap-1.5 bg-brand-surface-high border-brand-surface-highest text-white p-3 rounded-2xl shadow-xl hover:bg-slate-800 transition-colors focus:outline-none"
          >
            <span className="material-symbols-outlined text-brand-on-surface-variant text-[24px]">soap</span>
            <span className="font-sans text-[12px] font-bold tracking-tight">Clean</span>
          </button>
          
        </div>
      </div>

    </div>
  );
}

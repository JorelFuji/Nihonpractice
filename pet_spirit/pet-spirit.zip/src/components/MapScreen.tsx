import React, { useState } from 'react';
import { Sparkles, Backpack, Lock, RefreshCw, Send, CheckCircle2 } from 'lucide-react';

interface MapScreenProps {
  completedNodes: string[];
  currentPlayerNode: string;
  stars: number;
  adventureProgress: number;
  onCompleteNode: (nodeId: string) => void;
  onAddStars: (amount: number) => void;
  onStartBossBattle: () => void;
  onUseEnergyPill: () => void;
  triggerAudioFeed: () => void;
  triggerAudioLevelUp: () => void;
  energyPills: number;
}

export default function MapScreen({
  completedNodes,
  currentPlayerNode,
  stars,
  adventureProgress,
  onCompleteNode,
  onAddStars,
  onStartBossBattle,
  onUseEnergyPill,
  triggerAudioFeed,
  triggerAudioLevelUp,
  energyPills,
}: MapScreenProps) {
  const [mapOffset, setMapOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [activeNotification, setActiveNotification] = useState<string | null>(null);
  const [showInventory, setShowInventory] = useState<boolean>(false);

  // Drag handlers
  const handleStartDrag = (e: React.MouseEvent | React.TouchEvent) => {
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    setDragStart({ x: clientX - mapOffset.x, y: clientY - mapOffset.y });
  };

  const handleDrag = (e: React.MouseEvent | React.TouchEvent) => {
    if (!dragStart) return;
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    
    // Constrain map scroll bounds
    const nextX = Math.min(Math.max(clientX - dragStart.x, -300), 300);
    const nextY = Math.min(Math.max(clientY - dragStart.y, -150), 150);
    setMapOffset({ x: nextX, y: nextY });
  };

  const handleEndDrag = () => {
    setDragStart(null);
  };

  const handleNodeClick = (nodeId: string, name: string, starsReward: number) => {
    triggerAudioFeed();
    if (completedNodes.includes(nodeId)) {
      setActiveNotification(`You have already completed Level ${nodeId} in Whispering Woods! Retrying for fun.`);
      return;
    }

    onCompleteNode(nodeId);
    onAddStars(starsReward);
    triggerAudioLevelUp();
    setActiveNotification(`✨ Success! You completed Level ${nodeId} (${name})! Earned +${starsReward} Star fragments.`);
  };

  const handleBossClick = () => {
    triggerAudioLevelUp();
    setActiveNotification('⚔️ Activating Portal! Teleporting you to the Arena to fight NEON DRAKE...');
    setTimeout(() => {
      onStartBossBattle();
    }, 1500);
  };

  return (
    <div className="relative w-full h-full overflow-hidden select-none" id="map-screen-viewport">
      
      {/* Interactive Map Drag Container */}
      <div 
        className="absolute inset-0 transition-transform duration-100 ease-out cursor-grab active:cursor-grabbing flex items-center justify-center"
        onMouseDown={handleStartDrag}
        onMouseMove={handleDrag}
        onMouseUp={handleEndDrag}
        onMouseLeave={handleEndDrag}
        onTouchStart={handleStartDrag}
        onTouchMove={handleDrag}
        onTouchEnd={handleEndDrag}
        style={{ transform: `scale(1.1) translate(${mapOffset.x}px, ${mapOffset.y}px)` }}
      >
        
        {/* Connection pathways between Biomes */}
        <svg className="absolute w-[1400px] h-[900px] pointer-events-none" viewBox="0 0 1400 900">
          {/* Path 1: Forest to Lava Core */}
          <path 
            className="path-line" 
            d="M 280 430 Q 450 350 640 500 T 980 320" 
            fill="none" 
            stroke="rgba(0, 224, 255, 0.25)" 
            strokeWidth="5"
          />
          {/* Path 2: Lava to Frost Tundra */}
          <path 
            d="M 640 500 Q 820 620 980 620" 
            fill="none" 
            stroke="rgba(0, 224, 255, 0.15)" 
            strokeDasharray="10 10" 
            strokeWidth="4"
          />
        </svg>

        {/* =======================================
            BIOME 1: WHISPERING WOODS
           ======================================= */}
        <div className="absolute left-[80px] top-[260px] animate-float" style={{ animationDelay: '0s' }}>
          <div className="group flex flex-col items-center">
            
            <div className="w-48 h-32 glass-panel rounded-[2rem] flex items-center justify-center shadow-xl border-emerald-400/20 relative overflow-hidden">
              <div className="absolute inset-0 bg-emerald-500/5"></div>
              <img 
                className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-all duration-500" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAApUnngAbs3uCecBzb5JF0iwmuj_MOdixDFiYwyCYnvrzLIkcPNROyQaRrH7jQAh7BkV7BZQ8LIMJOVqZTb326yAKQ5shgSTwdzshw2YXqrswOzkqTna9l9yL99N18EtU6DNnN6tYtONe4ffC9Y6SJ40cEADYxGEsxGmM8O-gErXClyhd_Vx9OU6MuWu4vOmjnlHWRUeFN2fIQlOhy_cdQOAgJAgoXaqxipIi8iIJcgtKQZ_lMMtq1dj4CafwApCnPmQ6ScZIlrWY" 
                alt="Whispering Woods"
                referrerPolicy="no-referrer"
              />
              <span className="absolute material-symbols-outlined text-4xl text-brand-secondary drop-shadow-xl select-none">forest</span>
            </div>

            {/* Level Selector Nodes */}
            <div className="mt-3 flex gap-2.5 z-20">
              <button 
                onClick={() => handleNodeClick('1-1', 'Mossy Trails', 80)}
                className={`w-9 h-9 rounded-full font-mono text-xs font-extrabold flex items-center justify-center shadow-lg transform active:scale-95 transition-all cursor-pointer ${
                  completedNodes.includes('1-1') 
                  ? 'bg-brand-secondary text-[#053900]' 
                  : 'bg-emerald-900 border border-brand-secondary text-brand-secondary'
                }`}
              >
                {completedNodes.includes('1-1') ? '✓' : '1-1'}
              </button>

              <button 
                onClick={() => handleNodeClick('1-2', 'Biolume cavern', 100)}
                className={`w-9 h-9 rounded-full font-mono text-xs font-extrabold flex items-center justify-center shadow-lg transform active:scale-95 transition-all cursor-pointer ${
                  completedNodes.includes('1-2') 
                  ? 'bg-brand-secondary text-[#053900]' 
                  : 'bg-emerald-900 border border-brand-secondary text-brand-secondary'
                }`}
              >
                {completedNodes.includes('1-2') ? '✓' : '1-2'}
              </button>

              <button 
                onClick={handleBossClick}
                className="w-11 h-11 rounded-full bg-brand-error text-brand-error-container font-mono text-[10px] font-extrabold flex items-center justify-center shadow-[0_0_15px_rgba(255,75,75,0.7)] hover:shadow-[0_0_25px_rgba(255,100,100,0.9)] transform active:scale-90 transition-all cursor-pointer border border-[#ffdad6]/40 shrink-0"
              >
                BOSS
              </button>
            </div>

            <span className="mt-2 font-display text-[11px] font-extrabold text-brand-secondary tracking-widest uppercase">Whispering Woods</span>
          </div>
        </div>

        {/* =======================================
            BIOME 2: MAGMA CORE (ACTIVE BIOME)
           ======================================= */}
        <div className="absolute left-[540px] top-[400px] animate-float" style={{ animationDelay: '1.5s' }}>
          <div className="group flex flex-col items-center">
            
            <div className="w-52 h-34 glass-panel rounded-[2rem] flex items-center justify-center shadow-xl border-brand-error/25 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-error/5"></div>
              <img 
                className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-all duration-500" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuC6AQIadre7PHuPh9i43YJGNcR2VW-fn2nUlmItK-OEp8hiDtnroeDKuEb_ZdMkZGBc9G6ZcgjGiEsNYgnKWMZvCa0xGidUSNI0Nu8H5mbdGT5YiU_tl9WvDUAHzCnDST2J1AIniR-oJimT3dahzia3XzKayaZbOkIfw_7fYCuCY15YNGLjRoV9D3JB7jJZ8p77AyLGbcBTQpiBCMt4tJZ36Icw4dm0LW0KqRoJezCb6a4yXYkvElWTzA50rjdsbk5PXM48PQ08ijU" 
                alt="Magma Core"
                referrerPolicy="no-referrer"
              />
              <span className="absolute material-symbols-outlined text-4xl text-brand-error drop-shadow-xl select-none">volcano</span>
            </div>

            {/* Current Player Pin Locator overlay */}
            <div className="absolute -top-10 left-1/2 -translate-x-1/2 filter drop-shadow-[0_0_8px_rgba(0,224,255,0.85)] z-10 animate-bounce">
              <span className="material-symbols-outlined text-brand-primary-container text-4xl" style={{ fontVariationSettings: "'FILL' 1" }}>location_on</span>
            </div>

            <div className="mt-3 flex gap-2.5 z-20">
              <button 
                onClick={() => handleNodeClick('2-1', 'Obsidian Crack', 150)}
                className="w-9 h-9 rounded-full bg-brand-surface-high border border-brand-error/40 text-brand-error font-mono text-xs font-extrabold flex items-center justify-center shadow-lg opacity-60 hover:opacity-100 transition-all cursor-pointer"
              >
                2-1
              </button>
              <button 
                onClick={() => handleNodeClick('2-2', 'Basalt Forge', 180)}
                className="w-9 h-9 rounded-full bg-brand-surface-high border border-brand-error/40 text-brand-error font-mono text-xs font-extrabold flex items-center justify-center shadow-lg opacity-60 hover:opacity-100 transition-all cursor-pointer"
              >
                2-2
              </button>
            </div>

            <span className="mt-2 font-display text-[11px] font-extrabold text-[#ffd6fe] tracking-widest uppercase">Magma Core</span>
          </div>
        </div>

        {/* =======================================
            BIOME 3: GLACIAL PEAK (LOCKED BIOME)
           ======================================= */}
        <div className="absolute left-[950px] top-[200px] animate-float" style={{ animationDelay: '3s' }}>
          <div className="group flex flex-col items-center">
            
            <div className="w-52 h-34 glass-panel rounded-[2rem] flex items-center justify-center shadow-xl border-brand-primary/20 relative overflow-hidden opacity-60">
              <div className="absolute inset-0 bg-brand-primary/5"></div>
              <img 
                className="w-full h-full object-cover opacity-80" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDWnP73vpRkHM9-qojueriMrB61IqlqUBiAr0j53F4e83DMEZJuPwhYMcTsCoWTguXKxcawJqJ2qF8jArOP_Voz6YBDLMels9bCFl-Kdyd57wPQxWVXxZYhilVs7sZoyNlZbB-TgS3ZJxOblzZJ7K95p6VW2aoW-lglab4k0HqVR29RPJFgVwn-Ovu_FEoYY99Pm-O4K8HfBCsRL2BxLZmWmKVmC6fk09I_u06X0HG0H4pFGlYS6Q7wjCJqJwnNQOMppggre7kv_eE" 
                alt="Glacial Peak"
                referrerPolicy="no-referrer"
              />
              <span className="absolute material-symbols-outlined text-4xl text-brand-primary drop-shadow-xl select-none">ac_unit</span>
              <div className="absolute inset-0 bg-brand-bg/60 flex items-center justify-center">
                <span className="material-symbols-outlined text-3xl text-white/50">lock</span>
              </div>
            </div>

            <span className="mt-2 font-display text-[11px] font-extrabold text-brand-primary/40 tracking-widest uppercase">Glacial Peak</span>
          </div>
        </div>

      </div>

      {/* Progress Card (HUD top overlay) */}
      <div className="absolute top-4 left-4 z-20">
        <div className="glass-panel p-4 rounded-xl shadow-[0_8px_30px_rgba(0,0,0,0.5)] flex flex-col gap-2 min-w-[210px] bg-slate-900/80">
          <div className="flex justify-between items-center">
            <span className="font-sans text-[10px] font-semibold text-brand-on-surface-variant uppercase tracking-wide">Adventure Progress</span>
            <span className="material-symbols-outlined text-brand-primary text-lg">star</span>
          </div>
          
          <div className="flex items-end gap-1">
            <span className="font-display text-3xl font-extrabold text-brand-primary">{adventureProgress}</span>
            <span className="font-display text-base text-brand-on-surface-variant pb-1">/ 30</span>
          </div>

          <div className="w-full h-2 bg-brand-surface-highest rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-brand-primary to-blue-500 shadow-[0_0_10px_rgba(0,224,255,0.6)] transition-all duration-500" 
              style={{ width: `${(adventureProgress / 30) * 100}%` }}
            ></div>
          </div>

          <div className="flex justify-between font-mono text-[10px] text-brand-on-surface-variant">
            <span>Stars Collected</span>
            <span>{Math.round((adventureProgress / 30) * 100)}%</span>
          </div>
        </div>
      </div>

      {/* Backpack & Controller Mini-Fab Tray */}
      <div className="absolute right-4 bottom-28 z-40 flex flex-col gap-3">
        {/* Inventory Bag Toggle */}
        <button 
          onClick={() => { triggerAudioFeed(); setShowInventory(!showInventory); }}
          className={`w-12 h-12 rounded-2xl flex items-center justify-center border shadow-xl active:translate-y-1 transition-all cursor-pointer ${
            showInventory ? 'bg-brand-primary text-[#001f25] border-brand-primary' : 'bg-brand-surface-high border-brand-primary/30 text-brand-primary'
          }`}
        >
          <span className="material-symbols-outlined text-2xl">backpack</span>
        </button>

        {/* Quick heal/energy button */}
        <button 
          onClick={() => {
            if (energyPills <= 0) {
              setActiveNotification('No celestial energy pills left! Level up or complete forest stages to earn more capsule slots.');
              return;
            }
            onUseEnergyPill();
            triggerAudioLevelUp();
            setActiveNotification('💊 Star Pill consumed! Refilled active pet stats to maximum.');
          }}
          className="w-12 h-12 bg-brand-primary-container text-[#005f6d] rounded-2xl flex items-center justify-center shadow-[0_4px_15px_rgba(0,224,255,0.4)] border-b-[3px] border-brand-on-primary-container active:border-b-0 active:translate-y-[3px] transition-all cursor-pointer"
        >
          <span className="material-symbols-outlined text-2xl">health_and_safety</span>
        </button>
      </div>

      {/* Inventory Mini Dialog */}
      {showInventory && (
        <div className="absolute bottom-44 right-4 z-40 w-52 glass-panel p-4 rounded-2xl bg-slate-950/95 border-brand-primary-container/30 shadow-2xl animate-float">
          <div className="flex justify-between items-center border-b border-white/10 pb-1.5 mb-2">
            <span className="text-xs font-bold text-white uppercase tracking-wider">Trainer Backpack</span>
            <button onClick={() => setShowInventory(false)} className="text-[10px] text-brand-error hover:underline cursor-pointer">Close</button>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-brand-on-surface-variant">Max energy capsules</span>
              <span className="font-mono font-bold text-brand-primary">{energyPills}/20</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-brand-on-surface-variant">Lava stones unlocked</span>
              <span className="font-mono font-bold text-brand-secondary">{completedNodes.length}</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-brand-on-surface-variant">Current Gold value</span>
              <span className="font-mono font-bold text-[#e1bae1]">{stars}</span>
            </div>
            <p className="text-[9px] text-brand-on-surface-variant/70 leading-normal border-t border-white/5 pt-1">
              *Completing level nodes and defeating bosses rewards star powder and upgrades.
            </p>
          </div>
        </div>
      )}

      {/* Active notification / dialogue panel */}
      {activeNotification && (
        <div className="absolute bottom-[108px] inset-x-4 z-30 transition-all pointer-events-none">
          <div className="glass-panel p-3 rounded-2xl max-w-sm mx-auto bg-slate-900/95 shadow-xl border-brand-primary/30 pointer-events-auto flex items-start gap-2.5">
            <span className="material-symbols-outlined text-brand-primary mt-0.5">info</span>
            <div className="flex-1">
              <p className="text-xs text-white leading-normal font-medium">{activeNotification}</p>
              <button 
                onClick={() => setActiveNotification(null)}
                className="text-[10px] text-brand-primary hover:underline font-bold mt-1.5 block cursor-pointer"
              >
                Continue adventure
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

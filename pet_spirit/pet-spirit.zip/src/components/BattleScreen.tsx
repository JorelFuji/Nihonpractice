import React, { useState } from 'react';
import { Pet } from '../types';

interface BattleScreenProps {
  playerPet: Pet;
  onAddStars: (amount: number) => void;
  triggerAudioFeed: () => void;
  triggerAudioTrain: () => void;
  triggerAudioLevelUp: () => void;
  onNavigateToMap: () => void;
}

interface Enemy {
  name: string;
  level: number;
  health: number;
  maxHealth: number;
  image: string;
}

export default function BattleScreen({
  playerPet,
  onAddStars,
  triggerAudioFeed,
  triggerAudioTrain,
  triggerAudioLevelUp,
  onNavigateToMap,
}: BattleScreenProps) {
  // Let's create live Battle States
  const [enemy, setEnemy] = useState<Enemy>({
    name: 'Neon Drake',
    level: 42,
    health: 148, // 74% of 200
    maxHealth: 200,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD3_NmOkA5WmsMoW57U5lZNdIMwoLH4suW4ygyFEpsj1c0UOUXNf4GYdzQFQCJ4cE3-CSr5vmVBkWF0SVoXBYxTRZ9zIqUkYA6FQVsExwkNa3U5rv_-eNzTh0dlQHnbrpNhhsR9abTCaWDSMAV-72bS4nclM6-wqgHLKsJnTXaAUvhyaQ1IL-qmrnB6kf86v6G1erhrGkdflg0dgWfu6tb6uieKYjn8s8har5rjE8NLyjJqejZSx8P4z639Bn9Kjdk3q7yRuHPcP4g',
  });

  const [playerHp, setPlayerHp] = useState<number>(164); // 82% of 200
  const [maxPlayerHp] = useState<number>(200);

  const [battleLog, setBattleLog] = useState<string>(`${playerPet.name} used Thunder Bolt!`);
  const [isAnimating, setIsAnimating] = useState<boolean>(false);
  const [shieldActive, setShieldActive] = useState<boolean>(false);
  const [battleFinished, setBattleFinished] = useState<'WIN' | 'LOSE' | null>(null);

  const triggerShake = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setIsAnimating(false);
    }, 450);
  };

  const handleEnemyTurn = (currentEnemyHp: number) => {
    if (currentEnemyHp <= 0) {
      setBattleFinished('WIN');
      triggerAudioLevelUp();
      onAddStars(250);
      return;
    }

    // Neon Drake attacks
    setTimeout(() => {
      triggerAudioTrain();
      const moves = ['Lava Stream', 'Cyber Tail Whip', 'Cyber Flare Strike'];
      const randomMove = moves[Math.floor(Math.random() * moves.length)];
      let damage = 22 + Math.floor(Math.random() * 12);

      if (shieldActive) {
        damage = Math.floor(damage * 0.25); // Blocks 75%
        setShieldActive(false);
        setBattleLog(`🛡️ Protected! Neon Drake used ${randomMove}. Dealt only ${damage} damage (Shield absorbed)!`);
      } else {
        setBattleLog(`🔥 Neon Drake retaliated with ${randomMove}! Dealt ${damage} damage to ${playerPet.name}.`);
      }

      const nextPlayerHp = Math.max(0, playerHp - damage);
      setPlayerHp(nextPlayerHp);

      if (nextPlayerHp <= 0) {
        setBattleFinished('LOSE');
        triggerAudioTrain();
      }
    }, 1500);
  };

  const handleAttack = (type: 'bolt' | 'quick' | 'shield' | 'special') => {
    if (battleFinished) return;
    triggerAudioFeed();
    triggerShake();

    let damage = 0;
    let logMsg = '';
    let nextShield = false;

    switch (type) {
      case 'bolt':
        damage = 25 + Math.floor(Math.random() * 15);
        logMsg = `⚡ ${playerPet.name} summoned THUNDER BOLT! Scorched Neon Drake for ${damage} damage.`;
        break;
      case 'quick':
        damage = 15 + Math.floor(Math.random() * 8);
        logMsg = `🏃 Speed Dash! ${playerPet.name} executed Quick Attack! Dealt ${damage} damage with perfect timing.`;
        break;
      case 'shield':
        damage = 0;
        nextShield = true;
        setShieldActive(true);
        logMsg = `🛡️ Barrier Erected! ${playerPet.name} gains 75% Damage Shield for the next turn.`;
        break;
      case 'special':
        damage = 45 + Math.floor(Math.random() * 20);
        logMsg = `✨ COSMIC EMPOWERMENT! ${playerPet.name} unleashed a crystalline Special Burst! Dealt ${damage} critical damage!`;
        break;
    }

    setBattleLog(logMsg);
    const nextEnemyHp = Math.max(0, enemy.health - damage);
    setEnemy({
      ...enemy,
      health: nextEnemyHp,
    });

    if (nextEnemyHp <= 0) {
      setTimeout(() => {
        setBattleFinished('WIN');
        triggerAudioLevelUp();
        onAddStars(350);
      }, 800);
    } else {
      setShieldActive(nextShield);
      handleEnemyTurn(nextEnemyHp);
    }
  };

  const handleRestart = () => {
    setEnemy({
      ...enemy,
      health: 148,
    });
    setPlayerHp(164);
    setBattleLog(`${playerPet.name} enters the battle arena! Select a combat action.`);
    setBattleFinished(null);
    setShieldActive(false);
  };

  const enemyPercentage = Math.round((enemy.health / enemy.maxHealth) * 100);
  const playerPercentage = Math.round((playerHp / maxPlayerHp) * 100);

  return (
    <div className={`relative w-full h-full flex flex-col justify-between overflow-hidden select-none ${isAnimating ? 'animate-ping' : ''}`} id="battle-screen-root">
      
      {/* Tactical HUD (Top Health Monitors) */}
      <div className="absolute top-4 inset-x-0 px-4 z-20 flex flex-col gap-3">
        {/* Enemy Health Panel */}
        <div className="flex flex-col items-end">
          <div className="glass-panel rounded-xl px-4 py-2 w-2/3 md:w-1/2 max-w-[280px] shadow-[0_0_15px_rgba(255,180,171,0.25)] border-brand-error/25 transition-all">
            <div className="flex justify-between items-center mb-1">
              <span className="font-sans text-[10px] font-extrabold text-brand-error uppercase tracking-wider">{enemy.name} [LV. {enemy.level}]</span>
              <span className="font-mono text-xs font-bold text-brand-error">{enemyPercentage}%</span>
            </div>
            <div className="h-3 w-full bg-brand-surface-highest/80 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-red-500 to-red-800 rounded-full transition-all duration-300"
                style={{ width: `${enemyPercentage}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Player Health Panel */}
        <div className="flex flex-col items-start">
          <div className="glass-panel rounded-xl px-4 py-2 w-2/3 md:w-1/2 max-w-[280px] shadow-[0_0_15px_rgba(0,224,255,0.25)] border-brand-primary/25 transition-all">
            <div className="flex justify-between items-center mb-1">
              <span className="font-sans text-[10px] font-extrabold text-brand-primary uppercase tracking-wider">{playerPet.name} [LV. 38]</span>
              <span className="font-mono text-xs font-bold text-brand-primary">{playerPercentage}%</span>
            </div>
            <div className="h-3 w-full bg-brand-surface-highest/80 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-brand-primary-container to-blue-500 rounded-full transition-all duration-300"
                style={{ width: `${playerPercentage}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* 3D Battlefield Visuals Area */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
        <div className="w-[85%] aspect-square absolute -bottom-24 rounded-full bg-radial from-brand-primary/10 via-transparent to-transparent opacity-60"></div>
        
        {/* Enemy Monster Image */}
        <div className="absolute top-[28%] right-[8%] w-44 h-44 animate-bounce pointer-events-auto cursor-help" style={{ animationDuration: '4.8s' }}>
          <img 
            className="w-full h-full object-contain filter drop-shadow-[0_10px_20px_rgba(255,50,50,0.3)] hover:scale-110 duration-300"
            src={enemy.image}
            alt={enemy.name}
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Player Pet Image */}
        <div className="absolute bottom-[20%] left-[8%] w-56 h-56 scale-125 z-10 pointer-events-auto cursor-help">
          <img 
            className="w-full h-full object-contain filter drop-shadow-[0_20px_35px_rgba(0,224,255,0.55)] hover:scale-105 duration-300 pointer-events-auto"
            src={playerPet.image}
            alt={playerPet.name}
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* Custom Battle Overlay Result Modals */}
      {battleFinished && (
        <div className="absolute inset-0 bg-black/85 backdrop-blur-sm z-40 flex flex-col items-center justify-center px-6 text-center">
          <div className="glass-panel p-6 rounded-3xl max-w-sm w-full border-brand-primary/30 shadow-[0_0_40px_rgba(0,224,255,0.2)] animate-float">
            {battleFinished === 'WIN' ? (
              <>
                <span className="material-symbols-outlined text-6xl text-brand-secondary mb-3 animate-pulse" style={{ fontVariationSettings: "'FILL' 1" }}>trophy</span>
                <h3 className="font-display text-3xl font-extrabold text-brand-secondary mb-2">ARENA VICTORY</h3>
                <p className="text-sm text-brand-on-surface-variant font-medium mb-4 leading-relaxed">
                  Congratulations! {playerPet.name} dominated Neon Drake in the Arena and gained <span className="text-brand-secondary font-bold">+350 Stars</span> and ultimate honor!
                </p>
                <div className="flex gap-2">
                  <button 
                    onClick={handleRestart}
                    className="flex-1 py-3 bg-brand-surface-highest border border-brand-secondary/30 rounded-xl font-bold text-xs text-brand-secondary hover:bg-slate-800 transition shadow-lg shrink-0 cursor-pointer"
                  >
                    Battle Again
                  </button>
                  <button 
                    onClick={onNavigateToMap}
                    className="flex-1 py-3 bg-brand-primary-container text-brand-on-primary-container rounded-xl font-bold text-xs shadow-lg cursor-pointer shrink-0"
                  >
                    Return to Map
                  </button>
                </div>
              </>
            ) : (
              <>
                <span className="material-symbols-outlined text-6xl text-brand-error mb-3" style={{ fontVariationSettings: "'FILL' 1" }}>heart_broken</span>
                <h3 className="font-display text-3xl font-extrabold text-brand-error mb-2">PET DEFEATED</h3>
                <p className="text-sm text-brand-on-surface-variant font-medium mb-4 leading-relaxed">
                  Neon Drake proved too fierce this time. Rest up, rejuvenate your energy stats, and construct a stronger battle defense!
                </p>
                <button 
                  onClick={handleRestart}
                  className="w-full py-3 bg-brand-primary-container text-brand-on-primary-container rounded-xl font-bold text-xs shadow-lg cursor-pointer shrink-0"
                >
                  Quick Re-heal & Retry
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Battle Log Overlay in the Middle */}
      <div className="absolute bottom-[32%] inset-x-4 pointer-events-none z-10 flex justify-center">
        <div className="glass-panel rounded-lg py-2 px-5 max-w-[340px] text-center border-brand-primary-container/30 bg-slate-900/85">
          <p className="font-sans text-[13px] text-brand-primary leading-normal font-medium animate-pulse">
            {battleLog}
          </p>
        </div>
      </div>

      {/* Attack Controls (Bento Style Layout) */}
      <div className="absolute bottom-[108px] inset-x-4 z-30">
        <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
          
          <button 
            id="attack-bolt"
            disabled={!!battleFinished}
            onClick={() => handleAttack('bolt')}
            className="squishy-button flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-brand-primary-container text-brand-on-primary-container font-sans text-xs font-bold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <span className="material-symbols-outlined text-[26px]" style={{ fontVariationSettings: "'FILL' 1" }}>bolt</span>
            Thunder Bolt
          </button>
          
          <button 
            id="attack-quick"
            disabled={!!battleFinished}
            onClick={() => handleAttack('quick')}
            className="squishy-button flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-brand-surface-high border border-brand-primary/20 text-brand-primary font-sans text-xs font-bold cursor-pointer disabled:opacity-40"
          >
            <span className="material-symbols-outlined text-[26px]">speed</span>
            Quick Attack
          </button>
          
          <button 
            id="attack-shield"
            disabled={!!battleFinished}
            onClick={() => handleAttack('shield')}
            className="squishy-button flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-brand-surface-high border border-brand-primary/20 text-brand-primary font-sans text-xs font-bold cursor-pointer disabled:opacity-40"
          >
            <span className="material-symbols-outlined text-[26px]">shield</span>
            Shield Barrier
          </button>
          
          <button 
            id="attack-special"
            disabled={!!battleFinished}
            onClick={() => handleAttack('special')}
            className="squishy-button flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-brand-tertiary-container text-[#422645] font-sans text-xs font-bold shadow-[0_0_12px_rgba(232,192,231,0.5)] cursor-pointer disabled:opacity-40"
          >
            <span className="material-symbols-outlined text-[26px]" style={{ fontVariationSettings: "'FILL' 1" }}>auto_awesome</span>
            Special Star
          </button>
          
        </div>
      </div>

    </div>
  );
}

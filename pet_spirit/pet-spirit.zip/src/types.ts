export interface Pet {
  id: string;
  name: string;
  level: number;
  health: number;
  maxHealth: number;
  energy: number;
  maxEnergy: number;
  image: string;
  thumbnail: string;
  description: string;
  attributes: {
    attack: number;
    defense: number;
    speed: number;
    stamina: number;
  };
  maxAttributeVal: number;
  evolutionPath: {
    currentName: string;
    levelRequired: number;
    nextName: string;
    unlocked: boolean;
  };
  heldItems: (string | null)[];
}

export type ScreenType = 'Habitat' | 'Battle' | 'Map' | 'Team';

export interface GameState {
  pets: Pet[];
  activePetId: string;
  stars: number;
  energyPills: number;
  adventureProgress: number; // e.g. 12 stars collected on map
  selectedScreen: ScreenType;
  completedNodes: string[]; // e.g. ['1-1', '1-2']
  currentPlayerNode: string; // e.g. '2-1'
}

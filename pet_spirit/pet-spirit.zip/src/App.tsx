import React, { useState, useEffect } from 'react';
import { Pet, ScreenType, GameState } from './types';
import HabitatScreen from './components/HabitatScreen';
import BattleScreen from './components/BattleScreen';
import MapScreen from './components/MapScreen';
import TeamScreen from './components/TeamScreen';

// Default initial pets
const INITIAL_PETS: Pet[] = [
  {
    id: 'sparky',
    name: 'Sparky',
    level: 12,
    health: 180,
    maxHealth: 200,
    energy: 45,
    maxEnergy: 100,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAwGETVHRLz3GXtX4XgyvZfmWQcOSuNZuy_pxb36PBMNLBW_wX_x5tbKKEfi9tQ1WaOZHSnocStFRcTNrsVUwwm03O9VHQ4P19HT6227pPIss6N5LhR8qTyAwOmD-JUmnJaDSTGrKRVti8gTLq-dFInGFXTD1mgAAPD5YwaxfjVdW_tjd5PsuVQzW8ZI9iNHMAhTRIkXAhv4scm2cuGuVSGTGRKUVtaGAYCaCKYXTX4f-K-Fd8LMo5pKuslg15rwUxbu5aHQ5n3fCo',
    thumbnail: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAwGETVHRLz3GXtX4XgyvZfmWQcOSuNZuy_pxb36PBMNLBW_wX_x5tbKKEfi9tQ1WaOZHSnocStFRcTNrsVUwwm03O9VHQ4P19HT6227pPIss6N5LhR8qTyAwOmD-JUmnJaDSTGrKRVti8gTLq-dFInGFXTD1mgAAPD5YwaxfjVdW_tjd5PsuVQzW8ZI9iNHMAhTRIkXAhv4scm2cuGuVSGTGRKUVtaGAYCaCKYXTX4f-K-Fd8LMo5pKuslg15rwUxbu5aHQ5n3fCo',
    description: 'A small playful ebullient electric-type creature with neon yellow lightning ear highlights.',
    attributes: { attack: 45, defense: 38, speed: 78, stamina: 52 },
    maxAttributeVal: 120,
    evolutionPath: { currentName: 'Sparky', levelRequired: 30, nextName: 'Thunder Fox', unlocked: false },
    heldItems: [null, null],
  },
  {
    id: 'cyan_drake',
    name: 'Cyan Drake',
    level: 14,
    health: 190,
    maxHealth: 220,
    energy: 85,
    maxEnergy: 120,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCWFzYoQhaZCHkvdKESAk0Pyfw5cC6RsQH8qN1Oz7rftJS44HhcHXu3uxKSgOrtj96CD5D7W4lvUDEcMUnYPT9u0K9PrZ-wMW2WgOoSO4oxfpUbgC0LEh3QxCAicYXQgpODHf8AxNVyHYfzAl61W635M0bm30xejMR1LnUIq6fqNkciMG2skfUjl4u7SJoLVHzo2-fb_YpnC1jr7TrouTl-NVhR91SvN7gajIy20x_OjvPwkaS-N6xoOhw6gx-LoZrB-FWR_mwnNN4',
    thumbnail: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDAiTDfQNEtc0MKBJUyUpUUXMsH9Mt5d6Mla4SV1C-hOpINhoI1BSZaCqF24HtG_clsXhcnU2Bp75m8W3yu8K-X_lcrk8WpeDigjz6IO1jhTLL1pJfMuqD5_bJ_QJBu-6-lbMcFwJ8TMKGOcd5cofkltHf5EmQEkop9Dcka9n_rTnc81OLTcBqcl8Xlf6FL-eTJkZsT0auNLMMRgIKgAyZ765MA0iZxFdNpvvtSrEjyqIxcJmc47idmfVrkRpa1WOc9_90w8vAD8Y0',
    description: 'The Spirit of the Crystal Tides',
    attributes: { attack: 84, defense: 62, speed: 105, stamina: 45 },
    maxAttributeVal: 120,
    evolutionPath: { currentName: 'Cyan Drake', levelRequired: 20, nextName: 'Crystal Monarch', unlocked: false },
    heldItems: [null, null],
  },
];

export default function App() {
  const [selectedScreen, setSelectedScreen] = useState<ScreenType>('Habitat');
  const [pets, setPets] = useState<Pet[]>(INITIAL_PETS);
  const [activePetId, setActivePetId] = useState<string>('sparky');
  const [stars, setStars] = useState<number>(1240);
  const [energyPills, setEnergyPills] = useState<number>(12); // shown as 12/20
  const [completedNodes, setCompletedNodes] = useState<string[]>(['1-1', '1-2']);
  const [settingsOpen, setSettingsOpen] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [trainerName, setTrainerName] = useState<string>('Guardian Spiller');
  const [selectedAvatar, setSelectedAvatar] = useState<string>('spirit_guardian');

  // Load state from local storage on bootstrap
  useEffect(() => {
    try {
      const stored = localStorage.getItem('pet_spirit_game_save');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.pets) setPets(parsed.pets);
        if (parsed.activePetId) setActivePetId(parsed.activePetId);
        if (parsed.stars) setStars(parsed.stars);
        if (parsed.energyPills) setEnergyPills(parsed.energyPills);
        if (parsed.completedNodes) setCompletedNodes(parsed.completedNodes);
        if (parsed.trainerName) setTrainerName(parsed.trainerName);
      }
    } catch (e) {
      console.warn('Local Storage load failed: ', e);
    }
  }, []);

  // Save changes to localStorage on any mutation
  const persistSave = (mutatedPets: Pet[], nextStars: number, nextPills: number, nextNodes: string[]) => {
    try {
      localStorage.setItem('pet_spirit_game_save', JSON.stringify({
        pets: mutatedPets,
        activePetId,
        stars: nextStars,
        energyPills: nextPills,
        completedNodes: nextNodes,
        trainerName,
      }));
    } catch (e) {
      console.warn('Failed saving: ', e);
    }
  };

  // Sound generator
  const triggerSynth = (type: 'feed' | 'levelup' | 'train') => {
    if (!soundEnabled) return;
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'feed') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
        osc.start();
        osc.stop(ctx.currentTime + 0.15);
      } else if (type === 'levelup') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(329.63, ctx.currentTime); // E4
        osc.frequency.setValueAtTime(392.00, ctx.currentTime + 0.08); // G4
        osc.frequency.setValueAtTime(523.25, ctx.currentTime + 0.16); // C5
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.24); // E5
        osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.5);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
      } else if (type === 'train') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
      }
    } catch (err) {
      // Audio is often muted until manual tap
    }
  };

  const handleUpdateActivePet = (updated: Pet) => {
    const next = pets.map((p) => (p.id === updated.id ? updated : p));
    setPets(next);
    persistSave(next, stars, energyPills, completedNodes);
  };

  const handleAddStars = (amount: number) => {
    const nextStars = stars + amount;
    setStars(nextStars);
    persistSave(pets, nextStars, energyPills, completedNodes);
  };

  const handleUpgradePet = (petId: string, cost: number) => {
    const nextStars = stars - cost;
    setStars(nextStars);
    const target = pets.find((p) => p.id === petId);
    if (target) {
      const up = {
        ...target,
        level: target.level + 1,
        health: Math.min(target.maxHealth + 10, target.health + 10),
        maxHealth: target.maxHealth + 10,
        energy: Math.min(target.maxEnergy + 10, target.energy + 10),
        maxEnergy: target.maxEnergy + 10,
        attributes: {
          attack: Math.min(target.maxAttributeVal, target.attributes.attack + 5),
          defense: Math.min(target.maxAttributeVal, target.attributes.defense + 5),
          speed: Math.min(target.maxAttributeVal, target.attributes.speed + 5),
          stamina: Math.min(target.maxAttributeVal, target.attributes.stamina + 5),
        },
      };
      const nextPets = pets.map((p) => (p.id === petId ? up : p));
      setPets(nextPets);
      persistSave(nextPets, nextStars, energyPills, completedNodes);
    }
  };

  const handleCompleteNode = (nodeId: string) => {
    if (!completedNodes.includes(nodeId)) {
      const next = [...completedNodes, nodeId];
      setCompletedNodes(next);
      persistSave(pets, stars, energyPills, next);
    }
  };

  const handleUseEnergyPill = () => {
    const nextPills = Math.max(0, energyPills - 1);
    setEnergyPills(nextPills);
    const updatedPets = pets.map((p) => ({
      ...p,
      health: p.maxHealth,
      energy: p.maxEnergy,
    }));
    setPets(updatedPets);
    persistSave(updatedPets, stars, nextPills, completedNodes);
  };

  const handleResetProgress = () => {
    triggerSynth('train');
    setPets(INITIAL_PETS);
    setStars(1240);
    setEnergyPills(12);
    setCompletedNodes(['1-1', '1-2']);
    setSelectedScreen('Habitat');
    setSettingsOpen(false);
    try {
      localStorage.clear();
    } catch (e) {}
  };

  // Avatar assets mapped to state variables
  const AVATAR_IMAGES = {
    spirit_guardian: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBpZAKoA7m-bKRdflaEMTE4UDnYfgAm0h6LNnvDY3xch4AOEbJDuF8f7QMQmQdyvv21tTU7na07t9TgPRiNFQ0IPS274DQ9I-hi7uW-f4NLi7hOfo18yfHdEfj8h5DfkEz6qNjHRioHa31ERIDNGccLxZbd9x85KSe6iVfUDOyX9r0CRorZvG0GpD8KOb76NwPCB49X8ORZQrw5S_eyAJjZIE0xn3qCBTNCzKhYZ04vUl7XyoaNA-AljIWNqFTkUifsvmjmK96moCM',
    visor_trainer: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBR89CPLLWcTSAHQfKoO3NXWMB3cPd2x0ozkgON4HbT1HI_jYn25BGRrVO-45TbKv2xxGHF8g10zlRhmcYqxxsuAHaNdg7b2MxUsp3n3z6Y0aa_mNZvQTrqyQ_xmBiZ_RhdRQri60fzvCKo3w3gamT8Cs4EjHfhx9z6iGvm9iAPpvoGn6NWiagZSQuWLVf-xYlbAno1lWFqLlERtvP9aJb4ymmDNZ3vkVffdbs3kViVQ89HkXCpme-YuMcuCKI5C2cNzsvp8rM_j0s',
    tactical_shield: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCSq3Cp_n1Fv_FfMq_nMyKOLrthyxr9YX-0aCTIBsyErycaRliUJQV7e1ODQT01tsg8G7aVdVVuB6roGIuIz8dUsp5Yso6oafSbLi48Ed-6ZewkK_n0JtH18N2BZ_TAQX7eAVAnoF8o3W2l_e64yPR_ZNfoMaYwc3ZpjJJByT6S5kQZQfT8UGSnJID7Uw4xzbzHkoeATazB-CfsxgjIhD6cVnMttpPlshWCX-7J6w3X7BC2nEm6c7rqb2Tpiz5ptRWmLNsqzJ0RIi8',
    futuristic: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC1VQWGd8S9XZuLrk02zbFTBMjJbWyzNo-Zxg2ejrpRHPYioU7WDK3QyAYDwyplMdht29vjW2SHV2JE-7bR-1tZoiaZOFOK1OoG2JJaLW3CFVM0S4ZZRtuYMi0WmizTpsgrettgvBmE9ctp3yN5hTRg90s3DfvRUs_e9DCQaGSmQicQKgbnFENOchhYM2b9GQ9IUOszzKAzrKDQgDhoN6__BRIa2OBaSbTqgUb6HqCZMPXnol_zQhPV25oUeMLYimTJUCcVaR_fW68',
  };

  const getTrainerAvatar = () => {
    switch (selectedAvatar) {
      case 'spirit_guardian': return AVATAR_IMAGES.spirit_guardian;
      case 'visor_trainer': return AVATAR_IMAGES.visor_trainer;
      case 'tactical_shield': return AVATAR_IMAGES.tactical_shield;
      case 'futuristic': return AVATAR_IMAGES.futuristic;
      default: return AVATAR_IMAGES.spirit_guardian;
    }
  };

  const activePet = pets.find((p) => p.id === activePetId) || pets[0];

  return (
    <div className="relative min-h-[100dvh] bg-[#0d1516] text-[#dce4e6] font-sans flex flex-col overflow-x-hidden select-none pb-24">
      
      {/* 3D Immersive Environment Background Layer */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {selectedScreen === 'Habitat' && (
          <>
            <img 
              className="w-full h-full object-cover opacity-80" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCYQ1qED_XfC6jMmJygmTJ1XiuIfX-gFPndsgAMj5h8NkVZxpZmtx4my8kU0yRAOGH_qYbw4ntwqGB4hHyfd6PFBenkXKVSAuy7BBVm_Na5IVViaxpfOaq5SPJy7qcGzUSU5qr6x6wdECPvsCl3C2fuoe-i4jUSYSgaC-5tAa5o5xypy4qDtcYChyD5HO-_2FhQ4-tvOgzH8TINNgCN6WIAh2qZ9HWGMyGXhERF4btb9rUj6gmSvQxkL1h_OCkGc4XkXJRvRAZNFLQ" 
              alt="Habitat landscape"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#0d1516]/70 via-transparent to-[#0d1516]/95"></div>
          </>
        )}
        
        {selectedScreen === 'Battle' && (
          <>
            <div className="absolute inset-0 bg-radial from-slate-900 via-[#0d1516] to-[#080f11]"></div>
            {/* Holographic matrix floor overlay */}
            <div className="absolute bottom-0 inset-x-0 h-1/2 bg-[linear-gradient(rgba(0,224,255,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(0,224,255,0.06)_1px,transparent_1px)] bg-[size:24px_24px] [transform:rotateX(75deg)] origin-bottom opacity-40"></div>
          </>
        )}

        {selectedScreen === 'Map' && (
          <div className="absolute inset-0 bg-[#0d1516]">
            {/* Subtle nebula glow */}
            <div className="absolute top-[20%] left-[30%] w-96 h-96 rounded-full bg-brand-primary-container/5 blur-[120px] animate-pulse-glow"></div>
          </div>
        )}

        {selectedScreen === 'Team' && (
          <div className="absolute inset-0 bg-[#0d1516]">
            <div className="absolute top-[10%] left-[10%] w-72 h-72 bg-purple-500/5 rounded-full blur-[100px]"></div>
            <div className="absolute bottom-[20%] right-[10%] w-80 h-80 bg-brand-primary-container/5 rounded-full blur-[100px]"></div>
          </div>
        )}
      </div>

      {/* FIXED TOP APPBAR NAV */}
      <header className="fixed top-0 w-full z-50 flex justify-between items-center px-4 py-2 border-b border-brand-primary/25 bg-brand-surface/50 backdrop-blur-md shadow-[0_4px_20px_rgba(0,224,255,0.12)]">
        <div className="flex items-center gap-2.5">
          <div 
            onClick={() => { triggerSynth('feed'); setSettingsOpen(true); }}
            className="w-10 h-10 rounded-full border-2 border-brand-primary overflow-hidden bg-brand-surface-high cursor-pointer shadow-[0_0_10px_rgba(0,224,255,0.4)] transition-all active:scale-95 duration-150"
          >
            <img className="w-full h-full object-cover" src={getTrainerAvatar()} alt="Guardian Visor Portrait" referrerPolicy="no-referrer" />
          </div>
          <span className="font-display text-xl font-extrabold tracking-tight text-brand-primary drop-shadow-[0_0_8px_rgba(0,224,255,0.35)]">
            Pet Spirit
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-mono font-bold tracking-wider opacity-60 uppercase mr-1 hidden sm:inline">{trainerName}</span>
          <button 
            onClick={() => { triggerSynth('feed'); setSettingsOpen(true); }}
            className="w-9 h-9 flex items-center justify-center text-brand-primary hover:opacity-85 transition-opacity active:scale-[0.9] duration-150 rounded-lg hover:bg-white/5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[24px]">settings</span>
          </button>
        </div>
      </header>

      {/* SETTINGS / INFO OVERLAY DIALOG */}
      {settingsOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="glass-panel p-5 rounded-3xl max-w-sm w-full border-brand-primary/40 shadow-[0_0_35px_rgba(0,224,255,0.25)] flex flex-col gap-4 max-h-[85vh] overflow-y-auto no-scrollbar">
            
            <div className="flex justify-between items-center border-b border-white/10 pb-2">
              <h3 className="font-display text-xl font-black text-white uppercase tracking-tight">Trainer Dashboard</h3>
              <button 
                onClick={() => setSettingsOpen(false)}
                className="text-brand-error text-xs font-bold px-2 py-1 bg-brand-error/10 rounded-lg hover:bg-brand-error/20 cursor-pointer"
              >
                Close
              </button>
            </div>

            {/* Custom Trainer configuration */}
            <div className="space-y-3.5 pt-1">
              <div>
                <label className="block text-[10px] font-bold text-brand-on-surface-variant uppercase tracking-wider mb-1">Trainer Guardian Name</label>
                <input 
                  type="text" 
                  value={trainerName}
                  onChange={(e) => setTrainerName(e.target.value)}
                  className="w-full bg-brand-surface-high border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:border-brand-primary focus:outline-none focus:ring-1 focus:ring-brand-primary"
                />
              </div>

              {/* Sound Option Toggle */}
              <div className="flex justify-between items-center bg-brand-surface-high/50 p-2.5 rounded-xl border border-white/5">
                <span className="text-xs text-brand-on-surface-variant">Retro SFX Audio Output</span>
                <button
                  onClick={() => {
                    setSoundEnabled(!soundEnabled);
                    triggerSynth('feed');
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    soundEnabled ? 'bg-brand-secondary text-[#053900]' : 'bg-brand-surface-highest text-white/40'
                  }`}
                >
                  {soundEnabled ? '● ENABLED' : '○ MUTED'}
                </button>
              </div>

              {/* Choose Instructor Avatar Image */}
              <div>
                <label className="block text-[10px] font-bold text-brand-on-surface-variant uppercase tracking-wider mb-1.5">Select Instructor visors</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {Object.entries(AVATAR_IMAGES).map(([key, src]) => (
                    <button
                      key={key}
                      onClick={() => { triggerSynth('feed'); setSelectedAvatar(key); }}
                      className={`aspect-square rounded-xl overflow-hidden border-2 cursor-pointer relative transition-all ${
                        selectedAvatar === key ? 'border-brand-primary scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img className="w-full h-full object-cover" src={src} alt="Companion Choice" referrerPolicy="no-referrer" />
                      {selectedAvatar === key && (
                        <div className="absolute inset-0 bg-brand-primary/15 flex items-center justify-center">
                          <span className="text-[10px] text-brand-primary font-bold">✓</span>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Game Manual Instructions */}
              <div className="bg-brand-surface-high/60 p-3 rounded-2xl border border-white/5 text-[11px] leading-relaxed text-brand-on-surface-variant space-y-1.5">
                <p className="font-bold text-white text-xs border-b border-white/5 pb-1 mb-1">🎮 How to play:</p>
                <p>• 🏕️ <span className="font-bold text-[#baf2ff]">Habitat</span>: Nurture your pet spirit by giving treats, practicing, or cleaning to increment metrics. Watch out for level progress and stat multiplier increments.</p>
                <p>• ⚔️ <span className="font-bold text-brand-error">Battle Arena</span>: Strike with quick slashes, barrier blocks, or element specials to defeat Neon Drake. Victory earns star powder!</p>
                <p>• 🗺️ <span className="font-bold text-brand-secondary">Map Paths</span>: Clear stage nodes (1-1, 1-2) within biomes to earn points and ready your strength parameters.</p>
                <p>• 🧬 <span className="font-bold text-brand-tertiary-fixed">Team Laboratory</span>: Equip found protective items, unlock temporary skill passives, and upgrade pet stats using star gold.</p>
              </div>

              {/* Hard reset progression buttons */}
              <button
                onClick={() => {
                  if (confirm('Are you sure you want to hard reset all achievements and items?')) {
                    handleResetProgress();
                  }
                }}
                className="w-full py-2.5 bg-brand-error-container hover:bg-red-950 text-brand-error text-xs font-bold rounded-xl border border-brand-error/25 transition cursor-pointer"
              >
                Reset Save & Progression
              </button>
            </div>

          </div>
        </div>
      )}

      {/* DYNAMIC SCREEN CONTENT DISPLAY */}
      <main className="flex-1 w-full pt-16 z-10 relative flex flex-col justify-between">
        {selectedScreen === 'Habitat' && (
          <HabitatScreen 
            pet={activePet}
            stars={stars}
            energyPills={`${energyPills}/20`}
            onUpdatePet={handleUpdateActivePet}
            onAddStars={handleAddStars}
            triggerAudioFeed={() => triggerSynth('feed')}
            triggerAudioLevelUp={() => triggerSynth('levelup')}
            triggerAudioTrain={() => triggerSynth('train')}
          />
        )}

        {selectedScreen === 'Battle' && (
          <BattleScreen 
            playerPet={activePet}
            onAddStars={handleAddStars}
            triggerAudioFeed={() => triggerSynth('feed')}
            triggerAudioTrain={() => triggerSynth('train')}
            triggerAudioLevelUp={() => triggerSynth('levelup')}
            onNavigateToMap={() => setSelectedScreen('Map')}
          />
        )}

        {selectedScreen === 'Map' && (
          <MapScreen 
            completedNodes={completedNodes}
            currentPlayerNode="2-1"
            stars={stars}
            adventureProgress={completedNodes.length * 6} // e.g. 12 progress stars out of 30
            onCompleteNode={handleCompleteNode}
            onAddStars={handleAddStars}
            onStartBossBattle={() => setSelectedScreen('Battle')}
            onUseEnergyPill={handleUseEnergyPill}
            triggerAudioFeed={() => triggerSynth('feed')}
            triggerAudioLevelUp={() => triggerSynth('levelup')}
            energyPills={energyPills}
          />
        )}

        {selectedScreen === 'Team' && (
          <TeamScreen 
            pets={pets}
            activePetId={activePetId}
            stars={stars}
            onSelectPet={(petId) => setActivePetId(petId)}
            onUpgradePet={handleUpgradePet}
            onAddStars={handleAddStars}
            triggerAudioFeed={() => triggerSynth('feed')}
            triggerAudioLevelUp={() => triggerSynth('levelup')}
            triggerAudioTrain={() => triggerSynth('train')}
          />
        )}
      </main>

      {/* FIXED BOTTOM NAVIGATION BAR */}
      <nav className="fixed bottom-0 w-full z-50 rounded-t-2xl border-t border-brand-primary/20 bg-brand-surface-low/80 backdrop-blur-xl shadow-[0_-8px_30px_rgba(0,0,0,0.6)] flex justify-around items-center px-4 h-16 py-1">
        
        {/* Nav 1: Habitat */}
        <button 
          id="nav-tab-habitat"
          onClick={() => { triggerSynth('feed'); setSelectedScreen('Habitat'); }}
          className={`flex flex-col items-center justify-center transition-all duration-300 cursor-pointer focus:outline-none ${
            selectedScreen === 'Habitat'
              ? 'bg-brand-primary-container text-[#001f25] font-bold rounded-full xxs:px-4 xs:px-6 py-2 shadow-[0_0_15px_rgba(0,224,255,0.5)] scale-105 active:translate-y-0.5'
              : 'text-brand-on-surface-variant hover:text-brand-primary p-2 active:translate-y-0.5'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]" style={selectedScreen === 'Habitat' ? { fontVariationSettings: "'FILL' 1" } : {}}>home</span>
          <span className="font-sans text-[10px] font-bold tracking-tight">Habitat</span>
        </button>

        {/* Nav 2: Battle */}
        <button 
          id="nav-tab-battle"
          onClick={() => { triggerSynth('feed'); setSelectedScreen('Battle'); }}
          className={`flex flex-col items-center justify-center transition-all duration-300 cursor-pointer focus:outline-none ${
            selectedScreen === 'Battle'
              ? 'bg-brand-primary-container text-[#001f25] font-bold rounded-full xxs:px-4 xs:px-6 py-2 shadow-[0_0_15px_rgba(0,224,255,0.5)] scale-105 active:translate-y-0.5'
              : 'text-brand-on-surface-variant hover:text-brand-primary p-2 active:translate-y-0.5'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]" style={selectedScreen === 'Battle' ? { fontVariationSettings: "'FILL' 1" } : {}}>swords</span>
          <span className="font-sans text-[10px] font-bold tracking-tight">Battle</span>
        </button>

        {/* Nav 3: Map */}
        <button 
          id="nav-tab-map"
          onClick={() => { triggerSynth('feed'); setSelectedScreen('Map'); }}
          className={`flex flex-col items-center justify-center transition-all duration-300 cursor-pointer focus:outline-none ${
            selectedScreen === 'Map'
              ? 'bg-brand-primary-container text-[#001f25] font-bold rounded-full xxs:px-4 xs:px-6 py-2 shadow-[0_0_15px_rgba(0,224,255,0.5)] scale-105 active:translate-y-0.5'
              : 'text-brand-on-surface-variant hover:text-brand-primary p-2 active:translate-y-0.5'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]" style={selectedScreen === 'Map' ? { fontVariationSettings: "'FILL' 1" } : {}}>map</span>
          <span className="font-sans text-[10px] font-bold tracking-tight">Map</span>
        </button>

        {/* Nav 4: Team */}
        <button 
          id="nav-tab-team"
          onClick={() => { triggerSynth('feed'); setSelectedScreen('Team'); }}
          className={`flex flex-col items-center justify-center transition-all duration-300 cursor-pointer focus:outline-none ${
            selectedScreen === 'Team'
              ? 'bg-brand-primary-container text-[#001f25] font-bold rounded-full xxs:px-4 xs:px-6 py-2 shadow-[0_0_15px_rgba(0,224,255,0.5)] scale-105 active:translate-y-0.5'
              : 'text-brand-on-surface-variant hover:text-brand-primary p-2 active:translate-y-0.5'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]" style={selectedScreen === 'Team' ? { fontVariationSettings: "'FILL' 1" } : {}}>monitoring</span>
          <span className="font-sans text-[10px] font-bold tracking-tight">Team</span>
        </button>

      </nav>

    </div>
  );
}
